import asyncio
import logging
from datetime import datetime
from typing import Dict, List, Optional
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (Application, CommandHandler, CallbackQueryHandler,
                          ContextTypes, MessageHandler, filters)
from telegram.constants import ParseMode

from config.settings import BOT_TOKEN, CHAT_ID, SYMBOLS, TIMEFRAMES, MAX_MESSAGE_LENGTH
from data.data_fetcher import DataFetcher
from indicators.technical_indicators import TechnicalIndicators
from analysis.smc_analyzer import SMCAnalyzer
from analysis.pattern_analyzer import PatternAnalyzer
from analysis.entry_signal import EntrySignalGenerator
from analysis.fundamental_analyzer import FundamentalAnalyzer
from analysis.mtf_analyzer import MultiTimeframeAnalyzer
from ai_engine.ai_models import AIAnalyzer
from utils.report_generator import DetailedReportGenerator

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO)
logger = logging.getLogger(__name__)


class TradingBot:

    def __init__(self):
        self.data_fetcher = DataFetcher()
        self.fundamental = FundamentalAnalyzer()
        self.ai_analyzer = AIAnalyzer()
        self.report_generator = DetailedReportGenerator()
        self.user_states = {}

    def get_main_menu(self) -> InlineKeyboardMarkup:
        keyboard = [[
            InlineKeyboardButton("🔥 ورود 100% ربات دیوانه 🔥",
                                 callback_data="menu_crazy_bot")
        ],
                    [
                        InlineKeyboardButton("🎯 ورود سوباراشی",
                                             callback_data="menu_subarashi"),
                        InlineKeyboardButton("🎪 ورود اسنایپری",
                                             callback_data="menu_sniper")
                    ],
                    [
                        InlineKeyboardButton("📊 تحلیل اندیکاتور",
                                             callback_data="menu_indicators"),
                        InlineKeyboardButton("📈 تحلیل تکنیکال",
                                             callback_data="menu_technical")
                    ],
                    [
                        InlineKeyboardButton("💎 تحلیل SMC",
                                             callback_data="menu_smc"),
                        InlineKeyboardButton("🤖 تحلیل AI",
                                             callback_data="menu_ai")
                    ],
                    [
                        InlineKeyboardButton("💼 تحلیل فاندامنتال",
                                             callback_data="menu_fundamental"),
                        InlineKeyboardButton("📰 اخبار",
                                             callback_data="menu_news")
                    ],
                    [
                        InlineKeyboardButton("🔄 تحلیل کامل",
                                             callback_data="menu_full"),
                        InlineKeyboardButton("💰 قیمت‌های فعلی",
                                             callback_data="menu_prices")
                    ],
                    [
                        InlineKeyboardButton("📡 اسکنر بازار",
                                             callback_data="menu_scanner"),
                        InlineKeyboardButton("📊 چند تایم‌فریم",
                                             callback_data="menu_mtf")
                    ],
                    [
                        InlineKeyboardButton("🌡️ احساسات بازار",
                                             callback_data="menu_sentiment"),
                        InlineKeyboardButton("🔀 مقایسه نمادها",
                                             callback_data="menu_compare")
                    ],
                    [
                        InlineKeyboardButton("➕ اندیکاتور اضافی",
                                             callback_data="menu_extra_ind")
                    ],
                    [
                        InlineKeyboardButton(
                            "🎯 نقطه ورود همه نمادها 100%",
                            callback_data="menu_all_entries")
                    ],
                    [
                        InlineKeyboardButton(
                            "🏹 نقطه ورود صمدی",
                            callback_data="menu_samadi")
                    ]]
        return InlineKeyboardMarkup(keyboard)

    def get_symbol_keyboard(self) -> InlineKeyboardMarkup:
        keyboard = []
        row = []
        all_symbols = list(SYMBOLS["forex"].keys()) + list(
            SYMBOLS["crypto"].keys())
        for i, symbol in enumerate(all_symbols):
            emoji = "🥇" if "XAU" in symbol else "₿" if symbol in [
                "BTCUSD", "XRPUSD"
            ] else "💱"
            row.append(
                InlineKeyboardButton(f"{emoji} {symbol}",
                                     callback_data=f"symbol_{symbol}"))
            if len(row) == 2:
                keyboard.append(row)
                row = []
        if row:
            keyboard.append(row)
        keyboard.append(
            [InlineKeyboardButton("🔙 بازگشت", callback_data="back_main")])
        return InlineKeyboardMarkup(keyboard)

    def get_timeframe_keyboard(self) -> InlineKeyboardMarkup:
        keyboard = []
        row = []
        for tf, info in TIMEFRAMES.items():
            row.append(
                InlineKeyboardButton(info["display"],
                                     callback_data=f"tf_{tf}"))
            if len(row) == 3:
                keyboard.append(row)
                row = []
        if row:
            keyboard.append(row)
        keyboard.append(
            [InlineKeyboardButton("🔙 بازگشت", callback_data="back_symbols")])
        return InlineKeyboardMarkup(keyboard)

    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        welcome_text = """
🤖 **ربات تحلیل و معاملات هوشمند**

به سیستم تحلیل پیشرفته بازارهای مالی خوش آمدید!

📊 **امکانات:**
• تحلیل سوباراشی و اسنایپری
• 20+ اندیکاتور تکنیکال
• تحلیل Smart Money Concepts
• هوش مصنوعی پیشرفته
• تحلیل فاندامنتال و اخبار

💹 **نمادها:**
فارکس: XAUUSD, USDJPY, GBPUSD, EURUSD
کریپتو: BTCUSD, XRPUSD

⏱ **تایم فریم‌ها:**
 1m | 5m | 15m | 30m | 1h | 4h | Daily

از منوی زیر یک گزینه را انتخاب کنید:
"""
        await update.message.reply_text(welcome_text,
                                        reply_markup=self.get_main_menu(),
                                        parse_mode=ParseMode.MARKDOWN)

    async def button_callback(self, update: Update,
                              context: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()

        user_id = query.from_user.id
        data = query.data

        if data.startswith("menu_"):
            menu_type = data.replace("menu_", "")
            self.user_states[user_id] = {"menu": menu_type}

            if menu_type == "all_entries":
                await query.edit_message_text(
                    "🎯 در حال بررسی نقطه ورود همه نمادها...\n"
                    "لطفا صبور باشید (30 تا 60 ثانیه)")
                await self._send_all_entries_analysis(query, context)

            elif menu_type == "sentiment":
                await query.edit_message_text("🌡️ در حال سنجش احساسات بازار...")
                await self._send_sentiment_analysis(query, context)

            elif menu_type == "scanner":
                await query.edit_message_text(
                    "📡 **اسکنر بازار**\n\nتایم‌فریم اسکن را انتخاب کنید:",
                    reply_markup=self.get_timeframe_keyboard(),
                    parse_mode=ParseMode.MARKDOWN)

            elif menu_type == "mtf":
                await query.edit_message_text(
                    "📊 **تحلیل چند تایم‌فریم**\n\nنماد را انتخاب کنید:",
                    reply_markup=self.get_symbol_keyboard(),
                    parse_mode=ParseMode.MARKDOWN)

            elif menu_type == "compare":
                self.user_states[user_id]["compare_step"] = 1
                await query.edit_message_text(
                    "🔀 **مقایسه نمادها**\n\nنماد اول را انتخاب کنید:",
                    reply_markup=self.get_symbol_keyboard(),
                    parse_mode=ParseMode.MARKDOWN)

            else:
                await query.edit_message_text(
                    f"🔍 **انتخاب نماد برای {self._get_menu_name(menu_type)}**\n\nیک نماد را انتخاب کنید:",
                    reply_markup=self.get_symbol_keyboard(),
                    parse_mode=ParseMode.MARKDOWN)

        elif data.startswith("symbol_"):
            symbol = data.replace("symbol_", "")
            state = self.user_states.get(user_id, {})
            menu = state.get("menu", "")

            if menu == "mtf":
                self.user_states[user_id]["symbol"] = symbol
                await query.edit_message_text(
                    f"⏳ در حال تحلیل {symbol} در همه تایم‌فریم‌ها...")
                await self._send_mtf_analysis(query, context, symbol)

            elif menu == "compare":
                step = state.get("compare_step", 1)
                if step == 1:
                    self.user_states[user_id]["compare_symbol1"] = symbol
                    self.user_states[user_id]["compare_step"] = 2
                    await query.edit_message_text(
                        f"🔀 نماد اول: {symbol}\n\nنماد دوم را انتخاب کنید:",
                        reply_markup=self.get_symbol_keyboard(),
                        parse_mode=ParseMode.MARKDOWN)
                else:
                    self.user_states[user_id]["symbol"] = symbol
                    await query.edit_message_text(
                        f"🔀 مقایسه {state.get('compare_symbol1')} و {symbol}\n\nتایم‌فریم را انتخاب کنید:",
                        reply_markup=self.get_timeframe_keyboard(),
                        parse_mode=ParseMode.MARKDOWN)

            else:
                if user_id in self.user_states:
                    self.user_states[user_id]["symbol"] = symbol
                else:
                    self.user_states[user_id] = {"symbol": symbol}
                await query.edit_message_text(
                    f"⏱ **انتخاب تایم فریم برای {symbol}**\n\nیک تایم فریم را انتخاب کنید:",
                    reply_markup=self.get_timeframe_keyboard(),
                    parse_mode=ParseMode.MARKDOWN)

        elif data.startswith("tf_"):
            timeframe = data.replace("tf_", "")
            if user_id in self.user_states:
                self.user_states[user_id]["timeframe"] = timeframe
                await self._process_analysis(query, context, user_id)

        elif data == "back_main":
            await query.edit_message_text(
                "🤖 **منوی اصلی**\n\nیک گزینه را انتخاب کنید:",
                reply_markup=self.get_main_menu(),
                parse_mode=ParseMode.MARKDOWN)

        elif data == "back_symbols":
            await query.edit_message_text(
                "🔍 **انتخاب نماد**\n\nیک نماد را انتخاب کنید:",
                reply_markup=self.get_symbol_keyboard(),
                parse_mode=ParseMode.MARKDOWN)

    def _get_menu_name(self, menu_type: str) -> str:
        names = {
            "crazy_bot": "ورود 100% ربات دیوانه",
            "subarashi": "ورود سوباراشی",
            "sniper": "ورود اسنایپری",
            "indicators": "تحلیل اندیکاتور",
            "technical": "تحلیل تکنیکال",
            "smc": "تحلیل SMC",
            "ai": "تحلیل AI",
            "fundamental": "تحلیل فاندامنتال",
            "news": "اخبار",
            "full": "تحلیل کامل",
            "prices": "قیمت‌ها",
            "scanner": "اسکنر بازار",
            "mtf": "تحلیل چند تایم‌فریم",
            "sentiment": "سنجش احساسات بازار",
            "compare": "مقایسه نمادها",
            "extra_ind": "اندیکاتور اضافی",
            "all_entries": "نقطه ورود همه نمادها 100%",
            "samadi": "نقطه ورود صمدی"
        }
        return names.get(menu_type, menu_type)

    def _price_decimals(self, price: float) -> int:
        if price >= 1000:
            return 2
        elif price >= 100:
            return 3
        else:
            return 5

    def _format_entry_report(self, signal: dict, symbol: str, tf: str) -> str:
        sig_type = signal.get('signal_type', 'NEUTRAL')
        confidence = signal.get('confidence', 0)
        entry = signal.get('entry')
        sl = signal.get('stop_loss')
        tp1 = signal.get('take_profit_1')
        tp2 = signal.get('take_profit_2')
        tp3 = signal.get('take_profit_3')
        current_price = signal.get('current_price', entry or 0)
        atr = signal.get('atr', 0)
        reasons = signal.get('reasons', [])

        d = self._price_decimals(current_price)
        tf_display = TIMEFRAMES.get(tf, {}).get('display', tf)

        sig_icon = "🟢" if sig_type == "LONG" else "🔴"
        dir_text = "خرید (LONG)" if sig_type == "LONG" else "فروش (SHORT)"

        if entry and sl:
            risk_pips = abs(entry - sl)
            risk_pct = risk_pips / entry * 100
        else:
            risk_pips = 0
            risk_pct = 0

        if entry and sl and tp1:
            rr1 = abs(tp1 - entry) / abs(entry - sl) if abs(entry - sl) > 0 else 0
            rr2 = abs(tp2 - entry) / abs(entry - sl) if tp2 and abs(entry - sl) > 0 else 0
            rr3 = abs(tp3 - entry) / abs(entry - sl) if tp3 and abs(entry - sl) > 0 else 0
        else:
            rr1 = rr2 = rr3 = 0

        ind = signal.get('indicators', {})
        smc = signal.get('smc', {})
        patterns = signal.get('patterns', {})

        rsi_val = ind.get('RSI', {}).get('value', 0)
        rsi_signal = ind.get('RSI', {}).get('signal', 'N/A')
        macd_trend = ind.get('MACD', {}).get('trend', 'N/A')
        ema_trend = ind.get('EMA', {}).get('trend', 'N/A')
        ema50 = ind.get('EMA', {}).get('EMA_50', 0)
        ema200 = ind.get('EMA', {}).get('EMA_200', 0)
        supertrend = ind.get('SUPERTREND', {}).get('signal', 'N/A')
        adx_val = ind.get('ADX', {}).get('adx', 0)
        bb_signal = ind.get('BOLLINGER', {}).get('signal', 'N/A')
        stoch_k = ind.get('STOCHASTIC', {}).get('k', 0)

        ms = smc.get('market_structure', {})
        ms_trend = ms.get('trend', 'N/A')
        ms_bos = ms.get('recent_bos', 0) > 0
        ms_choch = ms.get('recent_choch', 0) > 0

        ob_list_bull = [ob for ob in smc.get('order_blocks', []) if ob.get('type') == 'BULLISH_OB']
        ob_list_bear = [ob for ob in smc.get('order_blocks', []) if ob.get('type') == 'BEARISH_OB']
        fvg_bull = [f for f in smc.get('fvg', []) if f.get('type') == 'BULLISH_FVG']
        fvg_bear = [f for f in smc.get('fvg', []) if f.get('type') == 'BEARISH_FVG']
        nearest_demand = smc.get('supply_demand', {}).get('nearest_demand')
        nearest_supply = smc.get('supply_demand', {}).get('nearest_supply')
        pd_data = smc.get('premium_discount', {})
        premium_discount = pd_data.get('current_zone', pd_data.get('zone', 'N/A'))
        liq_list = smc.get('liquidity', [])
        liq_list = liq_list if isinstance(liq_list, list) else []
        liq_sweep = len(liq_list) > 0

        nearest_support = patterns.get('support_resistance', {}).get('nearest_support')
        nearest_resistance = patterns.get('support_resistance', {}).get('nearest_resistance')
        fib_levels = patterns.get('fibonacci', {})
        pivot_pp = ind.get('PIVOT', {}).get('PP', 0)

        if sig_type == "LONG":
            ob_ref = ob_list_bull[0] if ob_list_bull else None
            fvg_ref = fvg_bull[-1] if fvg_bull else None
            zone_ref = nearest_demand
            ob_type_text = "صعودی (Bullish OB)"
            fvg_type_text = "صعودی (Bullish FVG)"
            sl_desc = "زیر پایین‌ترین swing با فاصله ATR"
            invalidation = f"بسته شدن کندل زیر {sl:.{d}f}" if sl else "N/A"
        else:
            ob_ref = ob_list_bear[0] if ob_list_bear else None
            fvg_ref = fvg_bear[-1] if fvg_bear else None
            zone_ref = nearest_supply
            ob_type_text = "نزولی (Bearish OB)"
            fvg_type_text = "نزولی (Bearish FVG)"
            sl_desc = "بالای بلندترین swing با فاصله ATR"
            invalidation = f"بسته شدن کندل بالای {sl:.{d}f}" if sl else "N/A"

        entry_reasons = []
        if ob_ref and entry:
            if ob_ref['bottom'] <= entry <= ob_ref['top']:
                entry_reasons.append(f"قیمت داخل Order Block {ob_type_text} ({ob_ref['bottom']:.{d}f} - {ob_ref['top']:.{d}f})")
        if fvg_ref and entry:
            if fvg_ref['bottom'] <= entry <= fvg_ref['top']:
                entry_reasons.append(f"قیمت در FVG {fvg_type_text} ({fvg_ref['bottom']:.{d}f} - {fvg_ref['top']:.{d}f})")
        if zone_ref:
            zone_name = "ناحیه تقاضا" if sig_type == "LONG" else "ناحیه عرضه"
            entry_reasons.append(f"نزدیک {zone_name} ({zone_ref.get('bottom', 0):.{d}f} - {zone_ref.get('top', 0):.{d}f})")
        if ms_bos:
            entry_reasons.append("BOS تایید شده - شکست ساختار در جهت سیگنال")
        if ms_choch:
            entry_reasons.append("CHoCH - تغییر کاراکتر بازار تایید شد")
        if liq_sweep:
            entry_reasons.append("Liquidity Sweep - نقدینگی جارو شد و برگشت رخ داد")
        if premium_discount == 'DISCOUNT' and sig_type == 'LONG':
            entry_reasons.append("قیمت در ناحیه Discount (زیر 50% فیبو) - ارزان")
        if premium_discount == 'PREMIUM' and sig_type == 'SHORT':
            entry_reasons.append("قیمت در ناحیه Premium (بالای 50% فیبو) - گران")
        if not entry_reasons:
            entry_reasons.append("تلاقی چند اندیکاتور در این سطح")

        lines = []
        lines.append(f"\n{'─'*38}")
        lines.append(f"{sig_icon} {symbol}  |  {tf_display}  |  {dir_text}")
        lines.append(f"{'─'*38}")
        lines.append(f"اطمینان سیگنال: {confidence:.1f}%")
        lines.append(f"قیمت فعلی:      {current_price:.{d}f}")
        lines.append(f"ATR (نوسان):    {atr:.{d}f}")
        lines.append("")

        lines.append("── نقطه ورود ─────────────────────")
        lines.append(f"Entry:  {entry:.{d}f}" if entry else "Entry:  N/A")
        lines.append("  چرا این نقطه؟")
        for er in entry_reasons:
            lines.append(f"  • {er}")
        lines.append("")

        lines.append("── استاپ لاس ─────────────────────")
        lines.append(f"SL:     {sl:.{d}f}" if sl else "SL:     N/A")
        if sl and entry:
            lines.append(f"  فاصله از ورود: {risk_pips:.{d}f}  ({risk_pct:.2f}%)")
        lines.append(f"  منطق: {sl_desc}")
        lines.append(f"  شرط باطل شدن: {invalidation}")
        lines.append("")

        lines.append("── تارگت‌ها (سود) ────────────────")
        if tp1:
            lines.append(f"TP1:  {tp1:.{d}f}   (R:R = {rr1:.1f}x)")
            lines.append(f"  → اینجا نیمی از پوزیشن بسته شود")
        if tp2:
            lines.append(f"TP2:  {tp2:.{d}f}   (R:R = {rr2:.1f}x)")
            lines.append(f"  → SL به نقطه ورود منتقل شود (breakeven)")
        if tp3:
            lines.append(f"TP3:  {tp3:.{d}f}   (R:R = {rr3:.1f}x)")
            lines.append(f"  → باقی پوزیشن با trailing SL نگه داشته شود")
        lines.append("")

        lines.append("── اندیکاتورها ───────────────────")
        lines.append(f"RSI:         {rsi_val:.1f}  ({rsi_signal})")
        lines.append(f"MACD:        {macd_trend}")
        lines.append(f"EMA روند:    {ema_trend}")
        lines.append(f"EMA50:       {ema50:.{d}f}")
        lines.append(f"EMA200:      {ema200:.{d}f}")
        lines.append(f"Supertrend:  {supertrend}")
        lines.append(f"ADX:         {adx_val:.1f}  ({'روند قوی' if adx_val > 25 else 'روند ضعیف'})")
        lines.append(f"Stochastic:  {stoch_k:.1f}")
        lines.append(f"Bollinger:   {bb_signal}")
        lines.append("")

        lines.append("── ساختار بازار (SMC) ────────────")
        lines.append(f"روند کلی:    {ms_trend}")
        lines.append(f"BOS:         {'✅ تایید' if ms_bos else '❌ تایید نشده'}")
        lines.append(f"CHoCH:       {'✅ تایید' if ms_choch else '❌ تایید نشده'}")
        lines.append(f"ناحیه قیمت:  {premium_discount}")
        lines.append(f"Liq Sweep:   {'✅ بله' if liq_sweep else '❌ خیر'}")
        if ob_ref:
            lines.append(f"OB فعال:     {ob_ref['bottom']:.{d}f} - {ob_ref['top']:.{d}f}")
        if fvg_ref:
            lines.append(f"FVG فعال:    {fvg_ref['bottom']:.{d}f} - {fvg_ref['top']:.{d}f}")
        if nearest_support:
            lines.append(f"حمایت:       {nearest_support['price']:.{d}f}")
        if nearest_resistance:
            lines.append(f"مقاومت:      {nearest_resistance['price']:.{d}f}")
        if pivot_pp:
            lines.append(f"Pivot PP:    {pivot_pp:.{d}f}")
        lines.append("")

        lines.append("── دلایل اصلی سیگنال ────────────")
        for i, r in enumerate(reasons[:7], 1):
            lines.append(f"{i}. {r}")

        return "\n".join(lines)

    async def _process_analysis(self, query, context, user_id: int):
        state = self.user_states.get(user_id, {})
        menu = state.get("menu", "indicators")
        symbol = state.get("symbol", "XAUUSD")
        timeframe = state.get("timeframe", "1h")

        await query.edit_message_text(
            f"⏳ در حال تحلیل {symbol} در تایم فریم {TIMEFRAMES[timeframe]['display']}..."
        )

        try:
            df = self.data_fetcher.get_candles(symbol, timeframe, count=500)

            if df.empty:
                await context.bot.send_message(
                    chat_id=query.message.chat_id,
                    text="❌ خطا در دریافت داده‌ها. لطفا دوباره تلاش کنید.",
                    reply_markup=self.get_main_menu())
                return

            if menu == "subarashi":
                await self._send_subarashi_analysis(query, context, df, symbol,
                                                    timeframe)
            elif menu == "sniper":
                await self._send_sniper_analysis(query, context, df, symbol,
                                                 timeframe)
            elif menu == "indicators":
                await self._send_indicators_analysis(query, context, df,
                                                     symbol, timeframe)
            elif menu == "technical":
                await self._send_technical_analysis(query, context, df, symbol,
                                                    timeframe)
            elif menu == "smc":
                await self._send_smc_analysis(query, context, df, symbol,
                                              timeframe)
            elif menu == "ai":
                await self._send_ai_analysis(query, context, df, symbol,
                                             timeframe)
            elif menu == "fundamental":
                await self._send_fundamental_analysis(query, context, symbol)
            elif menu == "news":
                await self._send_news(query, context, symbol)
            elif menu == "crazy_bot":
                await self._send_crazy_bot_analysis(query, context, symbol)
            elif menu == "full":
                await self._send_full_analysis(query, context, df, symbol,
                                               timeframe)
            elif menu == "scanner":
                await self._send_scanner_analysis(query, context, timeframe)
            elif menu == "compare":
                symbol1 = state.get("compare_symbol1", "XAUUSD")
                await self._send_compare_analysis(query, context, symbol1,
                                                  symbol, timeframe)
            elif menu == "extra_ind":
                await self._send_extra_indicators_analysis(query, context, df,
                                                           symbol, timeframe)
            elif menu == "samadi":
                await self._send_samadi_analysis(query, context, df, symbol,
                                                 timeframe)
            else:
                await self._send_indicators_analysis(query, context, df,
                                                     symbol, timeframe)

        except Exception as e:
            logger.error(f"Error in analysis: {e}")
            await context.bot.send_message(
                chat_id=query.message.chat_id,
                text=f"❌ خطا در تحلیل: {str(e)}\n\nلطفا دوباره تلاش کنید.",
                reply_markup=self.get_main_menu())

    async def _send_long_message(self,
                                 context,
                                 chat_id,
                                 text: str,
                                 reply_markup=None):
        messages = []
        current_message = ""

        lines = text.split('\n')
        for line in lines:
            if len(current_message) + len(line) + 1 > MAX_MESSAGE_LENGTH:
                messages.append(current_message)
                current_message = line
            else:
                current_message += '\n' + line if current_message else line

        if current_message:
            messages.append(current_message)

        for i, msg in enumerate(messages):
            try:
                if i == len(messages) - 1 and reply_markup:
                    await context.bot.send_message(
                        chat_id=chat_id,
                        text=msg,
                        parse_mode=ParseMode.MARKDOWN,
                        reply_markup=reply_markup)
                else:
                    await context.bot.send_message(
                        chat_id=chat_id,
                        text=msg,
                        parse_mode=ParseMode.MARKDOWN)
                    await asyncio.sleep(0.5)
            except Exception as e:
                # If Markdown parsing fails, send as plain text
                logger.warning(
                    f"Markdown parsing failed, sending as plain text: {e}")
                if i == len(messages) - 1 and reply_markup:
                    await context.bot.send_message(chat_id=chat_id,
                                                   text=msg,
                                                   reply_markup=reply_markup)
                else:
                    await context.bot.send_message(chat_id=chat_id, text=msg)
                    await asyncio.sleep(0.5)

    async def _send_subarashi_analysis(self, query, context, df, symbol,
                                       timeframe):
        signal_gen = EntrySignalGenerator(df, symbol, timeframe)
        signal = signal_gen.generate_subarashi_signal()
        signal['entry_explanation'] = signal_gen.generate_detailed_entry_explanation(signal)

        try:
            # Generate detailed report with trading plan
            detailed_report = self.report_generator.generate_signal_report(
                signal, symbol, timeframe, "subarashi")

            # Send in chunks if too long
            await self._send_long_message(context, query.message.chat_id,
                                          detailed_report,
                                          self.get_main_menu())

        except Exception as e:
            logger.error(f"Error generating subarashi report: {e}",
                         exc_info=True)
            # Send a simplified fallback version
            def _fp_bot(p):
                if p is None: return 'N/A'
                try:
                    v = float(p)
                    if v >= 1000: return f"{v:.2f}"
                    elif v >= 100: return f"{v:.3f}"
                    elif v >= 10: return f"{v:.4f}"
                    return f"{v:.5f}"
                except Exception:
                    return 'N/A'

            sig_e = '🟢' if signal.get('signal_type') == 'LONG' else '🔴' if signal.get('signal_type') == 'SHORT' else '⚪'
            simplified_text = (
                f"🎯 ورود سوباراشی - {symbol} ({TIMEFRAMES[timeframe]['display']})\n\n"
                f"{sig_e} سیگنال: {signal.get('signal_type','N/A')}\n"
                f"اطمینان: {signal.get('confidence',0):.1f}%\n\n"
                f"ورود: {_fp_bot(signal.get('entry'))}\n"
                f"استاپ: {_fp_bot(signal.get('stop_loss'))}\n"
                f"TP1: {_fp_bot(signal.get('take_profit_1'))}\n"
                f"TP2: {_fp_bot(signal.get('take_profit_2'))}\n"
                f"TP3: {_fp_bot(signal.get('take_profit_3'))}\n\n"
                f"دلایل:\n"
            )
            for reason in signal.get('reasons', [])[:8]:
                simplified_text += f"• {reason}\n"

            await self._send_long_message(context, query.message.chat_id,
                                          simplified_text,
                                          self.get_main_menu())

    async def _send_sniper_analysis(self, query, context, df, symbol,
                                    timeframe):
        signal_gen = EntrySignalGenerator(df, symbol, timeframe)
        signal = signal_gen.generate_sniper_entry()
        signal['entry_explanation'] = signal_gen.generate_detailed_entry_explanation(signal)

        try:
            # Generate detailed report with comprehensive sniper trading plan
            detailed_report = self.report_generator.generate_signal_report(
                signal, symbol, timeframe, "sniper")

            # Send in chunks if too long (will handle 150+ lines)
            await self._send_long_message(context, query.message.chat_id,
                                          detailed_report,
                                          self.get_main_menu())

        except Exception as e:
            logger.error(f"Error generating sniper report: {e}", exc_info=True)
            # Fallback to simplified version
            entry_str = f"{signal['entry']:.5f}" if signal.get(
                'entry') else 'N/A'
            sl_str = f"{signal['stop_loss']:.5f}" if signal.get(
                'stop_loss') else 'N/A'
            tp1_str = f"{signal['take_profit_1']:.5f}" if signal.get(
                'take_profit_1') else 'N/A'
            tp2_str = f"{signal['take_profit_2']:.5f}" if signal.get(
                'take_profit_2') else 'N/A'
            tp3_str = f"{signal['take_profit_3']:.5f}" if signal.get(
                'take_profit_3') else 'N/A'
            risk_str = f"{signal['risk_percent']:.2f}" if signal.get(
                'risk_percent') else '0.00'

            text = f"""
🎪 **ورود اسنایپری - {symbol} ({TIMEFRAMES[timeframe]['display']})**

{'✅' if signal['is_sniper_entry'] else '❌'} **ورود اسنایپری:** {'تایید شد' if signal['is_sniper_entry'] else 'تایید نشد'}
🎯 **کیفیت:** {signal['sniper_quality']}
📊 **امتیاز اسنایپر:** {signal['sniper_score']}/100

{'🟢' if signal['signal_type'] == 'LONG' else '🔴' if signal['signal_type'] == 'SHORT' else '⚪'} **نوع پوزیشن:** {signal['signal_type']}
📊 **اعتماد:** {signal['confidence']:.1f}%

💰 **نقاط ورود و خروج:**
• Entry: {entry_str}
• SL: {sl_str}
• TP1: {tp1_str}
• TP2: {tp2_str}
• TP3: {tp3_str}

⚠️ **ریسک:** {risk_str}%

🎯 **شرایط اسنایپری:**
"""
            for condition in signal.get('sniper_conditions', []):
                text += f"✓ {condition}\n"

            text += f"\n🔍 **دلایل ورود:**\n"
            for reason in signal.get('reasons', [])[:8]:
                text += f"• {reason}\n"

            await self._send_long_message(context, query.message.chat_id, text,
                                          self.get_main_menu())

    async def _send_indicators_analysis(self, query, context, df, symbol,
                                        timeframe):
        ti = TechnicalIndicators(df)
        indicators = ti.calculate_all()

        text = f"""
📊 **تحلیل اندیکاتورها - {symbol} ({TIMEFRAMES[timeframe]['display']})**

💵 **قیمت فعلی:** {indicators['PRICE']['current']:.5f}
📈 **تغییر:** {indicators['PRICE']['change']:.2f}%

━━━━━━━━━━━━━━━━━━━━
📊 **اندیکاتورهای مومنتوم**
━━━━━━━━━━━━━━━━━━━━

**RSI ({indicators['RSI']['value']:.1f}):**
• سیگنال: {indicators['RSI']['signal']}
• {'🔴 اشباع خرید' if indicators['RSI']['overbought'] else '🟢 اشباع فروش' if indicators['RSI']['oversold'] else '⚪ عادی'}

**Stochastic:**
• K: {indicators['STOCHASTIC']['k']:.1f} | D: {indicators['STOCHASTIC']['d']:.1f}
• سیگنال: {indicators['STOCHASTIC']['signal']}

**CCI ({indicators['CCI']['value']:.1f}):**
• سیگنال: {indicators['CCI']['signal']}

**Williams %R ({indicators['WILLIAMS_R']['value']:.1f}):**
• سیگنال: {indicators['WILLIAMS_R']['signal']}

**ROC ({indicators['ROC']['value']:.2f}):**
• سیگنال: {indicators['ROC']['signal']}

━━━━━━━━━━━━━━━━━━━━
📈 **اندیکاتورهای روند**
━━━━━━━━━━━━━━━━━━━━

**MACD:**
• MACD: {indicators['MACD']['macd']:.5f}
• Signal: {indicators['MACD']['signal']:.5f}
• Histogram: {indicators['MACD']['histogram']:.5f}
• روند: {indicators['MACD']['trend']}

**EMA:**
• EMA 9: {indicators['EMA']['EMA_9']:.5f}
• EMA 21: {indicators['EMA']['EMA_21']:.5f}
• EMA 50: {indicators['EMA']['EMA_50']:.5f}
• EMA 200: {indicators['EMA']['EMA_200']:.5f}
• روند: {indicators['EMA']['trend']}

**SMA:**
• SMA 20: {indicators['SMA']['SMA_20']:.5f}
• SMA 50: {indicators['SMA']['SMA_50']:.5f}
• SMA 200: {indicators['SMA']['SMA_200']:.5f}
• روند: {indicators['SMA']['trend']}

**ADX ({indicators['ADX']['adx']:.1f}):**
• +DI: {indicators['ADX']['plus_di']:.1f}
• -DI: {indicators['ADX']['minus_di']:.1f}
• قدرت روند: {indicators['ADX']['trend_strength']}
• جهت: {indicators['ADX']['trend_direction']}

**Supertrend:**
• مقدار: {indicators['SUPERTREND']['value']:.5f}
• سیگنال: {indicators['SUPERTREND']['signal']}

**PSAR:**
• مقدار: {indicators['PSAR']['value']:.5f}
• سیگنال: {indicators['PSAR']['signal']}
"""

        text2 = f"""
━━━━━━━━━━━━━━━━━━━━
📉 **اندیکاتورهای نوسان**
━━━━━━━━━━━━━━━━━━━━

**Bollinger Bands:**
• Upper: {indicators['BOLLINGER']['upper']:.5f}
• Middle: {indicators['BOLLINGER']['middle']:.5f}
• Lower: {indicators['BOLLINGER']['lower']:.5f}
• Width: {indicators['BOLLINGER']['width']:.5f}
• سیگنال: {indicators['BOLLINGER']['signal']}

**ATR:**
• مقدار: {indicators['ATR']['value']:.5f}
• درصد: {indicators['ATR']['percent']:.2f}%

**Keltner Channel:**
• Upper: {indicators['KELTNER']['upper']:.5f}
• Middle: {indicators['KELTNER']['middle']:.5f}
• Lower: {indicators['KELTNER']['lower']:.5f}
• سیگنال: {indicators['KELTNER']['signal']}

**Donchian Channel:**
• Upper: {indicators['DONCHIAN']['upper']:.5f}
• Middle: {indicators['DONCHIAN']['middle']:.5f}
• Lower: {indicators['DONCHIAN']['lower']:.5f}
• سیگنال: {indicators['DONCHIAN']['signal']}

━━━━━━━━━━━━━━━━━━━━
📊 **اندیکاتورهای حجم**
━━━━━━━━━━━━━━━━━━━━

**OBV:**
• روند: {indicators['OBV']['trend']}

**MFI ({indicators['MFI'].get('value', 0):.1f}):**
• سیگنال: {indicators['MFI'].get('signal', 'N/A')}

**VWAP:**
• سیگنال: {indicators['VWAP'].get('signal', 'N/A')}

━━━━━━━━━━━━━━━━━━━━
📊 **خلاصه روند**
━━━━━━━━━━━━━━━━━━━━

• صعودی: {indicators['TREND_SUMMARY']['bullish_count']}
• نزولی: {indicators['TREND_SUMMARY']['bearish_count']}
• درصد صعودی: {indicators['TREND_SUMMARY']['bullish_percent']:.1f}%
• **نتیجه: {indicators['TREND_SUMMARY']['overall']}**
"""

        await self._send_long_message(context, query.message.chat_id, text)
        await self._send_long_message(context, query.message.chat_id, text2,
                                      self.get_main_menu())

    async def _send_technical_analysis(self, query, context, df, symbol,
                                       timeframe):
        pa = PatternAnalyzer(df)
        analysis = pa.analyze_all()

        text = f"""
📈 **تحلیل تکنیکال پیشرفته - {symbol} ({TIMEFRAMES[timeframe]['display']})**

━━━━━━━━━━━━━━━━━━━━
🕯 **الگوهای کندلی**
━━━━━━━━━━━━━━━━━━━━
"""
        patterns = analysis.get('candlestick_patterns', [])
        if patterns:
            for p in patterns[-8:]:
                emoji = '🟢' if p['type'] == 'BULLISH' else '🔴' if p[
                    'type'] == 'BEARISH' else '⚪'
                text += f"{emoji} {p['pattern']}: {p['description']}\n"
        else:
            text += "الگوی خاصی شناسایی نشد\n"

        text += f"""
━━━━━━━━━━━━━━━━━━━━
📊 **سطوح حمایت و مقاومت**
━━━━━━━━━━━━━━━━━━━━

💵 **قیمت فعلی:** {analysis['support_resistance']['current_price']:.5f}

🔴 **مقاومت‌ها:**
"""
        for r in analysis['support_resistance']['resistance_levels'][:5]:
            text += f"• {r['price']:.5f} (قدرت: {r['strength']})\n"

        text += "\n🟢 **حمایت‌ها:**\n"
        for s in analysis['support_resistance']['support_levels'][:5]:
            text += f"• {s['price']:.5f} (قدرت: {s['strength']})\n"

        nr = analysis['support_resistance'].get('nearest_resistance')
        ns = analysis['support_resistance'].get('nearest_support')
        if nr:
            text += f"\n🎯 **نزدیک‌ترین مقاومت:** {nr['price']:.5f}"
        if ns:
            text += f"\n🎯 **نزدیک‌ترین حمایت:** {ns['price']:.5f}"

        fib = analysis.get('fibonacci', {})
        text += f"""

━━━━━━━━━━━━━━━━━━━━
📐 **سطوح فیبوناچی**
━━━━━━━━━━━━━━━━━━━━

📈 **روند:** {'صعودی' if fib.get('is_uptrend') else 'نزولی'}
🔝 **Swing High:** {fib.get('swing_high', 0):.5f}
🔻 **Swing Low:** {fib.get('swing_low', 0):.5f}

**سطوح:**
"""
        for level, price in fib.get('levels', {}).items():
            text += f"• {level}: {price:.5f}\n"

        text += f"\n📍 **موقعیت فعلی:** {fib.get('current_zone', 'N/A')}"

        pivot = analysis.get('pivot_points', {})
        if pivot:
            std = pivot.get('standard', {})
            text += f"""

━━━━━━━━━━━━━━━━━━━━
🎯 **نقاط Pivot**
━━━━━━━━━━━━━━━━━━━━

**Standard Pivots:**
• R3: {std.get('r3', 0):.5f}
• R2: {std.get('r2', 0):.5f}
• R1: {std.get('r1', 0):.5f}
• Pivot: {std.get('pivot', 0):.5f}
• S1: {std.get('s1', 0):.5f}
• S2: {std.get('s2', 0):.5f}
• S3: {std.get('s3', 0):.5f}

📍 **موقعیت:** {pivot.get('position', 'N/A')}
"""

        breakouts = analysis.get('breakouts', [])
        if breakouts:
            text += "\n━━━━━━━━━━━━━━━━━━━━\n💥 **شکست‌های قیمتی**\n━━━━━━━━━━━━━━━━━━━━\n"
            for b in breakouts:
                emoji = '🟢' if b['signal'] == 'BULLISH' else '🔴'
                text += f"{emoji} {b['description']}\n"

        await self._send_long_message(context, query.message.chat_id, text,
                                      self.get_main_menu())

    async def _send_smc_analysis(self, query, context, df, symbol, timeframe):
        smc = SMCAnalyzer(df)
        analysis = smc.analyze_all()

        ms = analysis.get('market_structure', {})
        text = f"""
💎 **تحلیل Smart Money Concepts - {symbol} ({TIMEFRAMES[timeframe]['display']})**

━━━━━━━━━━━━━━━━━━━━
📊 **ساختار بازار**
━━━━━━━━━━━━━━━━━━━━

🎯 **روند:** {ms.get('trend', 'N/A')}
📝 **توضیح:** {ms.get('description', 'N/A')}
💪 **قدرت:** {ms.get('strength', 'N/A')}

• Higher Highs: {'✅' if ms.get('higher_highs') else '❌'}
• Higher Lows: {'✅' if ms.get('higher_lows') else '❌'}
• Lower Highs: {'✅' if ms.get('lower_highs') else '❌'}
• Lower Lows: {'✅' if ms.get('lower_lows') else '❌'}

━━━━━━━━━━━━━━━━━━━━
🔄 **BOS و CHoCH**
━━━━━━━━━━━━━━━━━━━━
"""
        for signal in analysis.get('bos_choch', [])[-5:]:
            emoji = '🟢' if signal['direction'] == 'BULLISH' else '🔴'
            text += f"{emoji} **{signal['type']}:** {signal['description']}\n"

        if not analysis.get('bos_choch'):
            text += "سیگنالی شناسایی نشد\n"

        text += "\n━━━━━━━━━━━━━━━━━━━━\n📊 **Fair Value Gaps (FVG)**\n━━━━━━━━━━━━━━━━━━━━\n"
        for fvg in analysis.get('fvg', [])[-5:]:
            emoji = '🟢' if fvg['type'] == 'BULLISH_FVG' else '🔴'
            text += f"{emoji} {fvg['description']}\n"
            text += f"   Top: {fvg['top']:.5f} | Bottom: {fvg['bottom']:.5f}\n"

        if not analysis.get('fvg'):
            text += "FVG فعالی وجود ندارد\n"

        text += "\n━━━━━━━━━━━━━━━━━━━━\n🧱 **Order Blocks**\n━━━━━━━━━━━━━━━━━━━━\n"
        for ob in analysis.get('order_blocks', [])[:5]:
            emoji = '🟢' if ob['type'] == 'BULLISH_OB' else '🔴'
            text += f"{emoji} {ob['description']}\n"
            text += f"   Top: {ob['top']:.5f} | Bottom: {ob['bottom']:.5f} | قدرت: {ob['strength']}\n"

        if not analysis.get('order_blocks'):
            text += "Order Block فعالی وجود ندارد\n"

        sd = analysis.get('supply_demand', {})
        text += f"""
━━━━━━━━━━━━━━━━━━━━
📦 **مناطق Supply/Demand**
━━━━━━━━━━━━━━━━━━━━

🔴 **Supply Zones:**
"""
        for zone in sd.get('supply_zones', [])[:3]:
            text += f"• {zone['bottom']:.5f} - {zone['top']:.5f} (قدرت: {zone['strength']})\n"

        text += "\n🟢 **Demand Zones:**\n"
        for zone in sd.get('demand_zones', [])[:3]:
            text += f"• {zone['bottom']:.5f} - {zone['top']:.5f} (قدرت: {zone['strength']})\n"

        pd_zone = analysis.get('premium_discount', {})
        text += f"""
━━━━━━━━━━━━━━━━━━━━
💎 **Premium/Discount**
━━━━━━━━━━━━━━━━━━━━

🔝 **Swing High:** {pd_zone.get('swing_high', 0):.5f}
🔻 **Swing Low:** {pd_zone.get('swing_low', 0):.5f}
⚖️ **Equilibrium:** {pd_zone.get('equilibrium', 0):.5f}

📍 **منطقه فعلی:** {pd_zone.get('current_zone', 'N/A')}
📝 **توضیح:** {pd_zone.get('zone_description', 'N/A')}

━━━━━━━━━━━━━━━━━━━━
💧 **Liquidity Sweeps**
━━━━━━━━━━━━━━━━━━━━
"""
        for liq in analysis.get('liquidity', [])[-5:]:
            emoji = '🟢' if liq['signal'] == 'BULLISH' else '🔴'
            text += f"{emoji} {liq['description']}\n"

        if not analysis.get('liquidity'):
            text += "Liquidity Sweep شناسایی نشد\n"

        await self._send_long_message(context, query.message.chat_id, text,
                                      self.get_main_menu())

    async def _send_ai_analysis(self, query, context, df, symbol, timeframe):
        ti = TechnicalIndicators(df)
        indicators = ti.calculate_all()
        smc = SMCAnalyzer(df)
        smc_data = smc.analyze_all()
        pa = PatternAnalyzer(df)
        patterns = pa.analyze_all()

        market_data = {
            'indicators': indicators,
            'smc': smc_data,
            'patterns': patterns
        }

        ai_result = self.ai_analyzer.analyze_with_ai(market_data, symbol,
                                                     timeframe)

        ml = ai_result.get('ml_prediction', {})
        regime = ai_result.get('market_regime', {})
        money = ai_result.get('smart_money_flow', {})
        whale = ai_result.get('whale_activity', {})
        reversal = ai_result.get('reversal_probability', {})
        combined = ai_result.get('combined_signal', {})
        confidence = ai_result.get('ai_confidence', {})

        text = f"""
🤖 **تحلیل هوش مصنوعی - {symbol} ({TIMEFRAMES[timeframe]['display']})**

━━━━━━━━━━━━━━━━━━━━
🎯 **سیگنال ترکیبی AI**
━━━━━━━━━━━━━━━━━━━━

{'🟢' if combined.get('direction') == 'BULLISH' else '🔴' if combined.get('direction') == 'BEARISH' else '⚪'} **جهت:** {combined.get('direction', 'N/A')}
📊 **اطمینان:** {combined.get('confidence', 0):.1f}%
💪 **سطح اطمینان:** {confidence.get('level', 'N/A')}
📐 **سایز توصیه شده:** {confidence.get('recommended_size', 'N/A')}

━━━━━━━━━━━━━━━━━━━━
🧠 **پیش‌بینی Machine Learning**
━━━━━━━━━━━━━━━━━━━━

{'🟢' if ml.get('direction') == 'BULLISH' else '🔴' if ml.get('direction') == 'BEARISH' else '⚪'} **جهت:** {ml.get('direction', 'N/A')}
📊 **اطمینان:** {ml.get('confidence', 0):.1f}%
💪 **قدرت روند:** {ml.get('trend_strength', 'N/A')}
📈 **امتیاز صعودی:** {ml.get('bullish_score', 0)}
📉 **امتیاز نزولی:** {ml.get('bearish_score', 0)}

━━━━━━━━━━━━━━━━━━━━
📊 **رژیم بازار**
━━━━━━━━━━━━━━━━━━━━

🎯 **رژیم:** {regime.get('regime', 'N/A')}
📝 **توضیح:** {regime.get('description', 'N/A')}
📈 **نوسان:** {regime.get('volatility', 'N/A')}
💡 **توصیه:** {regime.get('recommendation', 'N/A')}

━━━━━━━━━━━━━━━━━━━━
💰 **جریان پول هوشمند**
━━━━━━━━━━━━━━━━━━━━

🎯 **جریان:** {money.get('flow', 'N/A')}
📊 **امتیاز:** {money.get('score', 0)}/100
📝 **توضیح:** {money.get('description', 'N/A')}
🏛 **تمایل موسسات:** {money.get('institutional_bias', 'N/A')}

━━━━━━━━━━━━━━━━━━━━
🐋 **فعالیت نهنگ‌ها**
━━━━━━━━━━━━━━━━━━━━

📊 **سطح فعالیت:** {whale.get('activity_level', 'N/A')}
📈 **امتیاز:** {whale.get('activity_score', 0)}/100
🎯 **جهت نهنگ‌ها:** {whale.get('whale_direction', 'N/A')}

**سیگنال‌ها:**
"""
        for sig in whale.get('signals', [])[:5]:
            emoji = '🟢' if sig.get('signal') == 'BULLISH' else '🔴' if sig.get(
                'signal') == 'BEARISH' else '⚪'
            text += f"{emoji} {sig.get('type', '')}: {sig.get('description', '')}\n"

        text += f"""
━━━━━━━━━━━━━━━━━━━━
🔄 **احتمال برگشت**
━━━━━━━━━━━━━━━━━━━━

📊 **احتمال:** {reversal.get('probability', 'N/A')}
📈 **امتیاز:** {reversal.get('score', 0)}/100
🎯 **جهت مورد انتظار:** {reversal.get('expected_direction', 'N/A')}
📝 **توضیح:** {reversal.get('description', 'N/A')}

**سیگنال‌های برگشت:**
"""
        for sig in reversal.get('signals', [])[:5]:
            text += f"• {sig}\n"

        llm = ai_result.get('llm_analysis')
        if llm and llm.get('status') == 'success':
            text += f"""
━━━━━━━━━━━━━━━━━━━━
🤖 **تحلیل LLM (Llama-3)**
━━━━━━━━━━━━━━━━━━━━

{llm.get('analysis', 'N/A')}
"""

        await self._send_long_message(context, query.message.chat_id, text,
                                      self.get_main_menu())

    async def _send_fundamental_analysis(self, query, context, symbol):
        analysis = self.fundamental.analyze_all(symbol)

        sentiment = analysis.get('sentiment', {})
        events = analysis.get('economic_events', [])
        bank = analysis.get('central_bank', {})
        corr = analysis.get('correlations', {})
        whale = self.fundamental.get_whale_activity(symbol)
        money = self.fundamental.calculate_smart_money_flow(symbol)

        text = f"""
💼 **تحلیل فاندامنتال - {symbol}**

━━━━━━━━━━━━━━━━━━━━
📊 **احساسات بازار**
━━━━━━━━━━━━━━━━━━━━

🎯 **احساس کلی:** {sentiment.get('overall', 'N/A')}
📝 **توضیح:** {sentiment.get('description', 'N/A')}
📈 **صعودی:** {sentiment.get('bullish_percent', 0):.1f}%
📉 **نزولی:** {sentiment.get('bearish_percent', 0):.1f}%

━━━━━━━━━━━━━━━━━━━━
📅 **تقویم اقتصادی**
━━━━━━━━━━━━━━━━━━━━
"""
        for event in events[:5]:
            impact_emoji = '🔴' if event.get(
                'impact') == 'HIGH' else '🟡' if event.get(
                    'impact') == 'MEDIUM' else '🟢'
            text += f"{impact_emoji} **{event.get('currency', '')}** {event.get('event', '')}\n"
            text += f"   ⏰ {event.get('time', '')} | پیش‌بینی: {event.get('forecast', '')} | قبلی: {event.get('previous', '')}\n\n"

        if isinstance(bank, dict) and 'base_currency' in bank:
            base = bank.get('base_currency', {})
            quote = bank.get('quote_currency', {})
            text += f"""
━━━━━━━━━━━━━━━━━━━━
🏦 **بانک‌های مرکزی**
━━━━━━━━━━━━━━━━━━━━

**{base.get('currency', 'N/A')}:**
• نرخ بهره: {base.get('rate', 'N/A')}%
• بانک: {base.get('bank', 'N/A')}
• تمایل: {base.get('bias', 'N/A')}

**{quote.get('currency', 'N/A')}:**
• نرخ بهره: {quote.get('rate', 'N/A')}%
• بانک: {quote.get('bank', 'N/A')}
• تمایل: {quote.get('bias', 'N/A')}

📊 **اختلاف نرخ:** {bank.get('rate_differential', 0):.2f}%
"""

        if isinstance(corr, dict) and 'description' in corr:
            text += f"""
━━━━━━━━━━━━━━━━━━━━
🔗 **همبستگی‌ها**
━━━━━━━━━━━━━━━━━━━━

📝 {corr.get('description', 'N/A')}

"""
            for key, value in corr.items():
                if key != 'description' and isinstance(value, (int, float)):
                    emoji = '🟢' if value > 0 else '🔴'
                    text += f"{emoji} {key}: {value:.2f}\n"

        text += f"""
━━━━━━━━━━━━━━━━━━━━
🐋 **فعالیت نهنگ‌ها**
━━━━━━━━━━━━━━━━━━━━

🎯 **نوع:** {whale.get('type', 'N/A')}
📝 **توضیح:** {whale.get('description', 'N/A')}
{'🟢' if whale.get('signal') == 'BULLISH' else '🔴' if whale.get('signal') == 'BEARISH' else '⚪'} **سیگنال:** {whale.get('signal', 'N/A')}

**جزئیات:**
"""
        for detail in whale.get('details', []):
            text += f"• {detail}\n"

        text += f"""
━━━━━━━━━━━━━━━━━━━━
💰 **جریان پول هوشمند**
━━━━━━━━━━━━━━━━━━━━

📊 **MFI:** {money.get('money_flow_index', 0):.1f}
🎯 **انباشت/توزیع:** {money.get('accumulation_distribution', 'N/A')}
📈 **تمایل موسسات:** {money.get('institutional_bias', 'N/A')}
👥 **احساس خرده‌فروشان:** {money.get('retail_sentiment', 'N/A')}
⚠️ **واگرایی:** {'بله' if money.get('smart_money_divergence') else 'خیر'}
💡 **توصیه:** {money.get('recommendation', 'N/A')}
"""

        await self._send_long_message(context, query.message.chat_id, text,
                                      self.get_main_menu())

    async def _send_news(self, query, context, symbol):
        news = self.fundamental.fetch_news(symbol, limit=15)
        sentiment = self.fundamental.analyze_sentiment(news)

        text = f"""
📰 **اخبار و تحلیل احساسات - {symbol}**

━━━━━━━━━━━━━━━━━━━━
📊 **خلاصه احساسات**
━━━━━━━━━━━━━━━━━━━━

🎯 **احساس کلی:** {sentiment.get('overall', 'N/A')}
📈 **صعودی:** {sentiment.get('bullish_count', 0)} خبر ({sentiment.get('bullish_percent', 0):.1f}%)
📉 **نزولی:** {sentiment.get('bearish_count', 0)} خبر ({sentiment.get('bearish_percent', 0):.1f}%)
⚪ **خنثی:** {sentiment.get('neutral_count', 0)} خبر

━━━━━━━━━━━━━━━━━━━━
📰 **آخرین اخبار**
━━━━━━━━━━━━━━━━━━━━
"""

        for item in sentiment.get('analyzed_news', [])[:12]:
            emoji = '🟢' if item.get(
                'sentiment') == 'BULLISH' else '🔴' if item.get(
                    'sentiment') == 'BEARISH' else '⚪'
            text += f"\n{emoji} **{item.get('title', 'N/A')[:80]}**\n"
            text += f"📝 {item.get('summary', 'N/A')[:150]}...\n"
            text += f"🔗 منبع: {item.get('source', 'N/A')}\n"

        await self._send_long_message(context, query.message.chat_id, text,
                                      self.get_main_menu())

    async def _send_crazy_bot_analysis(self, query, context, symbol):
        """تحلیل چند تایم‌فریمی با دقت 100%"""

        await query.edit_message_text(
            f"🔥 **ربات دیوانه در حال تحلیل {symbol}...**\n\n"
            "⏳ مرحله 1/4: تحلیل تایم فریم 4 ساعته...")

        try:
            mtf = MultiTimeframeAnalyzer(symbol)
            result = mtf.analyze_mtf()

            if not result['valid']:
                text = f"""
🔥 **ربات دیوانه - {symbol}**

❌ **سیگنال معتبر یافت نشد**

**دلیل:** {result['reason']}

💡 **توصیه:** منتظر بمانید تا شرایط مناسب فراهم شود. این ربات فقط سیگنال‌های با اطمینان بالای 95% را می‌دهد.
"""
                await self._send_long_message(context, query.message.chat_id,
                                              text, self.get_main_menu())
                return

            signal = result['signal']

            # ایجاد گزارش کامل
            text = f"""
╔══════════════════════════════════════════════════════════════════╗
║       🔥 ربات دیوانه - ورود 100% دقیق 🔥                        ║
║       {symbol}                                                    ║
║       {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}                               ║
╚══════════════════════════════════════════════════════════════════╝

{'🟢' if signal['direction'] == 'LONG' else '🔴'} **نوع پوزیشن:** {signal['direction']}
📊 **اطمینان:** {signal['confidence']:.1f}% {'✅' if signal['confidence'] >= 95 else '⚠️'}
⭐ **Risk/Reward:** 1:{signal['risk_reward']:.2f}

━━━━━━━━━━━━━━━━━━━━━━━━━━
💰 **نقاط ورود و خروج دقیق**
━━━━━━━━━━━━━━━━━━━━━━━━━━

🎯 **Entry:** {signal['entry']:.5f}
🛑 **Stop Loss:** {signal['stop_loss']:.5f}
🎯 **TP1:** {signal['take_profit_1']:.5f}
🎯 **TP2:** {signal['take_profit_2']:.5f}
🎯 **TP3:** {signal['take_profit_3']:.5f}

━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 **تحلیل چند تایم‌فریمی**
━━━━━━━━━━━━━━━━━━━━━━━━━━

**مرحله 1 - تایم فریم 4 ساعته:**
• روند: {signal['timeframe_alignment']['4h']}
• قدرت: {signal['strength_scores']['4h']}/100

**مرحله 2 - تایم فریم 1 ساعته:**
• روند: {signal['timeframe_alignment']['1h']}
• قدرت: {signal['strength_scores']['1h']}/100

**مرحله 3 - تایم فریم 15 دقیقه:**
• روند: {signal['timeframe_alignment']['15m']}
• قدرت: {signal['strength_scores']['15m']}/100

**مرحله 4 - تایم فریم 5 دقیقه:**
• روند: {signal['timeframe_alignment']['5m']}
• قدرت: {signal['strength_scores']['5m']}/100

━━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 **دلایل ورود (فیلتر شده)**
━━━━━━━━━━━━━━━━━━━━━━━━━━
"""

            for i, reason in enumerate(signal['reasons'][:15], 1):
                text += f"\n{i}. {reason}"

            text += f"""

━━━━━━━━━━━━━━━━━━━━━━━━━━
📋 **راهنمای معامله**
━━━━━━━━━━━━━━━━━━━━━━━━━━

**مرحله 1:** منتظر بمانید تا قیمت به {signal['entry']:.5f} برسد

**مرحله 2:** {'لانگ' if signal['direction'] == 'LONG' else 'شورت'} باز کنید

**مرحله 3:** استاپ لاس را روی {signal['stop_loss']:.5f} قرار دهید

**مرحله 4:** تارگت‌ها:
• TP1 ({signal['take_profit_1']:.5f}): 30% پوزیشن ببندید
• TP2 ({signal['take_profit_2']:.5f}): 40% پوزیشن ببندید
• TP3 ({signal['take_profit_3']:.5f}): 30% پوزیشن ببندید

**مرحله 5:** بعد از رسیدن به TP1، استاپ را به Break Even ببرید

━━━━━━━━━━━━━━━━━━━━━━━━━━
⚠️ **نکات مهم**
━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ این سیگنال با تحلیل 20+ اندیکاتور در 4 تایم‌فریم تولید شده
✅ همه سطوح کلیدی SMC بررسی شده‌اند
✅ ساختار بازار در همه تایم‌فریم‌ها همراستا است
✅ Risk/Reward عالی ({signal['risk_reward']:.2f})
✅ اطمینان {signal['confidence']:.1f}% - بالاترین سطح

⚠️ حتما از مدیریت سرمایه استفاده کنید
⚠️ بیش از 2-3% سرمایه ریسک نکنید
⚠️ در صورت تغییر شرایط، خارج شوید

━━━━━━━━━━━━━━━━━━━━━━━━━━
"""

            await self._send_long_message(context, query.message.chat_id, text,
                                          self.get_main_menu())

        except Exception as e:
            logger.error(f"Error in crazy bot analysis: {e}", exc_info=True)
            await context.bot.send_message(
                chat_id=query.message.chat_id,
                text=f"❌ خطا در تحلیل: {str(e)}\n\nلطفا دوباره تلاش کنید.",
                reply_markup=self.get_main_menu())

    async def _send_full_analysis(self, query, context, df, symbol, timeframe):
        await self._send_subarashi_analysis(query, context, df, symbol,
                                            timeframe)
        await asyncio.sleep(1)
        await self._send_indicators_analysis(query, context, df, symbol,
                                             timeframe)
        await asyncio.sleep(1)
        await self._send_smc_analysis(query, context, df, symbol, timeframe)
        await asyncio.sleep(1)
        await self._send_ai_analysis(query, context, df, symbol, timeframe)

    async def send_prices(self, update: Update,
                          context: ContextTypes.DEFAULT_TYPE):
        prices = self.data_fetcher.get_all_prices()

        text = "💰 **قیمت‌های فعلی**\n\n"

        text += "**فارکس:**\n"
        for symbol in SYMBOLS["forex"].keys():
            if symbol in prices:
                p = prices[symbol]
                text += f"• {symbol}: {p.get('mid', 0):.5f} (Spread: {p.get('spread', 0):.5f})\n"

        text += "\n**کریپتو:**\n"
        for symbol in SYMBOLS["crypto"].keys():
            if symbol in prices:
                p = prices[symbol]
                text += f"• {symbol}: ${p.get('mid', 0):,.2f}\n"

        text += f"\n⏰ آخرین به‌روزرسانی: {datetime.now().strftime('%H:%M:%S')}"

        if update.callback_query:
            await self._send_long_message(
                context, update.callback_query.message.chat_id, text,
                self.get_main_menu())
        else:
            await update.message.reply_text(text,
                                            parse_mode=ParseMode.MARKDOWN,
                                            reply_markup=self.get_main_menu())


    async def _send_scanner_analysis(self, query, context, timeframe: str):
        all_symbols = list(SYMBOLS["forex"].keys()) + list(SYMBOLS["crypto"].keys())
        text = f"📡 اسکنر بازار - {TIMEFRAMES[timeframe]['display']}\n"
        text += f"⏰ {datetime.now().strftime('%H:%M:%S')}\n"
        text += "=" * 40 + "\n\n"
        results = []
        for sym in all_symbols:
            try:
                df = self.data_fetcher.get_candles(sym, timeframe, count=200)
                if df.empty:
                    continue
                signal_gen = EntrySignalGenerator(df, sym, timeframe)
                signal = signal_gen.generate_subarashi_signal()
                results.append({
                    "symbol": sym,
                    "signal_type": signal["signal_type"],
                    "confidence": signal["confidence"],
                    "bullish": signal["bullish_score"],
                    "bearish": signal["bearish_score"],
                    "entry": signal.get("entry"),
                    "sl": signal.get("stop_loss"),
                    "tp1": signal.get("take_profit_1"),
                })
            except Exception as e:
                logger.warning(f"Scanner error for {sym}: {e}")

        longs = [r for r in results if r["signal_type"] == "LONG"]
        shorts = [r for r in results if r["signal_type"] == "SHORT"]
        neutrals = [r for r in results if r["signal_type"] == "NEUTRAL"]

        if longs:
            text += "🟢 سیگنال LONG:\n"
            for r in sorted(longs, key=lambda x: x["confidence"], reverse=True):
                entry_str = f"{r['entry']:.5f}" if r["entry"] else "N/A"
                sl_str = f"{r['sl']:.5f}" if r["sl"] else "N/A"
                tp1_str = f"{r['tp1']:.5f}" if r["tp1"] else "N/A"
                text += f"  {r['symbol']}: {r['confidence']:.0f}% | Entry:{entry_str} SL:{sl_str} TP:{tp1_str}\n"
            text += "\n"

        if shorts:
            text += "🔴 سیگنال SHORT:\n"
            for r in sorted(shorts, key=lambda x: x["confidence"], reverse=True):
                entry_str = f"{r['entry']:.5f}" if r["entry"] else "N/A"
                sl_str = f"{r['sl']:.5f}" if r["sl"] else "N/A"
                tp1_str = f"{r['tp1']:.5f}" if r["tp1"] else "N/A"
                text += f"  {r['symbol']}: {r['confidence']:.0f}% | Entry:{entry_str} SL:{sl_str} TP:{tp1_str}\n"
            text += "\n"

        if neutrals:
            text += "⚪ بدون سیگنال:\n"
            for r in neutrals:
                text += f"  {r['symbol']}\n"

        text += f"\nمجموع: {len(longs)} LONG | {len(shorts)} SHORT | {len(neutrals)} بی‌طرف"
        await self._send_long_message(context, query.message.chat_id, text, self.get_main_menu())

    async def _send_mtf_analysis(self, query, context, symbol: str):
        text = f"📊 تحلیل چند تایم‌فریم - {symbol}\n"
        text += f"⏰ {datetime.now().strftime('%H:%M:%S')}\n"
        text += "=" * 40 + "\n\n"
        signals_summary = []
        for tf, tf_info in TIMEFRAMES.items():
            try:
                df = self.data_fetcher.get_candles(symbol, tf, count=200)
                if df.empty:
                    text += f"{tf_info['display']}: داده در دسترس نیست\n"
                    continue
                signal_gen = EntrySignalGenerator(df, symbol, tf)
                signal = signal_gen.generate_subarashi_signal()
                sig_emoji = "🟢" if signal["signal_type"] == "LONG" else "🔴" if signal["signal_type"] == "SHORT" else "⚪"
                entry_str = f"{signal['entry']:.5f}" if signal.get("entry") else "N/A"
                sl_str = f"{signal['stop_loss']:.5f}" if signal.get("stop_loss") else "N/A"
                tp1_str = f"{signal['take_profit_1']:.5f}" if signal.get("take_profit_1") else "N/A"
                text += f"{sig_emoji} {tf_info['display']} ({tf}):\n"
                text += f"  سیگنال: {signal['signal_type']} | اعتماد: {signal['confidence']:.0f}%\n"
                text += f"  Entry: {entry_str} | SL: {sl_str} | TP1: {tp1_str}\n"
                top_reasons = signal.get("reasons", [])[:2]
                for r in top_reasons:
                    text += f"  - {r}\n"
                text += "\n"
                signals_summary.append(signal["signal_type"])
            except Exception as e:
                logger.warning(f"MTF error for {tf}: {e}")
                text += f"{tf_info['display']}: خطا در تحلیل\n\n"

        bull_count = signals_summary.count("LONG")
        bear_count = signals_summary.count("SHORT")
        text += "=" * 40 + "\n"
        text += f"خلاصه: {bull_count} تایم‌فریم صعودی | {bear_count} تایم‌فریم نزولی\n"
        if bull_count > bear_count:
            text += "نتیجه کلی: روند اصلی صعودی است"
        elif bear_count > bull_count:
            text += "نتیجه کلی: روند اصلی نزولی است"
        else:
            text += "نتیجه کلی: بازار در تعادل است"
        await self._send_long_message(context, query.message.chat_id, text, self.get_main_menu())

    async def _send_sentiment_analysis(self, query, context):
        all_symbols = list(SYMBOLS["forex"].keys()) + list(SYMBOLS["crypto"].keys())
        total_bull = 0
        total_bear = 0
        symbol_data = []
        for sym in all_symbols:
            try:
                df = self.data_fetcher.get_candles(sym, "1h", count=100)
                if df.empty:
                    continue
                signal_gen = EntrySignalGenerator(df, sym, "1h")
                signal = signal_gen.generate_subarashi_signal()
                total_bull += signal["bullish_score"]
                total_bear += signal["bearish_score"]
                symbol_data.append({
                    "symbol": sym,
                    "bull": signal["bullish_score"],
                    "bear": signal["bearish_score"],
                    "type": signal["signal_type"],
                    "confidence": signal["confidence"]
                })
            except Exception as e:
                logger.warning(f"Sentiment error for {sym}: {e}")

        total = total_bull + total_bear
        bull_pct = (total_bull / total * 100) if total > 0 else 50
        bear_pct = (total_bear / total * 100) if total > 0 else 50

        if bull_pct >= 70:
            sentiment = "طمع شدید (Extreme Greed)"
            sentiment_emoji = "🔥"
            bar = "🟢" * 8 + "🔴" * 2
        elif bull_pct >= 55:
            sentiment = "طمع (Greed)"
            sentiment_emoji = "😄"
            bar = "🟢" * 6 + "🔴" * 4
        elif bull_pct >= 45:
            sentiment = "خنثی (Neutral)"
            sentiment_emoji = "😐"
            bar = "🟢" * 5 + "🔴" * 5
        elif bull_pct >= 30:
            sentiment = "ترس (Fear)"
            sentiment_emoji = "😨"
            bar = "🟢" * 3 + "🔴" * 7
        else:
            sentiment = "ترس شدید (Extreme Fear)"
            sentiment_emoji = "🆘"
            bar = "🟢" * 1 + "🔴" * 9

        text = f"🌡️ سنجش احساسات بازار\n"
        text += f"⏰ {datetime.now().strftime('%H:%M:%S')}\n"
        text += "=" * 40 + "\n\n"
        text += f"{sentiment_emoji} احساسات کلی: {sentiment}\n\n"
        text += f"صعودی: {bull_pct:.1f}%  |  نزولی: {bear_pct:.1f}%\n"
        text += f"{bar}\n\n"
        text += "جزییات هر نماد:\n"
        for sd in symbol_data:
            sig_emoji = "🟢" if sd["type"] == "LONG" else "🔴" if sd["type"] == "SHORT" else "⚪"
            text += f"  {sig_emoji} {sd['symbol']}: {sd['type']} ({sd['confidence']:.0f}%) | صعودی:{sd['bull']} نزولی:{sd['bear']}\n"
        text += f"\nتعداد نمادهای تحلیل‌شده: {len(symbol_data)}"
        await self._send_long_message(context, query.message.chat_id, text, self.get_main_menu())

    async def _send_compare_analysis(self, query, context, symbol1: str, symbol2: str, timeframe: str):
        text = f"🔀 مقایسه نمادها - {TIMEFRAMES[timeframe]['display']}\n"
        text += f"⏰ {datetime.now().strftime('%H:%M:%S')}\n"
        text += "=" * 40 + "\n\n"
        signals = {}
        for sym in [symbol1, symbol2]:
            try:
                df = self.data_fetcher.get_candles(sym, timeframe, count=200)
                if df.empty:
                    signals[sym] = None
                    continue
                signal_gen = EntrySignalGenerator(df, sym, timeframe)
                signal = signal_gen.generate_subarashi_signal()
                ti = TechnicalIndicators(df)
                ind = ti.calculate_all()
                signals[sym] = {"signal": signal, "indicators": ind}
            except Exception as e:
                logger.warning(f"Compare error for {sym}: {e}")
                signals[sym] = None

        for sym in [symbol1, symbol2]:
            data = signals.get(sym)
            text += f"{'='*20}\n{sym}\n{'='*20}\n"
            if not data:
                text += "داده در دسترس نیست\n\n"
                continue
            sig = data["signal"]
            ind = data["indicators"]
            sig_emoji = "🟢" if sig["signal_type"] == "LONG" else "🔴" if sig["signal_type"] == "SHORT" else "⚪"
            entry_str = f"{sig['entry']:.5f}" if sig.get("entry") else "N/A"
            sl_str = f"{sig['stop_loss']:.5f}" if sig.get("stop_loss") else "N/A"
            tp1_str = f"{sig['take_profit_1']:.5f}" if sig.get("take_profit_1") else "N/A"
            tp2_str = f"{sig['take_profit_2']:.5f}" if sig.get("take_profit_2") else "N/A"
            text += f"{sig_emoji} سیگنال: {sig['signal_type']} | اعتماد: {sig['confidence']:.0f}%\n"
            text += f"قیمت: {sig.get('current_price', 0):.5f}\n"
            text += f"Entry: {entry_str}\n"
            text += f"SL: {sl_str}\n"
            text += f"TP1: {tp1_str} | TP2: {tp2_str}\n"
            text += f"ریسک: {sig.get('risk_percent', 0):.2f}%\n"
            rsi_val = ind.get("RSI", {}).get("value", 0)
            macd_trend = ind.get("MACD", {}).get("trend", "N/A")
            ema_trend = ind.get("EMA", {}).get("trend", "N/A")
            text += f"RSI: {rsi_val:.1f} | MACD: {macd_trend} | EMA: {ema_trend}\n"
            top_reasons = sig.get("reasons", [])[:3]
            text += "دلایل:\n"
            for r in top_reasons:
                text += f"  - {r}\n"
            text += "\n"

        text += "=" * 40 + "\n"
        d1 = signals.get(symbol1)
        d2 = signals.get(symbol2)
        if d1 and d2:
            c1 = d1["signal"]["confidence"]
            c2 = d2["signal"]["confidence"]
            winner = symbol1 if c1 >= c2 else symbol2
            text += f"برنده مقایسه: {winner} (اعتماد بالاتر: {max(c1,c2):.0f}%)"
        await self._send_long_message(context, query.message.chat_id, text, self.get_main_menu())

    async def _send_extra_indicators_analysis(self, query, context, df, symbol: str, timeframe: str):
        ti = TechnicalIndicators(df)
        indicators = ti.calculate_all()
        text = f"➕ اندیکاتورهای اضافی - {symbol} ({TIMEFRAMES[timeframe]['display']})\n"
        text += f"⏰ {datetime.now().strftime('%H:%M:%S')}\n"
        text += "=" * 40 + "\n\n"

        ich = indicators.get("ICHIMOKU", {})
        if ich:
            text += "☁️ Ichimoku Cloud:\n"
            text += f"  Tenkan-sen: {ich.get('tenkan', 0):.5f}\n"
            text += f"  Kijun-sen: {ich.get('kijun', 0):.5f}\n"
            text += f"  Senkou A: {ich.get('senkou_a', 0):.5f}\n"
            text += f"  Senkou B: {ich.get('senkou_b', 0):.5f}\n"
            text += f"  سیگنال: {ich.get('signal', 'N/A')}\n\n"

        psar = indicators.get("PSAR", {})
        if psar:
            text += "🔵 Parabolic SAR:\n"
            text += f"  مقدار: {psar.get('value', 0):.5f}\n"
            text += f"  سیگنال: {psar.get('signal', 'N/A')}\n\n"

        st = indicators.get("SUPERTREND", {})
        if st:
            text += "⚡ Supertrend:\n"
            text += f"  مقدار: {st.get('value', 0):.5f}\n"
            text += f"  سیگنال: {st.get('signal', 'N/A')}\n\n"

        kc = indicators.get("KELTNER", {})
        if kc:
            text += "📐 Keltner Channel:\n"
            text += f"  بالا: {kc.get('upper', 0):.5f}\n"
            text += f"  میانه: {kc.get('middle', 0):.5f}\n"
            text += f"  پایین: {kc.get('lower', 0):.5f}\n"
            text += f"  سیگنال: {kc.get('signal', 'N/A')}\n\n"

        dc = indicators.get("DONCHIAN", {})
        if dc:
            text += "📏 Donchian Channel:\n"
            text += f"  بالا: {dc.get('upper', 0):.5f}\n"
            text += f"  میانه: {dc.get('middle', 0):.5f}\n"
            text += f"  پایین: {dc.get('lower', 0):.5f}\n\n"

        vwap = indicators.get("VWAP", {})
        if vwap:
            text += "💹 VWAP:\n"
            text += f"  مقدار: {vwap.get('value', 0):.5f}\n"
            text += f"  سیگنال: {vwap.get('signal', 'N/A')}\n\n"

        obv = indicators.get("OBV", {})
        if obv:
            text += "📦 OBV (On Balance Volume):\n"
            text += f"  مقدار: {obv.get('value', 0):.0f}\n"
            text += f"  روند: {obv.get('trend', 'N/A')}\n\n"

        mfi = indicators.get("MFI", {})
        if mfi:
            text += "💰 MFI (Money Flow Index):\n"
            text += f"  مقدار: {mfi.get('value', 0):.1f}\n"
            text += f"  سیگنال: {mfi.get('signal', 'N/A')}\n"
            text += f"  {'🔴 اشباع خرید' if mfi.get('overbought') else '🟢 اشباع فروش' if mfi.get('oversold') else '⚪ عادی'}\n\n"

        atr = indicators.get("ATR", {})
        if atr:
            text += "📊 ATR (نوسان بازار):\n"
            text += f"  مقدار: {atr.get('value', 0):.5f}\n"
            text += f"  سطح نوسان: {atr.get('volatility', 'N/A')}\n\n"

        pivot = indicators.get("PIVOT", {})
        if pivot:
            text += "📌 نقاط Pivot:\n"
            text += f"  PP: {pivot.get('PP', 0):.5f}\n"
            text += f"  R1: {pivot.get('R1', 0):.5f} | R2: {pivot.get('R2', 0):.5f}\n"
            text += f"  S1: {pivot.get('S1', 0):.5f} | S2: {pivot.get('S2', 0):.5f}\n"

        await self._send_long_message(context, query.message.chat_id, text, self.get_main_menu())

    async def _send_all_entries_analysis(self, query, context):
        all_symbols = list(SYMBOLS["forex"].keys()) + list(SYMBOLS["crypto"].keys())
        key_timeframes = ["15m", "1h", "4h", "daily"]

        header = (
            "🎯 نقطه ورود همه نمادها 100%\n"
            f"⏰ {datetime.now().strftime('%Y-%m-%d  %H:%M:%S')}\n"
            "═" * 38 + "\n"
            "فقط سیگنال‌های LONG/SHORT با اعتماد بالا نمایش داده می‌شوند\n"
            "═" * 38
        )

        found_any = False
        all_parts = [header]

        for symbol in all_symbols:
            symbol_signals = []
            for tf in key_timeframes:
                try:
                    df = self.data_fetcher.get_candles(symbol, tf, count=500)
                    if df is None or df.empty:
                        continue
                    signal_gen = EntrySignalGenerator(df, symbol, tf)
                    signal = signal_gen.generate_subarashi_signal()
                    if signal.get('signal_type') in ('LONG', 'SHORT'):
                        report_block = self._format_entry_report(signal, symbol, tf)
                        symbol_signals.append(report_block)
                        found_any = True
                except Exception as e:
                    logger.error(f"Error in all_entries for {symbol} {tf}: {e}")
                    continue
                await asyncio.sleep(0.2)

            if symbol_signals:
                sym_emoji = "🥇" if "XAU" in symbol else "₿" if symbol in ("BTCUSD", "XRPUSD") else "💱"
                sym_header = f"\n\n{'█'*38}\n{sym_emoji}  {symbol}\n{'█'*38}"
                all_parts.append(sym_header + "\n".join(symbol_signals))

        if not found_any:
            all_parts.append(
                "\n\n⚠️ در حال حاضر هیچ سیگنال قوی یافت نشد.\n"
                "بازار در وضعیت خنثی است.\n"
                "پیشنهاد: صبر کنید تا بازار جهت مشخصی بگیرد."
            )

        full_text = "\n".join(all_parts)
        await self._send_long_message(
            context, query.message.chat_id, full_text, self.get_main_menu()
        )

    async def _send_samadi_analysis(self, query, context, df, symbol: str, timeframe: str):
        try:
            from indicators.technical_indicators import TechnicalIndicators
            from analysis.smc_analyzer import SMCAnalyzer
            from analysis.pattern_analyzer import PatternAnalyzer

            ti = TechnicalIndicators(df)
            ind = ti.calculate_all()
            smc_obj = SMCAnalyzer(df)
            smc = smc_obj.analyze_all()
            pat_obj = PatternAnalyzer(df)
            patterns = pat_obj.analyze_all()

            current_price = float(df['close'].iloc[-1])
            atr = float(ind.get('ATR', {}).get('value', current_price * 0.01) or current_price * 0.01)
            d = self._price_decimals(current_price)
            tf_display = TIMEFRAMES.get(timeframe, {}).get('display', timeframe)

            ema = ind.get('EMA', {})
            ema50 = float(ema.get('EMA_50', current_price) or current_price)
            ema200 = float(ema.get('EMA_200', current_price) or current_price)
            ema_trend = ema.get('trend', '')

            rsi_val = float(ind.get('RSI', {}).get('value', 50) or 50)
            rsi_oversold = ind.get('RSI', {}).get('oversold', False)
            rsi_overbought = ind.get('RSI', {}).get('overbought', False)
            macd_trend = ind.get('MACD', {}).get('trend', '')
            stoch_k = float(ind.get('STOCHASTIC', {}).get('k', 50) or 50)
            stoch_oversold = ind.get('STOCHASTIC', {}).get('oversold', False)
            stoch_overbought = ind.get('STOCHASTIC', {}).get('overbought', False)
            adx_val = float(ind.get('ADX', {}).get('adx', 0) or 0)
            adx_dir = ind.get('ADX', {}).get('trend_direction', '')
            supertrend_sig = ind.get('SUPERTREND', {}).get('signal', '')
            bb_sig = ind.get('BOLLINGER', {}).get('signal', '')
            pivot_pp = float(ind.get('PIVOT', {}).get('PP', 0) or 0)
            pivot_r1 = float(ind.get('PIVOT', {}).get('R1', 0) or 0)
            pivot_s1 = float(ind.get('PIVOT', {}).get('S1', 0) or 0)

            ms = smc.get('market_structure', {})
            ms_trend = ms.get('trend', '')
            ms_bos = ms.get('recent_bos', 0) > 0
            ms_choch = ms.get('recent_choch', 0) > 0

            ob_bull = [ob for ob in smc.get('order_blocks', []) if ob.get('type') == 'BULLISH_OB']
            ob_bear = [ob for ob in smc.get('order_blocks', []) if ob.get('type') == 'BEARISH_OB']
            fvg_bull = [f for f in smc.get('fvg', []) if f.get('type') == 'BULLISH_FVG' and not f.get('filled', True)]
            fvg_bear = [f for f in smc.get('fvg', []) if f.get('type') == 'BEARISH_FVG' and not f.get('filled', True)]
            nearest_demand = smc.get('supply_demand', {}).get('nearest_demand')
            nearest_supply = smc.get('supply_demand', {}).get('nearest_supply')
            pd_data = smc.get('premium_discount', {})
            pd_zone = pd_data.get('current_zone', pd_data.get('zone', ''))
            equil = float(pd_data.get('equilibrium', current_price) or current_price)
            liq_list = smc.get('liquidity', [])
            liq_list = liq_list if isinstance(liq_list, list) else []

            nearest_sup = patterns.get('support_resistance', {}).get('nearest_support')
            nearest_res = patterns.get('support_resistance', {}).get('nearest_resistance')

            # ─── قانون ۱: روند کلی ───
            long_trend_ok = current_price > ema50 and current_price > ema200
            short_trend_ok = current_price < ema50 and current_price < ema200
            if long_trend_ok:
                rule1_long = True; rule1_short = False
                rule1_detail = f"قیمت ({current_price:.{d}f}) بالای EMA50 ({ema50:.{d}f}) و EMA200 ({ema200:.{d}f})"
                rule1_note = "روند اصلی صعودی تایید است"
            elif short_trend_ok:
                rule1_long = False; rule1_short = True
                rule1_detail = f"قیمت ({current_price:.{d}f}) زیر EMA50 ({ema50:.{d}f}) و EMA200 ({ema200:.{d}f})"
                rule1_note = "روند اصلی نزولی تایید است"
            else:
                rule1_long = False; rule1_short = False
                rule1_detail = f"EMA50={ema50:.{d}f} | EMA200={ema200:.{d}f} | قیمت بین آن‌ها"
                rule1_note = "روند نامشخص - قیمت بین EMAها گیر کرده"

            # ─── قانون ۲: ساختار بازار ───
            bos_choch_list = smc.get('bos_choch', [])
            bos_bull_ok = any(b.get('direction') == 'BULLISH' and b.get('type') in ('BOS', 'CHoCH') for b in bos_choch_list)
            bos_bear_ok = any(b.get('direction') == 'BEARISH' and b.get('type') in ('BOS', 'CHoCH') for b in bos_choch_list)
            rule2_long = bos_bull_ok or ms_bos
            rule2_short = bos_bear_ok or ms_bos
            if rule2_long and not rule2_short:
                rule2_detail = "BOS/CHoCH صعودی تایید شده - ساختار در جهت خرید شکسته"
                rule2_note = "انتظار pullback به zone معتبر"
            elif rule2_short and not rule2_long:
                rule2_detail = "BOS/CHoCH نزولی تایید شده - ساختار در جهت فروش شکسته"
                rule2_note = "انتظار pullback به zone معتبر"
            elif rule2_long and rule2_short:
                rule2_detail = "هم BOS صعودی هم BOS نزولی وجود دارد - بازار در تردید"
                rule2_note = "منتظر تایید یک جهت بمانید"
                rule2_long = False; rule2_short = False
            else:
                rule2_detail = f"BOS/CHoCH هنوز تایید نشده | ساختار: {ms_trend}"
                rule2_note = "منتظر شکسته شدن یک سطح کلیدی بمانید"

            # ─── قانون ۳: ناحیه معتبر ورود ───
            def in_zone(price, bottom, top, buffer=0):
                return (bottom - buffer) <= price <= (top + buffer)

            long_zone = None; long_zone_type = ""; long_zone_desc = ""
            short_zone = None; short_zone_type = ""; short_zone_desc = ""

            for ob in ob_bull:
                if in_zone(current_price, ob['bottom'], ob['top'], atr * 0.5):
                    long_zone = ob; long_zone_type = "Order Block صعودی"
                    long_zone_desc = f"{ob['bottom']:.{d}f} - {ob['top']:.{d}f}"
                    break
            if not long_zone and fvg_bull:
                for fvg in reversed(fvg_bull):
                    if in_zone(current_price, fvg['bottom'], fvg['top'], atr * 0.5):
                        long_zone = fvg; long_zone_type = "FVG صعودی (Gap پر نشده)"
                        long_zone_desc = f"{fvg['bottom']:.{d}f} - {fvg['top']:.{d}f}"
                        break
            if not long_zone and nearest_demand:
                if in_zone(current_price, nearest_demand['bottom'], nearest_demand['top'], atr * 1.0):
                    long_zone = nearest_demand; long_zone_type = "ناحیه تقاضا"
                    long_zone_desc = f"{nearest_demand['bottom']:.{d}f} - {nearest_demand['top']:.{d}f}"
            if not long_zone and nearest_sup:
                sp = nearest_sup['price']
                if abs(current_price - sp) <= atr * 1.5:
                    long_zone = nearest_sup; long_zone_type = "سطح حمایت"
                    long_zone_desc = f"{sp:.{d}f}"

            for ob in ob_bear:
                if in_zone(current_price, ob['bottom'], ob['top'], atr * 0.5):
                    short_zone = ob; short_zone_type = "Order Block نزولی"
                    short_zone_desc = f"{ob['bottom']:.{d}f} - {ob['top']:.{d}f}"
                    break
            if not short_zone and fvg_bear:
                for fvg in reversed(fvg_bear):
                    if in_zone(current_price, fvg['bottom'], fvg['top'], atr * 0.5):
                        short_zone = fvg; short_zone_type = "FVG نزولی (Gap پر نشده)"
                        short_zone_desc = f"{fvg['bottom']:.{d}f} - {fvg['top']:.{d}f}"
                        break
            if not short_zone and nearest_supply:
                if in_zone(current_price, nearest_supply['bottom'], nearest_supply['top'], atr * 1.0):
                    short_zone = nearest_supply; short_zone_type = "ناحیه عرضه"
                    short_zone_desc = f"{nearest_supply['bottom']:.{d}f} - {nearest_supply['top']:.{d}f}"
            if not short_zone and nearest_res:
                rp = nearest_res['price']
                if abs(current_price - rp) <= atr * 1.5:
                    short_zone = nearest_res; short_zone_type = "سطح مقاومت"
                    short_zone_desc = f"{rp:.{d}f}"

            rule3_long = long_zone is not None
            rule3_short = short_zone is not None
            if rule3_long:
                rule3_long_detail = f"قیمت در/نزدیک {long_zone_type} ({long_zone_desc})"
                rule3_long_note = "این ناحیه پشتیبانی می‌کند - احتمال برگشت بالاست"
            else:
                rule3_long_detail = "قیمت در هیچ ناحیه معتبر خریدی نیست"
                rule3_long_note = "منتظر pullback به OB/FVG/Support بمانید"
            if rule3_short:
                rule3_short_detail = f"قیمت در/نزدیک {short_zone_type} ({short_zone_desc})"
                rule3_short_note = "این ناحیه مقاومت می‌کند - احتمال ریزش بالاست"
            else:
                rule3_short_detail = "قیمت در هیچ ناحیه معتبر فروشی نیست"
                rule3_short_note = "منتظر برگشت به OB/FVG/Resistance بمانید"

            # ─── قانون ۴: تأیید مومنتوم ───
            mom_bull_count = 0; mom_bear_count = 0
            mom_bull_items = []; mom_bear_items = []

            if rsi_oversold or rsi_val < 45:
                mom_bull_count += 1; mom_bull_items.append(f"RSI={rsi_val:.1f} (اشباع فروش - برگشت محتمل)")
            if rsi_overbought or rsi_val > 55:
                mom_bear_count += 1; mom_bear_items.append(f"RSI={rsi_val:.1f} (اشباع خرید - افت محتمل)")
            if 'BULLISH' in macd_trend:
                mom_bull_count += 1; mom_bull_items.append(f"MACD صعودی")
            if 'BEARISH' in macd_trend:
                mom_bear_count += 1; mom_bear_items.append(f"MACD نزولی")
            if stoch_oversold or stoch_k < 25:
                mom_bull_count += 1; mom_bull_items.append(f"Stochastic={stoch_k:.1f} (اشباع فروش)")
            if stoch_overbought or stoch_k > 75:
                mom_bear_count += 1; mom_bear_items.append(f"Stochastic={stoch_k:.1f} (اشباع خرید)")
            if 'OVERSOLD' in bb_sig:
                mom_bull_count += 1; mom_bull_items.append("Bollinger Band اشباع فروش")
            if 'OVERBOUGHT' in bb_sig:
                mom_bear_count += 1; mom_bear_items.append("Bollinger Band اشباع خرید")

            rule4_long = mom_bull_count >= 2
            rule4_short = mom_bear_count >= 2
            rule4_long_detail = " | ".join(mom_bull_items) if mom_bull_items else "هیچ تاییدیه مومنتومی برای خرید نیست"
            rule4_short_detail = " | ".join(mom_bear_items) if mom_bear_items else "هیچ تاییدیه مومنتومی برای فروش نیست"
            rule4_long_note = f"امتیاز مومنتوم خرید: {mom_bull_count}/4"
            rule4_short_note = f"امتیاز مومنتوم فروش: {mom_bear_count}/4"

            # ─── قانون ۵: قدرت روند ───
            adx_strong = adx_val > 20
            rule5_long = adx_strong and (supertrend_sig == 'BULLISH' or adx_dir == 'BULLISH')
            rule5_short = adx_strong and (supertrend_sig == 'BEARISH' or adx_dir == 'BEARISH')
            if rule5_long:
                rule5_detail = f"ADX={adx_val:.1f} (قوی) | Supertrend: {supertrend_sig} | روند قوی صعودی"
                rule5_note = "روند قوی است - ترید در جهت روند ریسک کمتری دارد"
            elif rule5_short:
                rule5_detail = f"ADX={adx_val:.1f} (قوی) | Supertrend: {supertrend_sig} | روند قوی نزولی"
                rule5_note = "روند قوی است - ترید در جهت روند ریسک کمتری دارد"
            elif adx_strong:
                rule5_detail = f"ADX={adx_val:.1f} (قوی) | Supertrend: {supertrend_sig} | جهت نامشخص"
                rule5_note = "ADX قوی است اما جهت روند با Supertrend تایید نشده"
            else:
                rule5_detail = f"ADX={adx_val:.1f} (ضعیف/خنثی) | Supertrend: {supertrend_sig}"
                rule5_note = "بازار رنج است - ورودهای ترند احتمال شکست دارند"

            # ─── تعیین جهت کلی ───
            long_score = sum([rule1_long, rule2_long, rule3_long, rule4_long, rule5_long])
            short_score = sum([rule1_short, rule2_short, rule3_short, rule4_short, rule5_short])

            if long_score >= short_score and long_score >= 3:
                direction = "LONG"
                score = long_score
            elif short_score > long_score and short_score >= 3:
                direction = "SHORT"
                score = short_score
            elif long_score > short_score:
                direction = "LONG_WEAK"
                score = long_score
            elif short_score > long_score:
                direction = "SHORT_WEAK"
                score = short_score
            else:
                direction = "NEUTRAL"
                score = max(long_score, short_score)

            # ─── محاسبه Entry / SL / TP ───
            entry = sl = tp1 = tp2 = tp3 = None
            risk_pips = risk_pct = rr1 = rr2 = rr3 = 0.0

            if direction in ("LONG", "LONG_WEAK"):
                swing_low = float(df['low'].tail(20).min())
                if long_zone and isinstance(long_zone, dict):
                    z_bot = float(long_zone.get('bottom', long_zone.get('price', current_price)))
                    z_top = float(long_zone.get('top', long_zone.get('price', current_price)))
                    entry = z_bot + atr * 0.1
                else:
                    entry = current_price
                sl_raw = swing_low - atr * 1.2
                sl = max(sl_raw, entry - atr * 3.0)
                risk = entry - sl
                if risk <= 0:
                    risk = atr * 1.5; sl = entry - risk
                tp1 = entry + risk * 1.5
                tp2 = entry + risk * 2.5
                tp3 = entry + risk * 4.0
                invalidation_text = f"بسته شدن کندل زیر {sl:.{d}f}"
                sl_logic = f"زیر swing low 20 کندل ({swing_low:.{d}f}) با 1.2x ATR فاصله"

            elif direction in ("SHORT", "SHORT_WEAK"):
                swing_high = float(df['high'].tail(20).max())
                if short_zone and isinstance(short_zone, dict):
                    z_bot = float(short_zone.get('bottom', short_zone.get('price', current_price)))
                    z_top = float(short_zone.get('top', short_zone.get('price', current_price)))
                    entry = z_top - atr * 0.1
                else:
                    entry = current_price
                sl_raw = swing_high + atr * 1.2
                sl = min(sl_raw, entry + atr * 3.0)
                risk = sl - entry
                if risk <= 0:
                    risk = atr * 1.5; sl = entry + risk
                tp1 = entry - risk * 1.5
                tp2 = entry - risk * 2.5
                tp3 = entry - risk * 4.0
                invalidation_text = f"بسته شدن کندل بالای {sl:.{d}f}"
                sl_logic = f"بالای swing high 20 کندل ({swing_high:.{d}f}) با 1.2x ATR فاصله"

            if entry and sl:
                risk_pips = abs(entry - sl)
                risk_pct = risk_pips / entry * 100
                r = abs(entry - sl)
                rr1 = abs(tp1 - entry) / r if tp1 and r > 0 else 0
                rr2 = abs(tp2 - entry) / r if tp2 and r > 0 else 0
                rr3 = abs(tp3 - entry) / r if tp3 and r > 0 else 0

            # ─── لیکوئیدیتی ───
            liq_bull_sweeps = [l for l in liq_list if l.get('signal') == 'BULLISH']
            liq_bear_sweeps = [l for l in liq_list if l.get('signal') == 'BEARISH']

            # ─── فیبوناچی ───
            fib = patterns.get('fibonacci', {})
            fib38 = float(fib.get('level_0.382', 0) or 0)
            fib50 = float(fib.get('level_0.5', 0) or 0)
            fib618 = float(fib.get('level_0.618', 0) or 0)

            # ─── ساخت گزارش ───
            sig_icon = "🟢" if "LONG" in direction else "🔴" if "SHORT" in direction else "⚪"
            dir_fa = "خرید (LONG)" if "LONG" in direction else "فروش (SHORT)" if "SHORT" in direction else "خنثی"

            if score == 5:
                quality = "عالی - ورود با اطمینان بالا"
                quality_icon = "💎"
            elif score == 4:
                quality = "خوب - ورود توصیه می‌شود"
                quality_icon = "🥇"
            elif score == 3:
                quality = "قابل قبول - با احتیاط وارد شوید"
                quality_icon = "🥈"
            elif score == 2:
                quality = "ضعیف - ورود توصیه نمی‌شود"
                quality_icon = "⚠️"
            else:
                quality = "نامعتبر - وارد نشوید"
                quality_icon = "❌"

            is_valid = score >= 3

            lines = []
            lines.append(f"{'='*40}")
            lines.append(f"🏹 نقطه ورود صمدی")
            lines.append(f"   {symbol}  |  {tf_display}")
            lines.append(f"   زمان: {datetime.now().strftime('%Y-%m-%d  %H:%M')}")
            lines.append(f"{'='*40}")
            lines.append(f"")
            lines.append(f"{sig_icon} جهت: {dir_fa}")
            lines.append(f"{quality_icon} کیفیت: {quality}")
            lines.append(f"   امتیاز صمدی: {score}/5 قانون تایید شده")
            lines.append(f"")
            lines.append(f"قیمت فعلی:  {current_price:.{d}f}")
            lines.append(f"ATR نوسان:  {atr:.{d}f}")
            lines.append(f"ناحیه قیمت: {pd_zone}")
            lines.append(f"تعادل بازار: {equil:.{d}f}")
            lines.append(f"")

            # ─── بخش قوانین صمدی ───
            lines.append(f"{'─'*40}")
            lines.append(f"قوانین صمدی - بررسی مو به مو")
            lines.append(f"{'─'*40}")
            lines.append(f"")

            # قانون ۱
            long_ok1 = "✅" if rule1_long else "❌"
            short_ok1 = "✅" if rule1_short else "❌"
            lines.append(f"قانون ۱: روند کلی (EMA50 & EMA200)")
            lines.append(f"  خرید {long_ok1} | فروش {short_ok1}")
            lines.append(f"  {rule1_detail}")
            lines.append(f"  راهنما: {rule1_note}")
            lines.append(f"")

            # قانون ۲
            long_ok2 = "✅" if rule2_long else "❌"
            short_ok2 = "✅" if rule2_short else "❌"
            lines.append(f"قانون ۲: ساختار بازار (BOS / CHoCH)")
            lines.append(f"  خرید {long_ok2} | فروش {short_ok2}")
            lines.append(f"  {rule2_detail}")
            lines.append(f"  راهنما: {rule2_note}")
            lines.append(f"")

            # قانون ۳
            long_ok3 = "✅" if rule3_long else "❌"
            short_ok3 = "✅" if rule3_short else "❌"
            lines.append(f"قانون ۳: ناحیه معتبر ورود (OB / FVG / Zone)")
            lines.append(f"  خرید {long_ok3} | فروش {short_ok3}")
            if direction in ("LONG", "LONG_WEAK"):
                lines.append(f"  {rule3_long_detail}")
                lines.append(f"  راهنما: {rule3_long_note}")
            else:
                lines.append(f"  {rule3_short_detail}")
                lines.append(f"  راهنما: {rule3_short_note}")
            lines.append(f"")

            # قانون ۴
            long_ok4 = "✅" if rule4_long else "❌"
            short_ok4 = "✅" if rule4_short else "❌"
            lines.append(f"قانون ۴: مومنتوم (RSI / MACD / Stochastic / BB)")
            lines.append(f"  خرید {long_ok4} | فروش {short_ok4}")
            if direction in ("LONG", "LONG_WEAK"):
                lines.append(f"  {rule4_long_detail}")
                lines.append(f"  راهنما: {rule4_long_note}")
            else:
                lines.append(f"  {rule4_short_detail}")
                lines.append(f"  راهنما: {rule4_short_note}")
            lines.append(f"")

            # قانون ۵
            long_ok5 = "✅" if rule5_long else "❌"
            short_ok5 = "✅" if rule5_short else "❌"
            lines.append(f"قانون ۵: قدرت روند (ADX / Supertrend)")
            lines.append(f"  خرید {long_ok5} | فروش {short_ok5}")
            lines.append(f"  {rule5_detail}")
            lines.append(f"  راهنما: {rule5_note}")
            lines.append(f"")

            lines.append(f"{'='*40}")

            if is_valid and entry and sl:
                lines.append(f"")
                lines.append(f"نقطه ورود دقیق صمدی")
                lines.append(f"{'─'*40}")
                lines.append(f"")
                lines.append(f"Entry (ورود):  {entry:.{d}f}")
                lines.append(f"  نوع سفارش: Limit Order")
                lines.append(f"  چرا این قیمت: {'لبه پایین ' + (long_zone_type if 'LONG' in direction else short_zone_type) + ' + بافر ATR' if (long_zone if 'LONG' in direction else short_zone) else 'قیمت فعلی بازار'}")
                lines.append(f"")
                lines.append(f"SL (استاپ لاس):  {sl:.{d}f}")
                lines.append(f"  فاصله: {risk_pips:.{d}f}  ({risk_pct:.2f}% از ورود)")
                lines.append(f"  منطق: {sl_logic}")
                lines.append(f"  باطل می‌شود اگر: {invalidation_text}")
                lines.append(f"")
                lines.append(f"TP1 (هدف اول):  {tp1:.{d}f}   (R:R = {rr1:.1f}x)")
                lines.append(f"  اقدام: 50% پوزیشن بسته شود")
                lines.append(f"  بعد از رسیدن: SL به Entry منتقل شود")
                lines.append(f"")
                lines.append(f"TP2 (هدف دوم):  {tp2:.{d}f}   (R:R = {rr2:.1f}x)")
                lines.append(f"  اقدام: 30% پوزیشن بسته شود")
                lines.append(f"  بعد از رسیدن: Trailing SL فعال شود")
                lines.append(f"")
                lines.append(f"TP3 (هدف سوم):  {tp3:.{d}f}   (R:R = {rr3:.1f}x)")
                lines.append(f"  اقدام: 20% باقیمانده بسته شود")
                lines.append(f"")
                lines.append(f"{'─'*40}")
                lines.append(f"سطوح کلیدی اطراف")
                lines.append(f"{'─'*40}")
                if pivot_pp:
                    lines.append(f"  Pivot PP:  {pivot_pp:.{d}f}")
                if pivot_r1:
                    lines.append(f"  Pivot R1:  {pivot_r1:.{d}f}")
                if pivot_s1:
                    lines.append(f"  Pivot S1:  {pivot_s1:.{d}f}")
                if fib38:
                    lines.append(f"  Fib 38.2%: {fib38:.{d}f}")
                if fib50:
                    lines.append(f"  Fib 50%:   {fib50:.{d}f}")
                if fib618:
                    lines.append(f"  Fib 61.8%: {fib618:.{d}f}")
                if nearest_sup:
                    lines.append(f"  حمایت:     {nearest_sup['price']:.{d}f}")
                if nearest_res:
                    lines.append(f"  مقاومت:    {nearest_res['price']:.{d}f}")
                if liq_bull_sweeps:
                    lines.append(f"  Liq Sweep صعودی: {liq_bull_sweeps[-1]['level']:.{d}f}")
                if liq_bear_sweeps:
                    lines.append(f"  Liq Sweep نزولی: {liq_bear_sweeps[-1]['level']:.{d}f}")
                lines.append(f"")
                lines.append(f"{'─'*40}")
                lines.append(f"راهنمای گام به گام ورود صمدی")
                lines.append(f"{'─'*40}")
                lines.append(f"")
                lines.append(f"گام ۱: اطمینان از روند")
                lines.append(f"  قیمت {'بالای' if 'LONG' in direction else 'زیر'} EMA50 و EMA200 است.")
                lines.append(f"  تایم فریم بالاتر ({self._higher_tf(timeframe)}) را هم بررسی کنید.")
                lines.append(f"")
                lines.append(f"گام ۲: انتظار برای رسیدن به ناحیه")
                lines.append(f"  اگر قیمت هنوز به {entry:.{d}f} نرسیده، صبر کنید.")
                lines.append(f"  عجله نکنید - قیمت باید خودش بیاید.")
                lines.append(f"")
                lines.append(f"گام ۳: تایید کندل برگشتی")
                lines.append(f"  وقتی قیمت به Entry رسید، منتظر یک")
                lines.append(f"  کندل تاییدیه بمانید (Pin Bar / Engulfing / Doji).")
                lines.append(f"")
                lines.append(f"گام ۴: ثبت سفارش")
                lines.append(f"  Entry: {entry:.{d}f}")
                lines.append(f"  SL:    {sl:.{d}f}")
                lines.append(f"  TP1:   {tp1:.{d}f}  (سود اول)")
                lines.append(f"")
                lines.append(f"گام ۵: مدیریت پوزیشن")
                lines.append(f"  در TP1 نیمی ببندید و SL به Breakeven ببرید.")
                lines.append(f"  در TP2 بخش دیگری ببندید.")
                lines.append(f"  TP3 را با Trailing Stop نگه دارید.")
                lines.append(f"")
                lines.append(f"گام ۶: مراقبت")
                lines.append(f"  {invalidation_text} = پوزیشن کنسل است.")
                lines.append(f"  هرگز SL را دور نکنید!")
                lines.append(f"")

            else:
                missing = []
                if direction in ("LONG", "LONG_WEAK"):
                    if not rule1_long: missing.append("روند EMA هنوز صعودی نیست")
                    if not rule2_long: missing.append("BOS/CHoCH صعودی هنوز تایید نشده")
                    if not rule3_long: missing.append("قیمت هنوز به ناحیه معتبر خرید نرسیده")
                    if not rule4_long: missing.append("مومنتوم خرید هنوز کافی نیست")
                    if not rule5_long: missing.append("قدرت روند هنوز تایید نشده")
                elif direction in ("SHORT", "SHORT_WEAK"):
                    if not rule1_short: missing.append("روند EMA هنوز نزولی نیست")
                    if not rule2_short: missing.append("BOS/CHoCH نزولی هنوز تایید نشده")
                    if not rule3_short: missing.append("قیمت هنوز به ناحیه معتبر فروش نرسیده")
                    if not rule4_short: missing.append("مومنتوم فروش هنوز کافی نیست")
                    if not rule5_short: missing.append("قدرت روند هنوز تایید نشده")
                else:
                    missing = ["بازار در حالت خنثی است", "هیچ جهت مشخصی وجود ندارد"]

                lines.append(f"")
                lines.append(f"ورود اکنون مناسب نیست")
                lines.append(f"{'─'*40}")
                lines.append(f"")
                lines.append(f"چرا نباید الان وارد شد:")
                for i, m in enumerate(missing, 1):
                    lines.append(f"  {i}. {m}")
                lines.append(f"")
                lines.append(f"منتظر چه باشید:")
                if direction in ("LONG", "LONG_WEAK"):
                    lines.append(f"  - قیمت به زیر EMA50/EMA200 نرود")
                    lines.append(f"  - یک BOS صعودی واضح شکل بگیرد")
                    lines.append(f"  - قیمت به OB/FVG/حمایت pullback کند")
                    lines.append(f"  - RSI زیر 40 یا Stochastic زیر 25 برسد")
                else:
                    lines.append(f"  - قیمت بالای EMA50/EMA200 نماند")
                    lines.append(f"  - یک BOS نزولی واضح شکل بگیرد")
                    lines.append(f"  - قیمت به OB/FVG/مقاومت برگردد")
                    lines.append(f"  - RSI بالای 60 یا Stochastic بالای 75 برسد")
                lines.append(f"")

            lines.append(f"{'='*40}")
            lines.append(f"تحلیلگر: ربات صمدی")
            lines.append(f"توجه: این تحلیل آموزشی است.")
            lines.append(f"مسئولیت معامله با خود شماست.")

            text = "\n".join(lines)
            await self._send_long_message(context, query.message.chat_id, text, self.get_main_menu())

        except Exception as e:
            logger.error(f"Error in samadi analysis: {e}", exc_info=True)
            await context.bot.send_message(
                chat_id=query.message.chat_id,
                text=f"خطا در تحلیل صمدی: {str(e)}\nلطفا دوباره تلاش کنید.",
                reply_markup=self.get_main_menu()
            )

    def _higher_tf(self, tf: str) -> str:
        order = ["1m", "5m", "15m", "30m", "1h", "4h", "daily"]
        try:
            idx = order.index(tf)
            return order[min(idx + 1, len(order) - 1)]
        except ValueError:
            return "4h"


def run_bot():
    bot = TradingBot()
    application = Application.builder().token(BOT_TOKEN).build()

    application.add_handler(CommandHandler("start", bot.start))
    application.add_handler(CommandHandler("prices", bot.send_prices))
    application.add_handler(CallbackQueryHandler(bot.button_callback))

    logger.info("Starting Telegram bot...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    run_bot()

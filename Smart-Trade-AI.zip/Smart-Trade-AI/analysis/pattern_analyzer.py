import pandas as pd
import numpy as np
from typing import List, Dict, Tuple

class PatternAnalyzer:
    def __init__(self, df: pd.DataFrame):
        self.df = df.copy()
        self.patterns = []
    
    def analyze_all(self) -> dict:
        candlestick_patterns = self.detect_candlestick_patterns()
        support_resistance = self.calculate_support_resistance()
        fibonacci = self.calculate_fibonacci_levels()
        pivot_points = self.calculate_pivot_points()
        breakouts = self.detect_breakouts()
        
        return {
            'candlestick_patterns': candlestick_patterns,
            'support_resistance': support_resistance,
            'fibonacci': fibonacci,
            'pivot_points': pivot_points,
            'breakouts': breakouts
        }
    
    def detect_candlestick_patterns(self) -> List[Dict]:
        patterns = []
        
        for i in range(3, len(self.df)):
            idx = self.df.index[i]
            current = self.df.iloc[i]
            prev1 = self.df.iloc[i-1]
            prev2 = self.df.iloc[i-2]
            
            body = abs(current['close'] - current['open'])
            upper_shadow = current['high'] - max(current['open'], current['close'])
            lower_shadow = min(current['open'], current['close']) - current['low']
            total_range = current['high'] - current['low']
            
            if total_range > 0:
                if lower_shadow > body * 2 and upper_shadow < body * 0.5:
                    if current['close'] > current['open']:
                        patterns.append({
                            'pattern': 'HAMMER',
                            'type': 'BULLISH',
                            'index': idx,
                            'strength': 'STRONG',
                            'description': 'الگوی چکش - سیگنال برگشت صعودی'
                        })
                    else:
                        patterns.append({
                            'pattern': 'HANGING_MAN',
                            'type': 'BEARISH',
                            'index': idx,
                            'strength': 'MODERATE',
                            'description': 'الگوی مرد آویزان - سیگنال برگشت نزولی'
                        })
                
                if upper_shadow > body * 2 and lower_shadow < body * 0.5:
                    if current['close'] < current['open']:
                        patterns.append({
                            'pattern': 'SHOOTING_STAR',
                            'type': 'BEARISH',
                            'index': idx,
                            'strength': 'STRONG',
                            'description': 'الگوی ستاره دنباله‌دار - سیگنال برگشت نزولی'
                        })
                    else:
                        patterns.append({
                            'pattern': 'INVERTED_HAMMER',
                            'type': 'BULLISH',
                            'index': idx,
                            'strength': 'MODERATE',
                            'description': 'الگوی چکش معکوس - سیگنال برگشت صعودی'
                        })
                
                if body < total_range * 0.1:
                    if upper_shadow > total_range * 0.3 and lower_shadow > total_range * 0.3:
                        patterns.append({
                            'pattern': 'DOJI',
                            'type': 'NEUTRAL',
                            'index': idx,
                            'strength': 'MODERATE',
                            'description': 'الگوی دوجی - عدم قطعیت در بازار'
                        })
                    elif upper_shadow > total_range * 0.6:
                        patterns.append({
                            'pattern': 'GRAVESTONE_DOJI',
                            'type': 'BEARISH',
                            'index': idx,
                            'strength': 'STRONG',
                            'description': 'دوجی سنگ قبر - سیگنال نزولی قوی'
                        })
                    elif lower_shadow > total_range * 0.6:
                        patterns.append({
                            'pattern': 'DRAGONFLY_DOJI',
                            'type': 'BULLISH',
                            'index': idx,
                            'strength': 'STRONG',
                            'description': 'دوجی سنجاقک - سیگنال صعودی قوی'
                        })
            
            prev_body = abs(prev1['close'] - prev1['open'])
            if prev_body > 0 and body > 0:
                if prev1['close'] < prev1['open'] and current['close'] > current['open']:
                    if current['open'] < prev1['close'] and current['close'] > prev1['open']:
                        patterns.append({
                            'pattern': 'BULLISH_ENGULFING',
                            'type': 'BULLISH',
                            'index': idx,
                            'strength': 'STRONG',
                            'description': 'الگوی پوشای صعودی - سیگنال برگشت صعودی قوی'
                        })
                
                if prev1['close'] > prev1['open'] and current['close'] < current['open']:
                    if current['open'] > prev1['close'] and current['close'] < prev1['open']:
                        patterns.append({
                            'pattern': 'BEARISH_ENGULFING',
                            'type': 'BEARISH',
                            'index': idx,
                            'strength': 'STRONG',
                            'description': 'الگوی پوشای نزولی - سیگنال برگشت نزولی قوی'
                        })
            
            if prev1['close'] < prev1['open'] and current['close'] > current['open']:
                if abs(current['open'] - prev1['close']) < body * 0.1:
                    if current['close'] > (prev1['open'] + prev1['close']) / 2:
                        patterns.append({
                            'pattern': 'PIERCING_LINE',
                            'type': 'BULLISH',
                            'index': idx,
                            'strength': 'MODERATE',
                            'description': 'الگوی خط نافذ - سیگنال برگشت صعودی'
                        })
            
            if prev1['close'] > prev1['open'] and current['close'] < current['open']:
                if abs(current['open'] - prev1['close']) < body * 0.1:
                    if current['close'] < (prev1['open'] + prev1['close']) / 2:
                        patterns.append({
                            'pattern': 'DARK_CLOUD_COVER',
                            'type': 'BEARISH',
                            'index': idx,
                            'strength': 'MODERATE',
                            'description': 'الگوی ابر سیاه - سیگنال برگشت نزولی'
                        })
            
            if i >= 3:
                prev3 = self.df.iloc[i-3]
                if (prev2['close'] > prev2['open'] and 
                    prev1['close'] > prev1['open'] and 
                    current['close'] > current['open']):
                    if (prev1['open'] > prev2['open'] and 
                        current['open'] > prev1['open']):
                        patterns.append({
                            'pattern': 'THREE_WHITE_SOLDIERS',
                            'type': 'BULLISH',
                            'index': idx,
                            'strength': 'VERY_STRONG',
                            'description': 'سه سرباز سفید - سیگنال صعودی بسیار قوی'
                        })
                
                if (prev2['close'] < prev2['open'] and 
                    prev1['close'] < prev1['open'] and 
                    current['close'] < current['open']):
                    if (prev1['open'] < prev2['open'] and 
                        current['open'] < prev1['open']):
                        patterns.append({
                            'pattern': 'THREE_BLACK_CROWS',
                            'type': 'BEARISH',
                            'index': idx,
                            'strength': 'VERY_STRONG',
                            'description': 'سه کلاغ سیاه - سیگنال نزولی بسیار قوی'
                        })
        
        return patterns[-10:] if len(patterns) > 10 else patterns
    
    def calculate_support_resistance(self) -> dict:
        highs = self.df['high'].values
        lows = self.df['low'].values
        closes = self.df['close'].values
        
        window = 10
        
        resistance_levels = []
        support_levels = []
        
        for i in range(window, len(self.df) - window):
            if highs[i] == max(highs[i-window:i+window+1]):
                resistance_levels.append({
                    'price': highs[i],
                    'index': self.df.index[i],
                    'strength': self._calculate_level_strength(highs[i], highs, lows)
                })
            
            if lows[i] == min(lows[i-window:i+window+1]):
                support_levels.append({
                    'price': lows[i],
                    'index': self.df.index[i],
                    'strength': self._calculate_level_strength(lows[i], highs, lows)
                })
        
        resistance_levels = sorted(resistance_levels, key=lambda x: x['strength'], reverse=True)[:5]
        support_levels = sorted(support_levels, key=lambda x: x['strength'], reverse=True)[:5]
        
        current_price = closes[-1]
        
        nearest_resistance = None
        for r in sorted(resistance_levels, key=lambda x: x['price']):
            if r['price'] > current_price:
                nearest_resistance = r
                break
        
        nearest_support = None
        for s in sorted(support_levels, key=lambda x: x['price'], reverse=True):
            if s['price'] < current_price:
                nearest_support = s
                break
        
        return {
            'resistance_levels': resistance_levels,
            'support_levels': support_levels,
            'nearest_resistance': nearest_resistance,
            'nearest_support': nearest_support,
            'current_price': current_price
        }
    
    def _calculate_level_strength(self, level: float, highs: np.ndarray, lows: np.ndarray) -> int:
        tolerance = level * 0.002
        touches = 0
        
        for i in range(len(highs)):
            if abs(highs[i] - level) < tolerance or abs(lows[i] - level) < tolerance:
                touches += 1
        
        return touches
    
    def calculate_fibonacci_levels(self) -> dict:
        high = self.df['high'].max()
        low = self.df['low'].min()
        diff = high - low
        current_price = self.df['close'].iloc[-1]
        
        is_uptrend = self.df['close'].iloc[-1] > self.df['close'].iloc[0]
        
        if is_uptrend:
            levels = {
                '0.0%': high,
                '23.6%': high - diff * 0.236,
                '38.2%': high - diff * 0.382,
                '50.0%': high - diff * 0.5,
                '61.8%': high - diff * 0.618,
                '78.6%': high - diff * 0.786,
                '100.0%': low,
                '127.2%': high + diff * 0.272,
                '161.8%': high + diff * 0.618
            }
        else:
            levels = {
                '0.0%': low,
                '23.6%': low + diff * 0.236,
                '38.2%': low + diff * 0.382,
                '50.0%': low + diff * 0.5,
                '61.8%': low + diff * 0.618,
                '78.6%': low + diff * 0.786,
                '100.0%': high,
                '127.2%': low - diff * 0.272,
                '161.8%': low - diff * 0.618
            }
        
        current_zone = None
        sorted_levels = sorted(levels.items(), key=lambda x: x[1])
        for i, (name, level) in enumerate(sorted_levels):
            if level > current_price:
                if i > 0:
                    current_zone = f"بین {sorted_levels[i-1][0]} و {name}"
                break
        
        return {
            'levels': levels,
            'swing_high': high,
            'swing_low': low,
            'is_uptrend': is_uptrend,
            'current_zone': current_zone,
            'current_price': current_price
        }
    
    def calculate_pivot_points(self) -> dict:
        if len(self.df) < 2:
            return {}
        
        prev = self.df.iloc[-2]
        high = prev['high']
        low = prev['low']
        close = prev['close']
        
        pivot = (high + low + close) / 3
        
        r1 = 2 * pivot - low
        s1 = 2 * pivot - high
        r2 = pivot + (high - low)
        s2 = pivot - (high - low)
        r3 = high + 2 * (pivot - low)
        s3 = low - 2 * (high - pivot)
        
        range_hl = high - low
        fib_r1 = pivot + 0.382 * range_hl
        fib_r2 = pivot + 0.618 * range_hl
        fib_r3 = pivot + range_hl
        fib_s1 = pivot - 0.382 * range_hl
        fib_s2 = pivot - 0.618 * range_hl
        fib_s3 = pivot - range_hl
        
        current_price = self.df['close'].iloc[-1]
        
        if current_price > r2:
            position = 'بالای R2 - منطقه اشباع خرید'
        elif current_price > r1:
            position = 'بین R1 و R2 - روند صعودی قوی'
        elif current_price > pivot:
            position = 'بالای Pivot - تمایل صعودی'
        elif current_price > s1:
            position = 'زیر Pivot - تمایل نزولی'
        elif current_price > s2:
            position = 'بین S1 و S2 - روند نزولی'
        else:
            position = 'زیر S2 - منطقه اشباع فروش'
        
        return {
            'standard': {
                'pivot': pivot,
                'r1': r1, 'r2': r2, 'r3': r3,
                's1': s1, 's2': s2, 's3': s3
            },
            'fibonacci': {
                'pivot': pivot,
                'r1': fib_r1, 'r2': fib_r2, 'r3': fib_r3,
                's1': fib_s1, 's2': fib_s2, 's3': fib_s3
            },
            'current_price': current_price,
            'position': position
        }
    
    def detect_breakouts(self) -> List[Dict]:
        breakouts = []
        
        sr = self.calculate_support_resistance()
        current_price = self.df['close'].iloc[-1]
        prev_price = self.df['close'].iloc[-2]
        
        for r in sr['resistance_levels']:
            if prev_price < r['price'] <= current_price:
                breakouts.append({
                    'type': 'RESISTANCE_BREAKOUT',
                    'level': r['price'],
                    'signal': 'BULLISH',
                    'strength': r['strength'],
                    'description': f'شکست مقاومت در {r["price"]:.5f}'
                })
        
        for s in sr['support_levels']:
            if prev_price > s['price'] >= current_price:
                breakouts.append({
                    'type': 'SUPPORT_BREAKOUT',
                    'level': s['price'],
                    'signal': 'BEARISH',
                    'strength': s['strength'],
                    'description': f'شکست حمایت در {s["price"]:.5f}'
                })
        
        if len(self.df) >= 20:
            high_20 = self.df['high'].rolling(20).max().iloc[-2]
            low_20 = self.df['low'].rolling(20).min().iloc[-2]
            
            if current_price > high_20 and prev_price <= high_20:
                breakouts.append({
                    'type': 'NEW_20_HIGH',
                    'level': high_20,
                    'signal': 'BULLISH',
                    'strength': 5,
                    'description': 'سقف جدید 20 کندلی'
                })
            
            if current_price < low_20 and prev_price >= low_20:
                breakouts.append({
                    'type': 'NEW_20_LOW',
                    'level': low_20,
                    'signal': 'BEARISH',
                    'strength': 5,
                    'description': 'کف جدید 20 کندلی'
                })
        
        return breakouts

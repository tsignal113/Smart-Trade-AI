import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple
from indicators.technical_indicators import TechnicalIndicators
from analysis.smc_analyzer import SMCAnalyzer
from analysis.pattern_analyzer import PatternAnalyzer

class EntrySignalGenerator:
    def __init__(self, df: pd.DataFrame, symbol: str, timeframe: str):
        self.df = df.copy()
        self.symbol = symbol
        self.timeframe = timeframe
        self.indicators = TechnicalIndicators(df)
        self.smc = SMCAnalyzer(df)
        self.patterns = PatternAnalyzer(df)

    @staticmethod
    def _fp(price) -> str:
        try:
            p = float(price)
        except (TypeError, ValueError):
            return 'N/A'
        if p >= 1000:
            return f"{p:.2f}"
        elif p >= 100:
            return f"{p:.3f}"
        elif p >= 10:
            return f"{p:.4f}"
        else:
            return f"{p:.5f}"
    
    # ─────────────────────────────────────────────────────────────────
    # سیستم سوباراشی حرفه‌ای - بازنویسی کامل بدون باگ
    # ─────────────────────────────────────────────────────────────────

    def _safe_float(self, val, default=0.0) -> float:
        try:
            return float(val)
        except (TypeError, ValueError):
            return default

    def _get_safe(self, d, *keys, default=None):
        for k in keys:
            if not isinstance(d, dict):
                return default
            d = d.get(k, default)
        return d

    def generate_subarashi_signal(self) -> dict:
        """
        سیستم تحلیل سوباراشی حرفه‌ای - 5 فاز تحلیل
        فاز 1: روند کلی      (EMA9/21/50/200 + Supertrend + ADX)     30 pts
        فاز 2: ساختار SMC    (Market Structure + PD Zone + Liquidity)  25 pts
        فاز 3: مومنتوم       (RSI + MACD + Stochastic + CCI)           25 pts
        فاز 4: ناحیه ورود    (Order Block + FVG + Supply/Demand)        20 pts
        فاز 5: تأییدیه       (Bollinger + Candles + Volume/MFI)         20 pts
        مجموع: 120 pts  |  حداقل اعتماد برای سیگنال: 62%
        """
        # ── بارگذاری ایمن داده‌ها ──────────────────────────────────────
        try:
            ind_data = self.indicators.calculate_all()
        except Exception:
            ind_data = {}
        try:
            smc_data = self.smc.analyze_all()
        except Exception:
            smc_data = {}
        try:
            pattern_data = self.patterns.analyze_all()
        except Exception:
            pattern_data = {}

        cp = self._safe_float(self.df['close'].iloc[-1])
        atr = self._safe_float(ind_data.get('ATR', {}).get('value', cp * 0.002))
        if atr <= 0:
            atr = cp * 0.002

        bull = 0
        bear = 0
        detail = {}   # ذخیره جزئیات تحلیل برای گزارش

        # ══════════════════════════════════════════════════════════════
        # فاز 1 – روند کلی (30 pts)
        # ══════════════════════════════════════════════════════════════

        # EMA (15 pts)
        ema_d = ind_data.get('EMA', {}) or {}
        ema9   = self._safe_float(ema_d.get('EMA_9',   cp), cp)
        ema21  = self._safe_float(ema_d.get('EMA_21',  cp), cp)
        ema50  = self._safe_float(ema_d.get('EMA_50',  cp), cp)
        ema200 = self._safe_float(ema_d.get('EMA_200', cp), cp)
        ema_bull_count = sum([cp > ema9, cp > ema21, cp > ema50, cp > ema200])
        ema_bear_count = 4 - ema_bull_count
        if ema_bull_count >= 3:
            bull += 15
            detail['ema'] = {'dir': 'BULL', 'pts': 15,
                'text': f"قیمت بالای {ema_bull_count}/4 EMA | EMA50={self._fp(ema50)} | EMA200={self._fp(ema200)}"}
        elif ema_bear_count >= 3:
            bear += 15
            detail['ema'] = {'dir': 'BEAR', 'pts': 15,
                'text': f"قیمت زیر {ema_bear_count}/4 EMA | EMA50={self._fp(ema50)} | EMA200={self._fp(ema200)}"}
        else:
            detail['ema'] = {'dir': 'NEUT', 'pts': 0,
                'text': f"EMA خنثی ({ema_bull_count}/4 صعودی) | EMA50={self._fp(ema50)}"}

        # Supertrend (10 pts)
        st_d = ind_data.get('SUPERTREND', {}) or {}
        st_sig = st_d.get('signal', '')
        st_val = self._safe_float(st_d.get('value', cp), cp)
        if st_sig == 'BULLISH':
            bull += 10
            detail['supertrend'] = {'dir': 'BULL', 'pts': 10,
                'text': f"Supertrend صعودی | حمایت داینامیک: {self._fp(st_val)}"}
        elif st_sig == 'BEARISH':
            bear += 10
            detail['supertrend'] = {'dir': 'BEAR', 'pts': 10,
                'text': f"Supertrend نزولی | مقاومت داینامیک: {self._fp(st_val)}"}
        else:
            detail['supertrend'] = {'dir': 'NEUT', 'pts': 0, 'text': "Supertrend خنثی"}

        # ADX (5 pts) – فقط اگر روند قوی باشد
        adx_d = ind_data.get('ADX', {}) or {}
        adx_val   = self._safe_float(adx_d.get('adx', 0))
        plus_di   = self._safe_float(adx_d.get('plus_di', 0))
        minus_di  = self._safe_float(adx_d.get('minus_di', 0))
        adx_trend = adx_d.get('trend_direction', '')
        if adx_val >= 25:
            if plus_di > minus_di:
                bull += 5
                detail['adx'] = {'dir': 'BULL', 'pts': 5,
                    'text': f"ADX={adx_val:.1f} (قوی) | +DI={plus_di:.1f} > -DI={minus_di:.1f}"}
            else:
                bear += 5
                detail['adx'] = {'dir': 'BEAR', 'pts': 5,
                    'text': f"ADX={adx_val:.1f} (قوی) | -DI={minus_di:.1f} > +DI={plus_di:.1f}"}
        else:
            detail['adx'] = {'dir': 'WEAK', 'pts': 0,
                'text': f"ADX={adx_val:.1f} – روند ضعیف یا رنج"}

        # ══════════════════════════════════════════════════════════════
        # فاز 2 – ساختار SMC (25 pts)
        # ══════════════════════════════════════════════════════════════

        # Market Structure (12 pts)
        ms_d = smc_data.get('market_structure', {}) if isinstance(smc_data, dict) else {}
        ms_trend = ms_d.get('trend', '') or ''
        ms_desc  = ms_d.get('description', '') or ''
        bos_cnt  = self._safe_float(ms_d.get('recent_bos', 0))
        choch_cnt= self._safe_float(ms_d.get('recent_choch', 0))
        if 'BULLISH' in ms_trend:
            bull += 12
            detail['ms'] = {'dir': 'BULL', 'pts': 12,
                'text': f"ساختار صعودی | BOS:{int(bos_cnt)} CHoCH:{int(choch_cnt)} | {ms_desc}"}
        elif 'BEARISH' in ms_trend:
            bear += 12
            detail['ms'] = {'dir': 'BEAR', 'pts': 12,
                'text': f"ساختار نزولی | BOS:{int(bos_cnt)} CHoCH:{int(choch_cnt)} | {ms_desc}"}
        else:
            detail['ms'] = {'dir': 'NEUT', 'pts': 0,
                'text': f"ساختار خنثی | BOS:{int(bos_cnt)} CHoCH:{int(choch_cnt)}"}

        # Premium / Discount Zone (8 pts)
        pd_d = smc_data.get('premium_discount', {}) if isinstance(smc_data, dict) else {}
        pd_zone = pd_d.get('current_zone', '') if isinstance(pd_d, dict) else ''
        pd_pct  = self._safe_float(pd_d.get('zone_percent', 0)) if isinstance(pd_d, dict) else 0
        if pd_zone == 'DISCOUNT':
            bull += 8
            detail['pd'] = {'dir': 'BULL', 'pts': 8,
                'text': f"قیمت در Discount Zone ({pd_pct:.1f}%) – بهترین ناحیه خرید"}
        elif pd_zone == 'PREMIUM':
            bear += 8
            detail['pd'] = {'dir': 'BEAR', 'pts': 8,
                'text': f"قیمت در Premium Zone ({pd_pct:.1f}%) – بهترین ناحیه فروش"}
        else:
            detail['pd'] = {'dir': 'NEUT', 'pts': 0, 'text': "قیمت در EQ Zone – میانه رنج"}

        # Liquidity Sweep (5 pts)
        liq_raw = smc_data.get('liquidity', []) if isinstance(smc_data, dict) else []
        liq_list = liq_raw if isinstance(liq_raw, list) else []
        if liq_list:
            last_liq = liq_list[-1] if isinstance(liq_list[-1], dict) else {}
            liq_sig = last_liq.get('signal', '') or ''
            liq_lvl = self._safe_float(last_liq.get('level', 0))
            if liq_sig == 'BULLISH':
                bull += 5
                detail['liq'] = {'dir': 'BULL', 'pts': 5,
                    'text': f"Liquidity Sweep صعودی | سطح: {self._fp(liq_lvl)}"}
            elif liq_sig == 'BEARISH':
                bear += 5
                detail['liq'] = {'dir': 'BEAR', 'pts': 5,
                    'text': f"Liquidity Sweep نزولی | سطح: {self._fp(liq_lvl)}"}
            else:
                detail['liq'] = {'dir': 'NEUT', 'pts': 0, 'text': "Liquidity Sweep فعالی نیست"}
        else:
            detail['liq'] = {'dir': 'NEUT', 'pts': 0, 'text': "Liquidity Sweep فعالی نیست"}

        # ══════════════════════════════════════════════════════════════
        # فاز 3 – مومنتوم ترکیبی (25 pts)
        # ══════════════════════════════════════════════════════════════

        # RSI (10 pts)
        rsi_d  = ind_data.get('RSI', {}) or {}
        rsi_v  = self._safe_float(rsi_d.get('value', 50), 50)
        if rsi_d.get('oversold') or rsi_v < 33:
            bull += 10
            detail['rsi'] = {'dir': 'BULL', 'pts': 10,
                'text': f"RSI={rsi_v:.1f} – اشباع فروش | برگشت صعودی محتمل"}
        elif rsi_d.get('overbought') or rsi_v > 67:
            bear += 10
            detail['rsi'] = {'dir': 'BEAR', 'pts': 10,
                'text': f"RSI={rsi_v:.1f} – اشباع خرید | برگشت نزولی محتمل"}
        elif rsi_v > 55:
            bull += 5
            detail['rsi'] = {'dir': 'BULL_M', 'pts': 5,
                'text': f"RSI={rsi_v:.1f} – مومنتوم صعودی ملایم"}
        elif rsi_v < 45:
            bear += 5
            detail['rsi'] = {'dir': 'BEAR_M', 'pts': 5,
                'text': f"RSI={rsi_v:.1f} – مومنتوم نزولی ملایم"}
        else:
            detail['rsi'] = {'dir': 'NEUT', 'pts': 0,
                'text': f"RSI={rsi_v:.1f} – خنثی"}

        # MACD (8 pts)
        macd_d    = ind_data.get('MACD', {}) or {}
        macd_v    = self._safe_float(macd_d.get('macd', 0))
        macd_hist = self._safe_float(macd_d.get('histogram', 0))
        macd_sig  = macd_d.get('trend', '') or ''
        if 'BULLISH' in macd_sig:
            bull += 8
            detail['macd'] = {'dir': 'BULL', 'pts': 8,
                'text': f"MACD کراس صعودی | MACD={self._fp(macd_v)} | Hist={self._fp(macd_hist)}"}
        elif 'BEARISH' in macd_sig:
            bear += 8
            detail['macd'] = {'dir': 'BEAR', 'pts': 8,
                'text': f"MACD کراس نزولی | MACD={self._fp(macd_v)} | Hist={self._fp(macd_hist)}"}
        elif macd_hist > 0:
            bull += 4
            detail['macd'] = {'dir': 'BULL_M', 'pts': 4,
                'text': f"MACD هیستوگرام مثبت={self._fp(macd_hist)}"}
        else:
            bear += 4
            detail['macd'] = {'dir': 'BEAR_M', 'pts': 4,
                'text': f"MACD هیستوگرام منفی={self._fp(macd_hist)}"}

        # Stochastic (7 pts)
        stoch_d  = ind_data.get('STOCHASTIC', {}) or {}
        stoch_k  = self._safe_float(stoch_d.get('k', 50), 50)
        stoch_dv = self._safe_float(stoch_d.get('d', 50), 50)
        if (stoch_d.get('oversold') or stoch_k < 22) and stoch_k > stoch_dv:
            bull += 7
            detail['stoch'] = {'dir': 'BULL', 'pts': 7,
                'text': f"Stoch اشباع+کراس صعودی | K={stoch_k:.1f} D={stoch_dv:.1f}"}
        elif (stoch_d.get('overbought') or stoch_k > 78) and stoch_k < stoch_dv:
            bear += 7
            detail['stoch'] = {'dir': 'BEAR', 'pts': 7,
                'text': f"Stoch اشباع+کراس نزولی | K={stoch_k:.1f} D={stoch_dv:.1f}"}
        elif stoch_k > stoch_dv:
            bull += 3
            detail['stoch'] = {'dir': 'BULL_M', 'pts': 3,
                'text': f"Stoch کراس صعودی | K={stoch_k:.1f} D={stoch_dv:.1f}"}
        elif stoch_k < stoch_dv:
            bear += 3
            detail['stoch'] = {'dir': 'BEAR_M', 'pts': 3,
                'text': f"Stoch کراس نزولی | K={stoch_k:.1f} D={stoch_dv:.1f}"}
        else:
            detail['stoch'] = {'dir': 'NEUT', 'pts': 0,
                'text': f"Stoch خنثی | K={stoch_k:.1f} D={stoch_dv:.1f}"}

        # ══════════════════════════════════════════════════════════════
        # فاز 4 – ناحیه ورود (20 pts)
        # ══════════════════════════════════════════════════════════════
        ob_list  = smc_data.get('order_blocks', []) if isinstance(smc_data, dict) else []
        fvg_list = smc_data.get('fvg', []) if isinstance(smc_data, dict) else []
        ob_list  = ob_list  if isinstance(ob_list, list)  else []
        fvg_list = fvg_list if isinstance(fvg_list, list) else []

        active_ob  = None
        active_fvg = None

        # Order Block (10 pts)
        for ob in ob_list:
            if not isinstance(ob, dict):
                continue
            ob_lo = self._safe_float(ob.get('bottom', 0))
            ob_hi = self._safe_float(ob.get('top', 0))
            if ob_lo <= 0 or ob_hi <= 0:
                continue
            if ob_lo - atr * 0.5 <= cp <= ob_hi + atr * 0.5:
                ob_type = ob.get('type', '')
                if ob_type == 'BULLISH_OB':
                    bull += 10
                    active_ob = ob
                    detail['ob'] = {'dir': 'BULL', 'pts': 10,
                        'text': f"Order Block صعودی | {self._fp(ob_lo)} – {self._fp(ob_hi)}"}
                    break
                elif ob_type == 'BEARISH_OB':
                    bear += 10
                    active_ob = ob
                    detail['ob'] = {'dir': 'BEAR', 'pts': 10,
                        'text': f"Order Block نزولی | {self._fp(ob_lo)} – {self._fp(ob_hi)}"}
                    break
        if 'ob' not in detail:
            detail['ob'] = {'dir': 'NONE', 'pts': 0, 'text': "قیمت خارج از Order Block"}

        # FVG (6 pts)
        for fvg in reversed(fvg_list):
            if not isinstance(fvg, dict):
                continue
            fvg_lo = self._safe_float(fvg.get('bottom', 0))
            fvg_hi = self._safe_float(fvg.get('top', 0))
            if fvg_lo <= 0 or fvg_hi <= 0:
                continue
            if fvg_lo - atr * 0.3 <= cp <= fvg_hi + atr * 0.3:
                fvg_type = fvg.get('type', '')
                if fvg_type == 'BULLISH_FVG':
                    bull += 6
                    active_fvg = fvg
                    detail['fvg'] = {'dir': 'BULL', 'pts': 6,
                        'text': f"FVG صعودی | {self._fp(fvg_lo)} – {self._fp(fvg_hi)}"}
                    break
                elif fvg_type == 'BEARISH_FVG':
                    bear += 6
                    active_fvg = fvg
                    detail['fvg'] = {'dir': 'BEAR', 'pts': 6,
                        'text': f"FVG نزولی | {self._fp(fvg_lo)} – {self._fp(fvg_hi)}"}
                    break
        if 'fvg' not in detail:
            detail['fvg'] = {'dir': 'NONE', 'pts': 0, 'text': "قیمت خارج از FVG"}

        # Supply / Demand Zone (4 pts)
        sd_d = smc_data.get('supply_demand', {}) if isinstance(smc_data, dict) else {}
        sd_d = sd_d if isinstance(sd_d, dict) else {}
        demand_z = sd_d.get('nearest_demand')
        supply_z = sd_d.get('nearest_supply')
        if isinstance(demand_z, dict):
            dz_lo = self._safe_float(demand_z.get('bottom', 0))
            dz_hi = self._safe_float(demand_z.get('top', 0))
            if dz_lo > 0 and dz_lo - atr <= cp <= dz_hi + atr:
                bull += 4
                detail['sd'] = {'dir': 'BULL', 'pts': 4,
                    'text': f"Demand Zone | {self._fp(dz_lo)} – {self._fp(dz_hi)}"}
        if 'sd' not in detail and isinstance(supply_z, dict):
            sz_lo = self._safe_float(supply_z.get('bottom', 0))
            sz_hi = self._safe_float(supply_z.get('top', 0))
            if sz_hi > 0 and sz_lo - atr <= cp <= sz_hi + atr:
                bear += 4
                detail['sd'] = {'dir': 'BEAR', 'pts': 4,
                    'text': f"Supply Zone | {self._fp(sz_lo)} – {self._fp(sz_hi)}"}
        if 'sd' not in detail:
            detail['sd'] = {'dir': 'NONE', 'pts': 0, 'text': "خارج از Supply/Demand Zone"}

        # ══════════════════════════════════════════════════════════════
        # فاز 5 – تأییدیه (20 pts)
        # ══════════════════════════════════════════════════════════════

        # Bollinger Bands (6 pts)
        bb_d    = ind_data.get('BOLLINGER', {}) or {}
        bb_sig  = bb_d.get('signal', '') or ''
        bb_pct  = self._safe_float(bb_d.get('percent_b', 0.5), 0.5)
        bb_lo   = self._safe_float(bb_d.get('lower', 0))
        bb_hi   = self._safe_float(bb_d.get('upper', 0))
        bb_mid  = self._safe_float(bb_d.get('middle', 0))
        if bb_sig == 'OVERSOLD' or bb_pct < 0.1:
            bull += 6
            detail['bb'] = {'dir': 'BULL', 'pts': 6,
                'text': f"BB کف | Lower={self._fp(bb_lo)} | %B={bb_pct:.2f}"}
        elif bb_sig == 'OVERBOUGHT' or bb_pct > 0.9:
            bear += 6
            detail['bb'] = {'dir': 'BEAR', 'pts': 6,
                'text': f"BB سقف | Upper={self._fp(bb_hi)} | %B={bb_pct:.2f}"}
        else:
            detail['bb'] = {'dir': 'NEUT', 'pts': 0,
                'text': f"BB خنثی | Mid={self._fp(bb_mid)} | %B={bb_pct:.2f}"}

        # Candlestick Patterns (8 pts)
        candles = pattern_data.get('candlestick_patterns', []) if isinstance(pattern_data, dict) else []
        candles = candles if isinstance(candles, list) else []
        candle_added = False
        for c in reversed(candles[-4:]):
            if not isinstance(c, dict):
                continue
            c_type = c.get('type', '') or ''
            c_str  = c.get('strength', 'MEDIUM') or 'MEDIUM'
            c_name = c.get('pattern', 'کندل') or 'کندل'
            pts = 8 if c_str == 'STRONG' else 5
            if c_type == 'BULLISH':
                bull += pts
                detail['candle'] = {'dir': 'BULL', 'pts': pts,
                    'text': f"الگوی {c_name} صعودی ({c_str})"}
                candle_added = True
                break
            elif c_type == 'BEARISH':
                bear += pts
                detail['candle'] = {'dir': 'BEAR', 'pts': pts,
                    'text': f"الگوی {c_name} نزولی ({c_str})"}
                candle_added = True
                break
        if not candle_added:
            detail['candle'] = {'dir': 'NEUT', 'pts': 0,
                'text': "الگوی کندلی تأییدکننده‌ای مشاهده نشد"}

        # Volume / MFI (6 pts)
        mfi_d  = ind_data.get('MFI', {}) or {}
        mfi_v  = self._safe_float(mfi_d.get('value', 50), 50)
        if mfi_v < 25:
            bull += 6
            detail['vol'] = {'dir': 'BULL', 'pts': 6,
                'text': f"MFI={mfi_v:.1f} – فشار خرید قوی با حجم"}
        elif mfi_v > 75:
            bear += 6
            detail['vol'] = {'dir': 'BEAR', 'pts': 6,
                'text': f"MFI={mfi_v:.1f} – فشار فروش قوی با حجم"}
        elif mfi_v > 58:
            bull += 3
            detail['vol'] = {'dir': 'BULL_M', 'pts': 3,
                'text': f"MFI={mfi_v:.1f} – جریان پول در جهت صعود"}
        elif mfi_v < 42:
            bear += 3
            detail['vol'] = {'dir': 'BEAR_M', 'pts': 3,
                'text': f"MFI={mfi_v:.1f} – جریان پول در جهت نزول"}
        else:
            detail['vol'] = {'dir': 'NEUT', 'pts': 0,
                'text': f"MFI={mfi_v:.1f} – جریان پول خنثی"}

        # ══════════════════════════════════════════════════════════════
        # محاسبه نهایی
        # ══════════════════════════════════════════════════════════════
        total = bull + bear
        confidence = (max(bull, bear) / total * 100) if total > 0 else 50.0

        if bull > bear and confidence >= 62:
            signal_type = 'LONG'
            reasons = [v['text'] for v in detail.values()
                       if v['dir'] in ('BULL', 'BULL_M')]
        elif bear > bull and confidence >= 62:
            signal_type = 'SHORT'
            reasons = [v['text'] for v in detail.values()
                       if v['dir'] in ('BEAR', 'BEAR_M')]
        else:
            signal_type = 'NEUTRAL'
            reasons = [v['text'] for v in detail.values() if v['pts'] > 0][:5]

        entry, sl, tp1, tp2, tp3 = self._calc_subarashi_levels(
            signal_type, ind_data, smc_data, pattern_data,
            active_ob, active_fvg, atr
        )

        risk_percent = 0.0
        if entry is not None and sl is not None and entry > 0:
            risk_percent = abs(entry - sl) / entry * 100

        return {
            'symbol':        self.symbol,
            'timeframe':     self.timeframe,
            'signal_type':   signal_type,
            'confidence':    round(confidence, 1),
            'bull_score':    bull,
            'bear_score':    bear,
            'bullish_score': bull,
            'bearish_score': bear,
            'entry':         entry,
            'stop_loss':     sl,
            'take_profit_1': tp1,
            'take_profit_2': tp2,
            'take_profit_3': tp3,
            'risk_percent':  round(risk_percent, 3),
            'reasons':       reasons[:8],
            'detail':        detail,
            'atr':           atr,
            'current_price': cp,
            'indicators':    ind_data,
            'smc':           smc_data,
            'patterns':      pattern_data,
            'active_ob':     active_ob,
            'active_fvg':    active_fvg,
        }

    def _calc_subarashi_levels(
        self,
        signal_type: str,
        ind_data: dict,
        smc_data: dict,
        pattern_data: dict,
        active_ob,
        active_fvg,
        atr: float
    ) -> Tuple:
        """محاسبه دقیق نقاط ورود، استاپ لاس و تارگت‌ها"""
        cp = self._safe_float(self.df['close'].iloc[-1])

        if signal_type == 'NEUTRAL':
            return None, None, None, None, None

        sd_d     = smc_data.get('supply_demand', {}) if isinstance(smc_data, dict) else {}
        sd_d     = sd_d if isinstance(sd_d, dict) else {}
        psar_d   = ind_data.get('PSAR', {}) or {}
        psar_val = self._safe_float(psar_d.get('value', 0))

        if signal_type == 'LONG':
            # ── ورود ──────────────────────────────────────────────────
            entry_cands = [cp]
            if isinstance(active_ob, dict) and active_ob.get('type') == 'BULLISH_OB':
                ob_lo = self._safe_float(active_ob.get('bottom', 0))
                ob_hi = self._safe_float(active_ob.get('top', 0))
                if ob_lo > 0:
                    entry_cands.append((ob_lo + ob_hi) / 2)
            if isinstance(active_fvg, dict) and active_fvg.get('type') == 'BULLISH_FVG':
                fvg_lo = self._safe_float(active_fvg.get('bottom', 0))
                if fvg_lo > 0:
                    entry_cands.append(fvg_lo + atr * 0.1)
            dz = sd_d.get('nearest_demand')
            if isinstance(dz, dict):
                dz_hi = self._safe_float(dz.get('top', 0))
                if 0 < dz_hi < cp + atr * 4:
                    entry_cands.append(dz_hi + atr * 0.05)
            entry = min(entry_cands)

            # ── استاپ لاس ─────────────────────────────────────────────
            swing_lo = self._safe_float(self.df['low'].tail(20).min())
            sl_cands = [swing_lo - atr * 1.2]
            if isinstance(active_ob, dict):
                ob_lo = self._safe_float(active_ob.get('bottom', 0))
                if ob_lo > 0:
                    sl_cands.append(ob_lo - atr * 0.8)
            if isinstance(active_fvg, dict):
                fvg_lo = self._safe_float(active_fvg.get('bottom', 0))
                if fvg_lo > 0:
                    sl_cands.append(fvg_lo - atr * 0.8)
            if isinstance(dz, dict):
                dz_lo = self._safe_float(dz.get('bottom', 0))
                if dz_lo > 0:
                    sl_cands.append(dz_lo - atr * 0.5)
            if psar_val > 0 and psar_val < entry:
                sl_cands.append(psar_val - atr * 0.3)
            # حمایت نزدیک
            try:
                sr = pattern_data.get('support_resistance', {}) if isinstance(pattern_data, dict) else {}
                ns = sr.get('nearest_support') if isinstance(sr, dict) else None
                if isinstance(ns, dict):
                    ns_p = self._safe_float(ns.get('price', 0))
                    if 0 < ns_p < entry:
                        sl_cands.append(ns_p - atr * 0.5)
            except Exception:
                pass

            sl_raw = min(sl_cands)
            sl = max(sl_raw, entry - atr * 3.5)   # سقف ریسک 3.5xATR

            risk = entry - sl
            if risk < atr * 0.4:
                risk = atr * 1.5
                sl = entry - risk

            # ── تارگت‌ها ──────────────────────────────────────────────
            tp1 = entry + risk * 1.5
            tp2 = entry + risk * 2.5
            tp3 = entry + risk * 4.0

            # تنظیم براساس مقاومت‌های نزدیک
            try:
                sr = pattern_data.get('support_resistance', {}) if isinstance(pattern_data, dict) else {}
                res_levels = sr.get('resistance_levels', []) if isinstance(sr, dict) else []
                res_prices = sorted([
                    self._safe_float(r.get('price', 0))
                    for r in res_levels
                    if isinstance(r, dict) and entry < self._safe_float(r.get('price', 0)) < entry + risk * 6
                ])
                if len(res_prices) >= 1 and res_prices[0] < tp1:
                    tp1 = res_prices[0] - atr * 0.1
                if len(res_prices) >= 2 and res_prices[1] < tp2:
                    tp2 = res_prices[1] - atr * 0.1
            except Exception:
                pass

        else:  # SHORT
            # ── ورود ──────────────────────────────────────────────────
            entry_cands = [cp]
            if isinstance(active_ob, dict) and active_ob.get('type') == 'BEARISH_OB':
                ob_lo = self._safe_float(active_ob.get('bottom', 0))
                ob_hi = self._safe_float(active_ob.get('top', 0))
                if ob_hi > 0:
                    entry_cands.append((ob_lo + ob_hi) / 2)
            if isinstance(active_fvg, dict) and active_fvg.get('type') == 'BEARISH_FVG':
                fvg_hi = self._safe_float(active_fvg.get('top', 0))
                if fvg_hi > 0:
                    entry_cands.append(fvg_hi - atr * 0.1)
            sz = sd_d.get('nearest_supply')
            if isinstance(sz, dict):
                sz_lo = self._safe_float(sz.get('bottom', 0))
                if 0 < sz_lo > cp - atr * 4:
                    entry_cands.append(sz_lo - atr * 0.05)
            entry = max(entry_cands)

            # ── استاپ لاس ─────────────────────────────────────────────
            swing_hi = self._safe_float(self.df['high'].tail(20).max())
            sl_cands = [swing_hi + atr * 1.2]
            if isinstance(active_ob, dict):
                ob_hi = self._safe_float(active_ob.get('top', 0))
                if ob_hi > 0:
                    sl_cands.append(ob_hi + atr * 0.8)
            if isinstance(active_fvg, dict):
                fvg_hi = self._safe_float(active_fvg.get('top', 0))
                if fvg_hi > 0:
                    sl_cands.append(fvg_hi + atr * 0.8)
            if isinstance(sz, dict):
                sz_hi = self._safe_float(sz.get('top', 0))
                if sz_hi > 0:
                    sl_cands.append(sz_hi + atr * 0.5)
            if psar_val > 0 and psar_val > entry:
                sl_cands.append(psar_val + atr * 0.3)
            try:
                sr = pattern_data.get('support_resistance', {}) if isinstance(pattern_data, dict) else {}
                nr = sr.get('nearest_resistance') if isinstance(sr, dict) else None
                if isinstance(nr, dict):
                    nr_p = self._safe_float(nr.get('price', 0))
                    if nr_p > entry:
                        sl_cands.append(nr_p + atr * 0.5)
            except Exception:
                pass

            sl_raw = max(sl_cands)
            sl = min(sl_raw, entry + atr * 3.5)

            risk = sl - entry
            if risk < atr * 0.4:
                risk = atr * 1.5
                sl = entry + risk

            # ── تارگت‌ها ──────────────────────────────────────────────
            tp1 = entry - risk * 1.5
            tp2 = entry - risk * 2.5
            tp3 = entry - risk * 4.0

            try:
                sr = pattern_data.get('support_resistance', {}) if isinstance(pattern_data, dict) else {}
                sup_levels = sr.get('support_levels', []) if isinstance(sr, dict) else []
                sup_prices = sorted([
                    self._safe_float(s.get('price', 0))
                    for s in sup_levels
                    if isinstance(s, dict) and entry - risk * 6 < self._safe_float(s.get('price', 0)) < entry
                ], reverse=True)
                if len(sup_prices) >= 1 and sup_prices[0] > tp1:
                    tp1 = sup_prices[0] + atr * 0.1
                if len(sup_prices) >= 2 and sup_prices[1] > tp2:
                    tp2 = sup_prices[1] + atr * 0.1
            except Exception:
                pass

        return (
            round(float(entry), 8),
            round(float(sl),    8),
            round(float(tp1),   8),
            round(float(tp2),   8),
            round(float(tp3),   8),
        )
    
    def _calculate_entry_exit(self, signal_type: str, ind_data: dict, smc_data: dict, pattern_data: dict) -> Tuple:
        current_price = self.df['close'].iloc[-1]
        atr = ind_data.get('ATR', {}).get('value', current_price * 0.01)

        if signal_type == 'LONG':
            # Entry: بهترین نقطه ورود - اگر قیمت در OB یا FVG است پایین آن ناحیه وارد شو
            ob_list = [ob for ob in smc_data.get('order_blocks', []) if ob['type'] == 'BULLISH_OB']
            fvg_list = [f for f in smc_data.get('fvg', []) if f['type'] == 'BULLISH_FVG']
            demand = smc_data.get('supply_demand', {}).get('nearest_demand')

            entry_candidates = [current_price]
            if ob_list:
                ob = ob_list[0]
                if ob['bottom'] <= current_price <= ob['top']:
                    entry_candidates.append(ob['bottom'] + atr * 0.2)
            if fvg_list:
                fvg = fvg_list[-1]
                if fvg['bottom'] <= current_price <= fvg['top']:
                    entry_candidates.append(fvg['bottom'] + atr * 0.1)
            if demand and demand['top'] <= current_price <= demand['top'] + atr * 2:
                entry_candidates.append(demand['top'] + atr * 0.1)
            entry = min(entry_candidates)

            # SL: زیر ساختار معتبر با فاصله کافی (min = بیشترین فاصله = امن‌ترین)
            swing_low_20 = self.df['low'].tail(20).min()
            sl_candidates = [swing_low_20 - atr * 1.5]

            if demand:
                sl_candidates.append(demand['bottom'] - atr * 1.0)
            if ob_list:
                sl_candidates.append(ob_list[0]['bottom'] - atr * 1.0)
            support = pattern_data.get('support_resistance', {}).get('nearest_support')
            if support:
                sl_candidates.append(support['price'] - atr * 1.0)

            # SL نباید از entry بیشتر از 3xATR فاصله داشته باشد
            sl_raw = min(sl_candidates)
            sl = max(sl_raw, entry - atr * 3.0)

            risk = entry - sl
            if risk <= 0:
                risk = atr * 1.5
                sl = entry - risk
            tp1 = entry + risk * 1.5
            tp2 = entry + risk * 2.5
            tp3 = entry + risk * 4.0

        elif signal_type == 'SHORT':
            # Entry: بهترین نقطه ورود برای شورت
            ob_list = [ob for ob in smc_data.get('order_blocks', []) if ob['type'] == 'BEARISH_OB']
            fvg_list = [f for f in smc_data.get('fvg', []) if f['type'] == 'BEARISH_FVG']
            supply = smc_data.get('supply_demand', {}).get('nearest_supply')

            entry_candidates = [current_price]
            if ob_list:
                ob = ob_list[0]
                if ob['bottom'] <= current_price <= ob['top']:
                    entry_candidates.append(ob['top'] - atr * 0.2)
            if fvg_list:
                fvg = fvg_list[-1]
                if fvg['bottom'] <= current_price <= fvg['top']:
                    entry_candidates.append(fvg['top'] - atr * 0.1)
            if supply and supply['bottom'] - atr * 2 <= current_price <= supply['bottom']:
                entry_candidates.append(supply['bottom'] - atr * 0.1)
            entry = max(entry_candidates)

            # SL: بالای ساختار معتبر با فاصله کافی (max = بیشترین فاصله = امن‌ترین)
            swing_high_20 = self.df['high'].tail(20).max()
            sl_candidates = [swing_high_20 + atr * 1.5]

            if supply:
                sl_candidates.append(supply['top'] + atr * 1.0)
            if ob_list:
                sl_candidates.append(ob_list[0]['top'] + atr * 1.0)
            resistance = pattern_data.get('support_resistance', {}).get('nearest_resistance')
            if resistance:
                sl_candidates.append(resistance['price'] + atr * 1.0)

            # SL نباید از entry بیشتر از 3xATR فاصله داشته باشد
            sl_raw = max(sl_candidates)
            sl = min(sl_raw, entry + atr * 3.0)

            risk = sl - entry
            if risk <= 0:
                risk = atr * 1.5
                sl = entry + risk
            tp1 = entry - risk * 1.5
            tp2 = entry - risk * 2.5
            tp3 = entry - risk * 4.0

        else:
            entry = current_price
            sl = None
            tp1 = None
            tp2 = None
            tp3 = None

        return (
            float(entry) if entry is not None else None,
            float(sl) if sl is not None else None,
            float(tp1) if tp1 is not None else None,
            float(tp2) if tp2 is not None else None,
            float(tp3) if tp3 is not None else None
        )
    
    def generate_sniper_entry(self) -> dict:
        subarashi = self.generate_subarashi_signal()
        
        sniper_conditions = []
        sniper_score = 0
        
        smc = subarashi['smc']
        ind_data = subarashi['indicators']
        pattern_data = subarashi['patterns']
        
        premium_discount = smc.get('premium_discount', {})
        if subarashi['signal_type'] == 'LONG' and premium_discount.get('current_zone') == 'DISCOUNT':
            sniper_score += 20
            sniper_conditions.append('ورود در منطقه Discount برای لانگ')
        elif subarashi['signal_type'] == 'SHORT' and premium_discount.get('current_zone') == 'PREMIUM':
            sniper_score += 20
            sniper_conditions.append('ورود در منطقه Premium برای شورت')
        
        order_blocks = smc.get('order_blocks', [])
        current_price = self.df['close'].iloc[-1]
        for ob in order_blocks:
            if ob['bottom'] <= current_price <= ob['top']:
                if (subarashi['signal_type'] == 'LONG' and ob['type'] == 'BULLISH_OB') or \
                   (subarashi['signal_type'] == 'SHORT' and ob['type'] == 'BEARISH_OB'):
                    sniper_score += 25
                    sniper_conditions.append('قیمت در Order Block معتبر')
                    break
        
        fvg = smc.get('fvg', [])
        for f in fvg:
            if f['bottom'] <= current_price <= f['top']:
                if (subarashi['signal_type'] == 'LONG' and f['type'] == 'BULLISH_FVG') or \
                   (subarashi['signal_type'] == 'SHORT' and f['type'] == 'BEARISH_FVG'):
                    sniper_score += 20
                    sniper_conditions.append('قیمت در FVG')
                    break
        
        liquidity = smc.get('liquidity', [])
        if liquidity:
            last_liq = liquidity[-1]
            if (subarashi['signal_type'] == 'LONG' and last_liq['signal'] == 'BULLISH') or \
               (subarashi['signal_type'] == 'SHORT' and last_liq['signal'] == 'BEARISH'):
                sniper_score += 15
                sniper_conditions.append('Liquidity Sweep تایید شده')
        
        bos_choch = smc.get('bos_choch', [])
        for signal in bos_choch[-3:]:
            if (subarashi['signal_type'] == 'LONG' and signal['direction'] == 'BULLISH') or \
               (subarashi['signal_type'] == 'SHORT' and signal['direction'] == 'BEARISH'):
                sniper_score += 10
                sniper_conditions.append(f"{signal['type']} {signal['direction']}")
                break
        
        if subarashi['confidence'] >= 75:
            sniper_score += 10
            sniper_conditions.append('اعتماد بالای سیگنال اصلی')
        
        is_sniper_entry = sniper_score >= 50 and subarashi['signal_type'] != 'NEUTRAL'
        
        # Calculate sniper-specific entry/exit with tighter parameters
        if is_sniper_entry:
            sniper_entry, sniper_sl, sniper_tp1, sniper_tp2, sniper_tp3 = self._calculate_sniper_entry_exit(
                subarashi['signal_type'], ind_data, smc, pattern_data
            )
            
            # Calculate sniper-specific risk
            sniper_risk_percent = 0
            if sniper_entry and sniper_sl:
                sniper_risk_percent = abs(sniper_entry - sniper_sl) / sniper_entry * 100
            
            return {
                **subarashi,
                'is_sniper_entry': is_sniper_entry,
                'sniper_score': sniper_score,
                'sniper_conditions': sniper_conditions,
                'sniper_quality': self._get_sniper_quality(sniper_score),
                # Override with sniper-specific values
                'entry': sniper_entry,
                'stop_loss': sniper_sl,
                'take_profit_1': sniper_tp1,
                'take_profit_2': sniper_tp2,
                'take_profit_3': sniper_tp3,
                'risk_percent': round(sniper_risk_percent, 2)
            }
        else:
            return {
                **subarashi,
                'is_sniper_entry': is_sniper_entry,
                'sniper_score': sniper_score,
                'sniper_conditions': sniper_conditions,
                'sniper_quality': self._get_sniper_quality(sniper_score)
            }
    
    def _calculate_sniper_entry_exit(self, signal_type: str, ind_data: dict, smc_data: dict, pattern_data: dict) -> Tuple:
        """
        محاسبه نقاط ورود و خروج اسنایپری با دقت بالاتر
        استاپ لاس تنگ‌تر و تارگت‌های واقع‌بینانه‌تر
        """
        current_price = self.df['close'].iloc[-1]
        atr = ind_data.get('ATR', {}).get('value', current_price * 0.01)
        
        if signal_type == 'LONG':
            order_blocks = [ob for ob in smc_data.get('order_blocks', []) if ob['type'] == 'BULLISH_OB']
            fvg_list = [f for f in smc_data.get('fvg', []) if f['type'] == 'BULLISH_FVG']

            if order_blocks and order_blocks[0]['bottom'] <= current_price <= order_blocks[0]['top']:
                entry = order_blocks[0]['bottom'] + atr * 0.1
            elif fvg_list and fvg_list[-1]['bottom'] <= current_price <= fvg_list[-1]['top']:
                entry = fvg_list[-1]['bottom'] + atr * 0.1
            else:
                entry = current_price

            swing_low_15 = self.df['low'].tail(15).min()
            sl_candidates = [swing_low_15 - atr * 1.2]
            if order_blocks:
                sl_candidates.append(order_blocks[0]['bottom'] - atr * 1.0)
            if fvg_list:
                sl_candidates.append(fvg_list[-1]['bottom'] - atr * 1.0)

            sl_raw = min(sl_candidates)
            sl = max(sl_raw, entry - atr * 3.0)

            risk = entry - sl
            if risk <= 0:
                risk = atr * 1.5
                sl = entry - risk
            tp1 = entry + risk * 1.5
            tp2 = entry + risk * 2.5
            tp3 = entry + risk * 3.5

        elif signal_type == 'SHORT':
            order_blocks = [ob for ob in smc_data.get('order_blocks', []) if ob['type'] == 'BEARISH_OB']
            fvg_list = [f for f in smc_data.get('fvg', []) if f['type'] == 'BEARISH_FVG']

            if order_blocks and order_blocks[0]['bottom'] <= current_price <= order_blocks[0]['top']:
                entry = order_blocks[0]['top'] - atr * 0.1
            elif fvg_list and fvg_list[-1]['bottom'] <= current_price <= fvg_list[-1]['top']:
                entry = fvg_list[-1]['top'] - atr * 0.1
            else:
                entry = current_price

            swing_high_15 = self.df['high'].tail(15).max()
            sl_candidates = [swing_high_15 + atr * 1.2]
            if order_blocks:
                sl_candidates.append(order_blocks[0]['top'] + atr * 1.0)
            if fvg_list:
                sl_candidates.append(fvg_list[-1]['top'] + atr * 1.0)

            sl_raw = max(sl_candidates)
            sl = min(sl_raw, entry + atr * 3.0)

            risk = sl - entry
            if risk <= 0:
                risk = atr * 1.5
                sl = entry + risk
            tp1 = entry - risk * 1.5
            tp2 = entry - risk * 2.5
            tp3 = entry - risk * 3.5

        else:
            entry = current_price
            sl = None
            tp1 = None
            tp2 = None
            tp3 = None
        
        return (
            float(entry) if entry is not None else None,
            float(sl) if sl is not None else None,
            float(tp1) if tp1 is not None else None,
            float(tp2) if tp2 is not None else None,
            float(tp3) if tp3 is not None else None
        )
    
    def _get_sniper_quality(self, score: int) -> str:
        if score >= 80:
            return 'A+ (عالی)'
        elif score >= 65:
            return 'A (خیلی خوب)'
        elif score >= 50:
            return 'B (خوب)'
        elif score >= 35:
            return 'C (متوسط)'
        else:
            return 'D (ضعیف)'

    def generate_detailed_entry_explanation(self, signal: dict) -> dict:
        """
        توضیحات کامل و حرفه‌ای برای هر بخش سیگنال
        - ایمن در برابر همه خطاها
        - از _fp و _safe_float استفاده می‌کند
        """
        ind_data     = signal.get('indicators', {}) or {}
        smc_data     = signal.get('smc', {}) or {}
        pattern_data = signal.get('patterns', {}) or {}
        detail       = signal.get('detail', {}) or {}

        cp    = self._safe_float(signal.get('current_price', self.df['close'].iloc[-1]))
        atr   = self._safe_float(signal.get('atr', 0))
        entry = signal.get('entry')
        sl    = signal.get('stop_loss')
        tp1   = signal.get('take_profit_1')
        tp2   = signal.get('take_profit_2')
        tp3   = signal.get('take_profit_3')
        stype = signal.get('signal_type', 'NEUTRAL')

        expl = {}

        # ── دلایل ورود ───────────────────────────────────────────────
        entry_reasons = []
        if entry is not None and stype != 'NEUTRAL':
            entry_f = self._safe_float(entry)

            # Order Block
            aob = signal.get('active_ob')
            if isinstance(aob, dict):
                ob_lo = self._safe_float(aob.get('bottom', 0))
                ob_hi = self._safe_float(aob.get('top', 0))
                ob_type_fa = 'تقاضا (خرید)' if stype == 'LONG' else 'عرضه (فروش)'
                entry_reasons.append(
                    f"ورود در Order Block {ob_type_fa} | محدوده: {self._fp(ob_lo)} – {self._fp(ob_hi)}")

            # FVG
            afvg = signal.get('active_fvg')
            if isinstance(afvg, dict):
                fvg_lo = self._safe_float(afvg.get('bottom', 0))
                fvg_hi = self._safe_float(afvg.get('top', 0))
                entry_reasons.append(
                    f"قیمت در FVG | محدوده: {self._fp(fvg_lo)} – {self._fp(fvg_hi)} | این شکاف مغناطیس قیمت است")

            # RSI
            rsi_d = ind_data.get('RSI', {}) or {}
            rsi_v = self._safe_float(rsi_d.get('value', 50), 50)
            if rsi_d.get('oversold') and stype == 'LONG':
                entry_reasons.append(f"RSI={rsi_v:.1f} در اشباع فروش → خریداران در حال ورودند")
            elif rsi_d.get('overbought') and stype == 'SHORT':
                entry_reasons.append(f"RSI={rsi_v:.1f} در اشباع خرید → فروشندگان در حال ورودند")

            # MACD
            macd_d = ind_data.get('MACD', {}) or {}
            macd_t = macd_d.get('trend', '') or ''
            macd_v = self._safe_float(macd_d.get('macd', 0))
            if 'BULLISH' in macd_t and stype == 'LONG':
                entry_reasons.append(f"MACD={self._fp(macd_v)} کراس صعودی – مومنتوم تأیید شد")
            elif 'BEARISH' in macd_t and stype == 'SHORT':
                entry_reasons.append(f"MACD={self._fp(macd_v)} کراس نزولی – مومنتوم تأیید شد")

            # EMA Alignment
            ema_det = detail.get('ema', {})
            if ema_det.get('dir') in ('BULL', 'BEAR'):
                entry_reasons.append(ema_det.get('text', ''))

            # Supertrend
            st_det = detail.get('supertrend', {})
            if st_det.get('dir') in ('BULL', 'BEAR'):
                entry_reasons.append(st_det.get('text', ''))

            # Premium/Discount
            pd_d = smc_data.get('premium_discount', {}) if isinstance(smc_data, dict) else {}
            pd_z = pd_d.get('current_zone', '') if isinstance(pd_d, dict) else ''
            if pd_z == 'DISCOUNT' and stype == 'LONG':
                entry_reasons.append("قیمت در Discount Zone – بهترین منطقه خرید در روند صعودی")
            elif pd_z == 'PREMIUM' and stype == 'SHORT':
                entry_reasons.append("قیمت در Premium Zone – بهترین منطقه فروش در روند نزولی")

            # Market Structure
            ms_d = smc_data.get('market_structure', {}) if isinstance(smc_data, dict) else {}
            ms_t = ms_d.get('trend', '') if isinstance(ms_d, dict) else ''
            ms_desc = ms_d.get('description', '') if isinstance(ms_d, dict) else ''
            if ms_t:
                entry_reasons.append(f"ساختار بازار: {ms_t} | {ms_desc}")

            if not entry_reasons:
                entry_reasons.append(
                    f"ورود در {self._fp(entry_f)} بر اساس ترکیب {len(detail)} اندیکاتور")
        expl['entry_reasons'] = [r for r in entry_reasons if r]

        # ── دلایل استاپ لاس ──────────────────────────────────────────
        sl_reasons = []
        if sl is not None and entry is not None and stype != 'NEUTRAL':
            sl_f   = self._safe_float(sl)
            ent_f  = self._safe_float(entry)
            risk_d = abs(ent_f - sl_f)
            atr_m  = (risk_d / atr) if atr > 0 else 0

            if stype == 'LONG':
                recent_low = self._safe_float(self.df['low'].tail(10).min())
                sl_reasons.append(
                    f"استاپ زیر پایین‌ترین نقطه ۱۰ کندل اخیر ({self._fp(recent_low)})")
                sd_d = smc_data.get('supply_demand', {}) if isinstance(smc_data, dict) else {}
                dz   = sd_d.get('nearest_demand') if isinstance(sd_d, dict) else None
                if isinstance(dz, dict):
                    dz_lo = self._safe_float(dz.get('bottom', 0))
                    if dz_lo > 0:
                        sl_reasons.append(
                            f"زیر Demand Zone ({self._fp(dz_lo)}) – شکست آن ایده را باطل می‌کند")
                aob = signal.get('active_ob')
                if isinstance(aob, dict):
                    ob_lo = self._safe_float(aob.get('bottom', 0))
                    sl_reasons.append(f"زیر Order Block ({self._fp(ob_lo)}) – شکست = ساختار شکسته")
            else:  # SHORT
                recent_high = self._safe_float(self.df['high'].tail(10).max())
                sl_reasons.append(
                    f"استاپ بالای بالاترین نقطه ۱۰ کندل اخیر ({self._fp(recent_high)})")
                sd_d = smc_data.get('supply_demand', {}) if isinstance(smc_data, dict) else {}
                sz   = sd_d.get('nearest_supply') if isinstance(sd_d, dict) else None
                if isinstance(sz, dict):
                    sz_hi = self._safe_float(sz.get('top', 0))
                    if sz_hi > 0:
                        sl_reasons.append(
                            f"بالای Supply Zone ({self._fp(sz_hi)}) – شکست آن ایده را باطل می‌کند")
                aob = signal.get('active_ob')
                if isinstance(aob, dict):
                    ob_hi = self._safe_float(aob.get('top', 0))
                    sl_reasons.append(f"بالای Order Block ({self._fp(ob_hi)}) – شکست = ساختار شکسته")

            sl_reasons.append(
                f"فاصله SL از ورود: {self._fp(risk_d)} | ({atr_m:.1f} × ATR) | ریسک بهینه")
        expl['sl_reasons'] = sl_reasons

        # ── دلایل تارگت‌ها ────────────────────────────────────────────
        tp_reasons = {}
        if entry is not None and sl is not None and tp1 is not None:
            ent_f = self._safe_float(entry)
            sl_f  = self._safe_float(sl)
            risk  = abs(ent_f - sl_f)
            if risk > 0:
                rr1 = abs(self._safe_float(tp1) - ent_f) / risk if tp1 is not None else 0
                rr2 = abs(self._safe_float(tp2) - ent_f) / risk if tp2 is not None else 0
                rr3 = abs(self._safe_float(tp3) - ent_f) / risk if tp3 is not None else 0
                tp_reasons['tp1'] = [
                    f"R:R = 1:{rr1:.1f} – هدف محافظه‌کارانه",
                    "بستن ۳۰-۵۰٪ پوزیشن در این سطح پیشنهاد می‌شود",
                    "بعد از رسیدن: استاپ را به بریک‌ایون منتقل کنید"
                ]
                tp_reasons['tp2'] = [
                    f"R:R = 1:{rr2:.1f} – هدف میانی",
                    "بستن ۳۰٪ دیگر از پوزیشن",
                    "بعد از رسیدن: استاپ را به TP1 منتقل کنید"
                ]
                tp_reasons['tp3'] = [
                    f"R:R = 1:{rr3:.1f} – هدف بلندمدت",
                    "باقی‌مانده پوزیشن را نگه دارید",
                    "بعد از رسیدن به TP2: اجازه دهید سود بدوند (Trailing Stop)"
                ]
        expl['tp_reasons'] = tp_reasons

        # ── شرایط باطل شدن معامله ────────────────────────────────────
        invalidation = []
        if stype == 'LONG' and sl is not None:
            invalidation.append(f"بسته شدن کندل زیر استاپ لاس {self._fp(sl)} → خروج فوری")
            invalidation.append("کراس نزولی EMA50 و EMA200 → روند تغییر کرده")
            invalidation.append("RSI زیر ۳۰ + کندل نزولی قوی → ادامه فشار فروش")
            invalidation.append("Supertrend تغییر به نزولی → سیگنال برعکس")
        elif stype == 'SHORT' and sl is not None:
            invalidation.append(f"بسته شدن کندل بالای استاپ لاس {self._fp(sl)} → خروج فوری")
            invalidation.append("کراس صعودی EMA50 و EMA200 → روند تغییر کرده")
            invalidation.append("RSI بالای ۷۰ + کندل صعودی قوی → ادامه فشار خرید")
            invalidation.append("Supertrend تغییر به صعودی → سیگنال برعکس")
        expl['invalidation'] = invalidation

        # ── پلن مدیریت معامله ─────────────────────────────────────────
        trade_plan = []
        if entry is not None and sl is not None and tp1 is not None:
            rp = self._safe_float(signal.get('risk_percent', 0))
            trade_plan.append(f"قدم ۱ – ثبت سفارش Limit در {self._fp(entry)} (یا Market اگر قیمت فعلی است)")
            trade_plan.append(f"قدم ۲ – استاپ لاس: {self._fp(sl)} | ریسک سرمایه: {rp:.2f}% (حداکثر ۲٪ توصیه می‌شود)")
            trade_plan.append(f"قدم ۳ – رسیدن به TP1 ({self._fp(tp1)}): نیمی از پوزیشن را ببندید")
            trade_plan.append(f"قدم ۴ – انتقال استاپ به بریک‌ایون ({self._fp(entry)}) → معامله بدون ریسک")
            if tp2 is not None:
                trade_plan.append(f"قدم ۵ – رسیدن به TP2 ({self._fp(tp2)}): ۳۰٪ دیگر ببندید، SL به TP1")
            if tp3 is not None:
                trade_plan.append(f"قدم ۶ – رسیدن به TP3 ({self._fp(tp3)}): باقیمانده را با Trailing Stop مدیریت کنید")
        expl['trade_plan'] = trade_plan

        # ── سطوح کلیدی بازار ─────────────────────────────────────────
        key_levels = {}
        try:
            pivots = pattern_data.get('pivot_points', {})
            if isinstance(pivots, dict):
                std = pivots.get('standard', {})
                if isinstance(std, dict):
                    for k, alias in [('pivot','pivot'),('r1','r1'),('r2','r2'),('s1','s1'),('s2','s2')]:
                        v = self._safe_float(std.get(k, 0))
                        if v > 0:
                            key_levels[alias] = v
        except Exception:
            pass
        try:
            fib = pattern_data.get('fibonacci', {})
            if isinstance(fib, dict):
                lvls = fib.get('levels', {})
                if isinstance(lvls, dict):
                    for pct, alias in [('38.2%','fib_382'),('50.0%','fib_500'),('61.8%','fib_618')]:
                        v = self._safe_float(lvls.get(pct, 0))
                        if v > 0:
                            key_levels[alias] = v
        except Exception:
            pass
        expl['key_levels'] = key_levels

        return expl

import pandas as pd
import numpy as np
from typing import List, Dict, Tuple, Optional
from config.settings import SMC_SETTINGS

class SMCAnalyzer:
    def __init__(self, df: pd.DataFrame):
        self.df = df.copy()
        self.settings = SMC_SETTINGS
    
    def analyze_all(self) -> dict:
        swing_points = self.identify_swing_points()
        bos_choch = self.detect_bos_choch(swing_points)
        fvg = self.detect_fvg()
        order_blocks = self.detect_order_blocks()
        supply_demand = self.identify_supply_demand_zones()
        premium_discount = self.calculate_premium_discount()
        liquidity = self.detect_liquidity_sweep()
        market_structure = self.analyze_market_structure(swing_points, bos_choch)
        
        return {
            'swing_points': swing_points,
            'bos_choch': bos_choch,
            'fvg': fvg,
            'order_blocks': order_blocks,
            'supply_demand': supply_demand,
            'premium_discount': premium_discount,
            'liquidity': liquidity,
            'market_structure': market_structure
        }
    
    def identify_swing_points(self) -> dict:
        lookback = self.settings['swing_lookback']
        highs = self.df['high'].values
        lows = self.df['low'].values
        
        swing_highs = []
        swing_lows = []
        
        for i in range(lookback, len(self.df) - lookback):
            if highs[i] == max(highs[i-lookback:i+lookback+1]):
                swing_highs.append({
                    'index': self.df.index[i],
                    'price': highs[i],
                    'position': i
                })
            
            if lows[i] == min(lows[i-lookback:i+lookback+1]):
                swing_lows.append({
                    'index': self.df.index[i],
                    'price': lows[i],
                    'position': i
                })
        
        return {
            'swing_highs': swing_highs,
            'swing_lows': swing_lows,
            'last_swing_high': swing_highs[-1] if swing_highs else None,
            'last_swing_low': swing_lows[-1] if swing_lows else None
        }
    
    def detect_bos_choch(self, swing_points: dict) -> List[Dict]:
        signals = []
        swing_highs = swing_points['swing_highs']
        swing_lows = swing_points['swing_lows']
        
        if len(swing_highs) < 2 or len(swing_lows) < 2:
            return signals
        
        current_price = self.df['close'].iloc[-1]
        
        for i in range(1, min(5, len(swing_highs))):
            prev_high = swing_highs[-(i+1)]['price']
            curr_high = swing_highs[-i]['price']
            
            if curr_high > prev_high:
                signals.append({
                    'type': 'BOS',
                    'direction': 'BULLISH',
                    'level': prev_high,
                    'description': f'شکست ساختار صعودی - سقف {prev_high:.5f} شکسته شد',
                    'strength': 'STRONG' if (curr_high - prev_high) / prev_high > 0.001 else 'MODERATE'
                })
        
        for i in range(1, min(5, len(swing_lows))):
            prev_low = swing_lows[-(i+1)]['price']
            curr_low = swing_lows[-i]['price']
            
            if curr_low < prev_low:
                signals.append({
                    'type': 'BOS',
                    'direction': 'BEARISH',
                    'level': prev_low,
                    'description': f'شکست ساختار نزولی - کف {prev_low:.5f} شکسته شد',
                    'strength': 'STRONG' if (prev_low - curr_low) / prev_low > 0.001 else 'MODERATE'
                })
        
        if len(swing_highs) >= 2 and len(swing_lows) >= 2:
            last_high = swing_highs[-1]['price']
            prev_high = swing_highs[-2]['price']
            last_low = swing_lows[-1]['price']
            prev_low = swing_lows[-2]['price']
            
            if last_high < prev_high and last_low < prev_low:
                if swing_highs[-1]['position'] > swing_lows[-1]['position']:
                    signals.append({
                        'type': 'CHoCH',
                        'direction': 'BEARISH',
                        'level': prev_low,
                        'description': 'تغییر کاراکتر بازار به نزولی - Lower Highs و Lower Lows',
                        'strength': 'VERY_STRONG'
                    })
            
            if last_high > prev_high and last_low > prev_low:
                if swing_lows[-1]['position'] > swing_highs[-1]['position']:
                    signals.append({
                        'type': 'CHoCH',
                        'direction': 'BULLISH',
                        'level': prev_high,
                        'description': 'تغییر کاراکتر بازار به صعودی - Higher Highs و Higher Lows',
                        'strength': 'VERY_STRONG'
                    })
        
        return signals
    
    def detect_fvg(self) -> List[Dict]:
        fvg_list = []
        min_gap = self.settings['fvg_min_gap']
        
        for i in range(2, len(self.df)):
            candle1 = self.df.iloc[i-2]
            candle2 = self.df.iloc[i-1]
            candle3 = self.df.iloc[i]
            
            if candle1['high'] < candle3['low']:
                gap_size = candle3['low'] - candle1['high']
                if gap_size / candle2['close'] > min_gap:
                    fvg_list.append({
                        'type': 'BULLISH_FVG',
                        'top': candle3['low'],
                        'bottom': candle1['high'],
                        'gap_size': gap_size,
                        'index': self.df.index[i-1],
                        'filled': self._check_fvg_filled(candle1['high'], candle3['low'], i, 'bullish'),
                        'description': f'FVG صعودی - Gap: {gap_size:.5f}'
                    })
            
            if candle1['low'] > candle3['high']:
                gap_size = candle1['low'] - candle3['high']
                if gap_size / candle2['close'] > min_gap:
                    fvg_list.append({
                        'type': 'BEARISH_FVG',
                        'top': candle1['low'],
                        'bottom': candle3['high'],
                        'gap_size': gap_size,
                        'index': self.df.index[i-1],
                        'filled': self._check_fvg_filled(candle3['high'], candle1['low'], i, 'bearish'),
                        'description': f'FVG نزولی - Gap: {gap_size:.5f}'
                    })
        
        unfilled = [f for f in fvg_list if not f['filled']]
        return unfilled[-10:] if len(unfilled) > 10 else unfilled
    
    def _check_fvg_filled(self, bottom: float, top: float, start_idx: int, fvg_type: str) -> bool:
        for i in range(start_idx, len(self.df)):
            candle = self.df.iloc[i]
            if fvg_type == 'bullish':
                if candle['low'] <= bottom:
                    return True
            else:
                if candle['high'] >= top:
                    return True
        return False
    
    def detect_order_blocks(self) -> List[Dict]:
        order_blocks = []
        lookback = self.settings['order_block_lookback']
        
        for i in range(lookback, len(self.df) - 1):
            current = self.df.iloc[i]
            next_candle = self.df.iloc[i + 1]
            
            current_body = abs(current['close'] - current['open'])
            next_body = abs(next_candle['close'] - next_candle['open'])
            
            if current['close'] < current['open']:
                if next_candle['close'] > next_candle['open'] and next_body > current_body * 1.5:
                    if next_candle['close'] > current['high']:
                        order_blocks.append({
                            'type': 'BULLISH_OB',
                            'top': current['high'],
                            'bottom': current['low'],
                            'index': self.df.index[i],
                            'strength': self._calculate_ob_strength(i, 'bullish'),
                            'mitigated': self._check_ob_mitigated(current['low'], i, 'bullish'),
                            'description': 'Order Block صعودی - منطقه خرید موسسات'
                        })
            
            if current['close'] > current['open']:
                if next_candle['close'] < next_candle['open'] and next_body > current_body * 1.5:
                    if next_candle['close'] < current['low']:
                        order_blocks.append({
                            'type': 'BEARISH_OB',
                            'top': current['high'],
                            'bottom': current['low'],
                            'index': self.df.index[i],
                            'strength': self._calculate_ob_strength(i, 'bearish'),
                            'mitigated': self._check_ob_mitigated(current['high'], i, 'bearish'),
                            'description': 'Order Block نزولی - منطقه فروش موسسات'
                        })
        
        unmitigated = [ob for ob in order_blocks if not ob['mitigated']]
        return sorted(unmitigated, key=lambda x: x['strength'], reverse=True)[:5]
    
    def _calculate_ob_strength(self, idx: int, ob_type: str) -> int:
        strength = 1
        
        candle = self.df.iloc[idx]
        avg_volume = self.df['volume'].mean()
        if candle['volume'] > avg_volume * 1.5:
            strength += 2
        
        body = abs(candle['close'] - candle['open'])
        avg_body = abs(self.df['close'] - self.df['open']).mean()
        if body > avg_body:
            strength += 1
        
        return min(strength, 5)
    
    def _check_ob_mitigated(self, level: float, start_idx: int, ob_type: str) -> bool:
        for i in range(start_idx + 2, len(self.df)):
            candle = self.df.iloc[i]
            if ob_type == 'bullish' and candle['low'] < level:
                return True
            if ob_type == 'bearish' and candle['high'] > level:
                return True
        return False
    
    def identify_supply_demand_zones(self) -> dict:
        supply_zones = []
        demand_zones = []
        
        for i in range(10, len(self.df) - 5):
            window = self.df.iloc[i-5:i+5]
            current = self.df.iloc[i]
            
            if current['high'] == window['high'].max():
                next_candles = self.df.iloc[i+1:i+6]
                if len(next_candles) > 0:
                    drop = (current['high'] - next_candles['low'].min()) / current['high']
                    if drop > 0.005:
                        supply_zones.append({
                            'top': current['high'],
                            'bottom': current['low'],
                            'index': self.df.index[i],
                            'strength': min(int(drop * 1000), 5),
                            'tested': self._count_zone_tests(current['low'], current['high'], i)
                        })
            
            if current['low'] == window['low'].min():
                next_candles = self.df.iloc[i+1:i+6]
                if len(next_candles) > 0:
                    rise = (next_candles['high'].max() - current['low']) / current['low']
                    if rise > 0.005:
                        demand_zones.append({
                            'top': current['high'],
                            'bottom': current['low'],
                            'index': self.df.index[i],
                            'strength': min(int(rise * 1000), 5),
                            'tested': self._count_zone_tests(current['low'], current['high'], i)
                        })
        
        current_price = self.df['close'].iloc[-1]
        
        active_supply = [z for z in supply_zones if z['bottom'] > current_price and z['tested'] < 3]
        active_demand = [z for z in demand_zones if z['top'] < current_price and z['tested'] < 3]
        
        return {
            'supply_zones': sorted(active_supply, key=lambda x: x['bottom'])[:3],
            'demand_zones': sorted(active_demand, key=lambda x: x['top'], reverse=True)[:3],
            'nearest_supply': active_supply[0] if active_supply else None,
            'nearest_demand': active_demand[0] if active_demand else None
        }
    
    def _count_zone_tests(self, bottom: float, top: float, start_idx: int) -> int:
        tests = 0
        for i in range(start_idx + 1, len(self.df)):
            candle = self.df.iloc[i]
            if candle['low'] <= top and candle['high'] >= bottom:
                tests += 1
        return tests
    
    def calculate_premium_discount(self) -> dict:
        swing_high = self.df['high'].rolling(50).max().iloc[-1]
        swing_low = self.df['low'].rolling(50).min().iloc[-1]
        
        range_size = swing_high - swing_low
        equilibrium = swing_low + range_size * 0.5
        
        current_price = self.df['close'].iloc[-1]
        
        premium_top = swing_high
        premium_bottom = swing_low + range_size * 0.7
        discount_top = swing_low + range_size * 0.3
        discount_bottom = swing_low
        
        if current_price > premium_bottom:
            zone = 'PREMIUM'
            zone_description = 'قیمت در منطقه Premium - مناسب فروش'
            pct = ((current_price - equilibrium) / (swing_high - equilibrium)) * 100
        elif current_price < discount_top:
            zone = 'DISCOUNT'
            zone_description = 'قیمت در منطقه Discount - مناسب خرید'
            pct = ((equilibrium - current_price) / (equilibrium - swing_low)) * 100
        else:
            zone = 'EQUILIBRIUM'
            zone_description = 'قیمت در منطقه تعادل'
            pct = 0
        
        return {
            'swing_high': swing_high,
            'swing_low': swing_low,
            'equilibrium': equilibrium,
            'premium_zone': {'top': premium_top, 'bottom': premium_bottom},
            'discount_zone': {'top': discount_top, 'bottom': discount_bottom},
            'current_zone': zone,
            'zone_description': zone_description,
            'zone_percentage': pct,
            'current_price': current_price
        }
    
    def detect_liquidity_sweep(self) -> List[Dict]:
        sweeps = []
        pips_threshold = self.settings['liquidity_sweep_pips'] * 0.0001
        
        swing_points = self.identify_swing_points()
        
        for sh in swing_points['swing_highs'][-5:]:
            for i in range(sh['position'] + 1, len(self.df)):
                candle = self.df.iloc[i]
                if candle['high'] > sh['price'] and candle['close'] < sh['price']:
                    sweeps.append({
                        'type': 'LIQUIDITY_SWEEP_HIGH',
                        'level': sh['price'],
                        'sweep_high': candle['high'],
                        'index': self.df.index[i],
                        'description': f'جمع‌آوری نقدینگی بالای {sh["price"]:.5f} - سیگنال نزولی',
                        'signal': 'BEARISH'
                    })
                    break
        
        for sl in swing_points['swing_lows'][-5:]:
            for i in range(sl['position'] + 1, len(self.df)):
                candle = self.df.iloc[i]
                if candle['low'] < sl['price'] and candle['close'] > sl['price']:
                    sweeps.append({
                        'type': 'LIQUIDITY_SWEEP_LOW',
                        'level': sl['price'],
                        'sweep_low': candle['low'],
                        'index': self.df.index[i],
                        'description': f'جمع‌آوری نقدینگی زیر {sl["price"]:.5f} - سیگنال صعودی',
                        'signal': 'BULLISH'
                    })
                    break
        
        return sweeps[-5:]
    
    def analyze_market_structure(self, swing_points: dict, bos_choch: List[Dict]) -> dict:
        if not swing_points['swing_highs'] or not swing_points['swing_lows']:
            return {'trend': 'UNKNOWN', 'description': 'داده کافی نیست'}
        
        highs = [sh['price'] for sh in swing_points['swing_highs'][-4:]]
        lows = [sl['price'] for sl in swing_points['swing_lows'][-4:]]
        
        higher_highs = all(highs[i] > highs[i-1] for i in range(1, len(highs))) if len(highs) > 1 else False
        higher_lows = all(lows[i] > lows[i-1] for i in range(1, len(lows))) if len(lows) > 1 else False
        lower_highs = all(highs[i] < highs[i-1] for i in range(1, len(highs))) if len(highs) > 1 else False
        lower_lows = all(lows[i] < lows[i-1] for i in range(1, len(lows))) if len(lows) > 1 else False
        
        choch_signals = [s for s in bos_choch if s['type'] == 'CHoCH']
        bos_signals = [s for s in bos_choch if s['type'] == 'BOS']
        
        if higher_highs and higher_lows:
            trend = 'BULLISH'
            description = 'ساختار صعودی - Higher Highs و Higher Lows'
            strength = 'STRONG'
        elif lower_highs and lower_lows:
            trend = 'BEARISH'
            description = 'ساختار نزولی - Lower Highs و Lower Lows'
            strength = 'STRONG'
        elif higher_highs and not higher_lows:
            trend = 'WEAK_BULLISH'
            description = 'روند صعودی ضعیف - فقط Higher Highs'
            strength = 'WEAK'
        elif lower_lows and not lower_highs:
            trend = 'WEAK_BEARISH'
            description = 'روند نزولی ضعیف - فقط Lower Lows'
            strength = 'WEAK'
        else:
            trend = 'RANGING'
            description = 'بازار رنج - بدون روند مشخص'
            strength = 'NEUTRAL'
        
        if choch_signals:
            last_choch = choch_signals[-1]
            if last_choch['direction'] != trend.replace('WEAK_', ''):
                description += f" | هشدار CHoCH {last_choch['direction']}"
        
        return {
            'trend': trend,
            'description': description,
            'strength': strength,
            'higher_highs': higher_highs,
            'higher_lows': higher_lows,
            'lower_highs': lower_highs,
            'lower_lows': lower_lows,
            'recent_bos': len(bos_signals),
            'recent_choch': len(choch_signals)
        }

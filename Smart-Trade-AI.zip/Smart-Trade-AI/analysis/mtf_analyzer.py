
import pandas as pd
from typing import Dict, List, Optional
from data.data_fetcher import DataFetcher
from indicators.technical_indicators import TechnicalIndicators
from analysis.smc_analyzer import SMCAnalyzer
from analysis.pattern_analyzer import PatternAnalyzer

class MultiTimeframeAnalyzer:
    """تحلیلگر چند تایم‌فریمی برای یافتن بهترین نقطه ورود"""
    
    def __init__(self, symbol: str):
        self.symbol = symbol
        self.data_fetcher = DataFetcher()
        self.timeframes = ['4h', '1h', '15m', '5m']
        
    def analyze_mtf(self) -> Dict:
        """تحلیل کامل چند تایم‌فریمی"""
        
        # مرحله 1: تحلیل 4 ساعته - تعیین روند اصلی
        h4_analysis = self._analyze_timeframe('4h')
        if not h4_analysis['valid']:
            return {
                'valid': False,
                'reason': 'روند اصلی در 4 ساعته مشخص نیست'
            }
        
        main_trend = h4_analysis['trend']
        
        # مرحله 2: تحلیل 1 ساعته - تایید روند و یافتن نقاط کلیدی
        h1_analysis = self._analyze_timeframe('1h')
        if not h1_analysis['valid']:
            return {
                'valid': False,
                'reason': 'تایید در 1 ساعته انجام نشد'
            }
        
        # بررسی همراستایی روند
        if h1_analysis['trend'] != main_trend:
            return {
                'valid': False,
                'reason': f'روند 1 ساعته ({h1_analysis["trend"]}) با 4 ساعته ({main_trend}) مطابقت ندارد'
            }
        
        # مرحله 3: تحلیل 15 دقیقه - یافتن زون ورود
        m15_analysis = self._analyze_timeframe('15m')
        if not m15_analysis['valid']:
            return {
                'valid': False,
                'reason': 'زون ورود در 15 دقیقه پیدا نشد'
            }
        
        # بررسی setup در 15 دقیقه
        if not self._check_setup_alignment(m15_analysis, main_trend):
            return {
                'valid': False,
                'reason': 'Setup در 15 دقیقه آماده نیست'
            }
        
        # مرحله 4: تحلیل 5 دقیقه - پیدا کردن نقطه دقیق ورود
        m5_analysis = self._analyze_timeframe('5m')
        if not m5_analysis['valid']:
            return {
                'valid': False,
                'reason': 'نقطه دقیق ورود در 5 دقیقه یافت نشد'
            }
        
        # بررسی سیگنال نهایی
        final_signal = self._generate_final_signal(
            h4_analysis, h1_analysis, m15_analysis, m5_analysis, main_trend
        )
        
        if final_signal['confidence'] < 95:
            return {
                'valid': False,
                'reason': f'اطمینان کافی نیست ({final_signal["confidence"]:.1f}%)',
                'signal': final_signal
            }
        
        return {
            'valid': True,
            'signal': final_signal,
            'h4_analysis': h4_analysis,
            'h1_analysis': h1_analysis,
            'm15_analysis': m15_analysis,
            'm5_analysis': m5_analysis
        }
    
    def _analyze_timeframe(self, timeframe: str) -> Dict:
        """تحلیل یک تایم‌فریم"""
        
        df = self.data_fetcher.get_candles(self.symbol, timeframe, count=500)
        if df.empty:
            return {'valid': False}
        
        ti = TechnicalIndicators(df)
        indicators = ti.calculate_all()
        
        smc = SMCAnalyzer(df)
        smc_data = smc.analyze_all()
        
        pa = PatternAnalyzer(df)
        patterns = pa.analyze_all()
        
        # تعیین روند
        trend = self._determine_trend(indicators, smc_data)
        
        # محاسبه قدرت
        strength = self._calculate_strength(indicators, smc_data, patterns)
        
        # شناسایی نواحی کلیدی
        key_zones = self._identify_key_zones(smc_data, patterns, df)
        
        # بررسی سیگنال‌های ورود
        entry_signals = self._check_entry_signals(
            indicators, smc_data, patterns, df, timeframe
        )
        
        return {
            'valid': True,
            'timeframe': timeframe,
            'trend': trend,
            'strength': strength,
            'key_zones': key_zones,
            'entry_signals': entry_signals,
            'indicators': indicators,
            'smc': smc_data,
            'patterns': patterns,
            'current_price': df['close'].iloc[-1]
        }
    
    def _determine_trend(self, indicators: Dict, smc_data: Dict) -> str:
        """تعیین روند با دقت بالا"""
        
        scores = {'BULLISH': 0, 'BEARISH': 0}
        
        # EMA Alignment (وزن: 25)
        ema_trend = indicators.get('EMA', {}).get('trend', '')
        if 'STRONG_BULLISH' in ema_trend:
            scores['BULLISH'] += 25
        elif 'BULLISH' in ema_trend:
            scores['BULLISH'] += 15
        elif 'STRONG_BEARISH' in ema_trend:
            scores['BEARISH'] += 25
        elif 'BEARISH' in ema_trend:
            scores['BEARISH'] += 15
        
        # Market Structure (وزن: 30)
        ms = smc_data.get('market_structure', {})
        ms_trend = ms.get('trend', '')
        if 'BULLISH' in ms_trend:
            scores['BULLISH'] += 30
        elif 'BEARISH' in ms_trend:
            scores['BEARISH'] += 30
        
        # ADX > 25 (وزن: 20)
        adx = indicators.get('ADX', {})
        if adx.get('adx', 0) > 25:
            if adx.get('trend_direction') == 'BULLISH':
                scores['BULLISH'] += 20
            else:
                scores['BEARISH'] += 20
        
        # Supertrend (وزن: 15)
        st = indicators.get('SUPERTREND', {})
        if st.get('signal') == 'BULLISH':
            scores['BULLISH'] += 15
        elif st.get('signal') == 'BEARISH':
            scores['BEARISH'] += 15
        
        # MACD (وزن: 10)
        macd = indicators.get('MACD', {})
        if 'BULLISH' in macd.get('trend', ''):
            scores['BULLISH'] += 10
        elif 'BEARISH' in macd.get('trend', ''):
            scores['BEARISH'] += 10
        
        total = scores['BULLISH'] + scores['BEARISH']
        if total == 0:
            return 'NEUTRAL'
        
        confidence = max(scores['BULLISH'], scores['BEARISH']) / total * 100
        
        if confidence < 70:
            return 'NEUTRAL'
        
        return 'BULLISH' if scores['BULLISH'] > scores['BEARISH'] else 'BEARISH'
    
    def _calculate_strength(self, indicators: Dict, smc_data: Dict, patterns: Dict) -> int:
        """محاسبه قدرت روند (0-100)"""
        
        strength = 0
        
        # ADX
        adx = indicators.get('ADX', {}).get('adx', 0)
        if adx > 50:
            strength += 30
        elif adx > 35:
            strength += 20
        elif adx > 25:
            strength += 10
        
        # BOS/CHoCH
        bos_choch = smc_data.get('bos_choch', [])
        strength += min(len(bos_choch) * 5, 20)
        
        # Order Blocks
        obs = smc_data.get('order_blocks', [])
        strength += min(len(obs) * 3, 15)
        
        # Trend Summary
        ts = indicators.get('TREND_SUMMARY', {})
        bp = ts.get('bullish_percent', 50)
        if bp > 70 or bp < 30:
            strength += 20
        elif bp > 60 or bp < 40:
            strength += 10
        
        # Patterns
        patterns_list = patterns.get('candlestick_patterns', [])
        strong_patterns = [p for p in patterns_list if p.get('strength') in ['STRONG', 'VERY_STRONG']]
        strength += min(len(strong_patterns) * 5, 15)
        
        return min(strength, 100)
    
    def _identify_key_zones(self, smc_data: Dict, patterns: Dict, df: pd.DataFrame) -> Dict:
        """شناسایی نواحی کلیدی"""
        
        current_price = df['close'].iloc[-1]
        
        # Order Blocks
        obs = smc_data.get('order_blocks', [])
        bullish_obs = [ob for ob in obs if ob['type'] == 'BULLISH_OB']
        bearish_obs = [ob for ob in obs if ob['type'] == 'BEARISH_OB']
        
        # FVGs
        fvgs = smc_data.get('fvg', [])
        bullish_fvgs = [f for f in fvgs if f['type'] == 'BULLISH_FVG']
        bearish_fvgs = [f for f in fvgs if f['type'] == 'BEARISH_FVG']
        
        # Support/Resistance
        sr = patterns.get('support_resistance', {})
        
        # Premium/Discount
        pd = smc_data.get('premium_discount', {})
        
        return {
            'bullish_obs': bullish_obs[:3],
            'bearish_obs': bearish_obs[:3],
            'bullish_fvgs': bullish_fvgs[:3],
            'bearish_fvgs': bearish_fvgs[:3],
            'support_levels': sr.get('support_levels', [])[:3],
            'resistance_levels': sr.get('resistance_levels', [])[:3],
            'premium_discount': pd,
            'current_price': current_price
        }
    
    def _check_entry_signals(self, indicators: Dict, smc_data: Dict, 
                            patterns: Dict, df: pd.DataFrame, timeframe: str) -> List[Dict]:
        """بررسی سیگنال‌های ورود"""
        
        signals = []
        current_price = df['close'].iloc[-1]
        
        # 1. Price at Order Block
        obs = smc_data.get('order_blocks', [])
        for ob in obs:
            if ob['bottom'] <= current_price <= ob['top']:
                signals.append({
                    'type': 'ORDER_BLOCK',
                    'direction': 'LONG' if ob['type'] == 'BULLISH_OB' else 'SHORT',
                    'strength': ob.get('strength', 1) * 20,
                    'description': f"قیمت در {ob['type']}"
                })
        
        # 2. Price at FVG
        fvgs = smc_data.get('fvg', [])
        for fvg in fvgs:
            if fvg['bottom'] <= current_price <= fvg['top']:
                signals.append({
                    'type': 'FVG',
                    'direction': 'LONG' if fvg['type'] == 'BULLISH_FVG' else 'SHORT',
                    'strength': 15,
                    'description': f"قیمت در {fvg['type']}"
                })
        
        # 3. Premium/Discount Zone
        pd = smc_data.get('premium_discount', {})
        zone = pd.get('current_zone', '')
        if zone == 'DISCOUNT':
            signals.append({
                'type': 'PREMIUM_DISCOUNT',
                'direction': 'LONG',
                'strength': 20,
                'description': 'قیمت در Discount Zone'
            })
        elif zone == 'PREMIUM':
            signals.append({
                'type': 'PREMIUM_DISCOUNT',
                'direction': 'SHORT',
                'strength': 20,
                'description': 'قیمت در Premium Zone'
            })
        
        # 4. RSI Divergence
        rsi = indicators.get('RSI', {})
        if rsi.get('oversold'):
            signals.append({
                'type': 'RSI',
                'direction': 'LONG',
                'strength': 15,
                'description': 'RSI در اشباع فروش'
            })
        elif rsi.get('overbought'):
            signals.append({
                'type': 'RSI',
                'direction': 'SHORT',
                'strength': 15,
                'description': 'RSI در اشباع خرید'
            })
        
        # 5. Candlestick Patterns
        candlesticks = patterns.get('candlestick_patterns', [])
        for pattern in candlesticks[-3:]:
            if pattern.get('strength') in ['STRONG', 'VERY_STRONG']:
                signals.append({
                    'type': 'PATTERN',
                    'direction': 'LONG' if pattern['type'] == 'BULLISH' else 'SHORT',
                    'strength': 20 if pattern['strength'] == 'VERY_STRONG' else 15,
                    'description': f"الگوی {pattern['pattern']}"
                })
        
        # 6. Liquidity Sweep
        liquidity = smc_data.get('liquidity', [])
        if liquidity:
            last_sweep = liquidity[-1]
            signals.append({
                'type': 'LIQUIDITY_SWEEP',
                'direction': 'LONG' if last_sweep['signal'] == 'BULLISH' else 'SHORT',
                'strength': 25,
                'description': last_sweep['description']
            })
        
        return signals
    
    def _check_setup_alignment(self, analysis: Dict, main_trend: str) -> bool:
        """بررسی آماده بودن setup در تایم‌فریم میانی"""
        
        if analysis['trend'] != main_trend:
            return False
        
        if analysis['strength'] < 60:
            return False
        
        signals = analysis['entry_signals']
        trend_aligned_signals = [
            s for s in signals 
            if s['direction'] == ('LONG' if main_trend == 'BULLISH' else 'SHORT')
        ]
        
        return len(trend_aligned_signals) >= 2
    
    def _generate_final_signal(self, h4: Dict, h1: Dict, m15: Dict, 
                              m5: Dict, main_trend: str) -> Dict:
        """تولید سیگنال نهایی با اطمینان 100%"""
        
        direction = 'LONG' if main_trend == 'BULLISH' else 'SHORT'
        
        # محاسبه امتیاز کل
        total_score = 0
        max_score = 0
        reasons = []
        
        # 4H Trend (وزن: 30%)
        if h4['trend'] == main_trend:
            score = h4['strength'] * 0.3
            total_score += score
            reasons.append(f"✅ روند 4 ساعته {main_trend} (قدرت: {h4['strength']})")
        max_score += 30
        
        # 1H Trend (وزن: 25%)
        if h1['trend'] == main_trend:
            score = h1['strength'] * 0.25
            total_score += score
            reasons.append(f"✅ روند 1 ساعته {main_trend} (قدرت: {h1['strength']})")
        max_score += 25
        
        # 15M Setup (وزن: 25%)
        m15_signals = [s for s in m15['entry_signals'] if s['direction'] == direction]
        if m15_signals:
            score = min(sum(s['strength'] for s in m15_signals), 25)
            total_score += score
            for sig in m15_signals[:3]:
                reasons.append(f"✅ 15M: {sig['description']}")
        max_score += 25
        
        # 5M Entry (وزن: 20%)
        m5_signals = [s for s in m5['entry_signals'] if s['direction'] == direction]
        if m5_signals:
            score = min(sum(s['strength'] for s in m5_signals), 20)
            total_score += score
            for sig in m5_signals[:3]:
                reasons.append(f"✅ 5M: {sig['description']}")
        max_score += 20
        
        confidence = (total_score / max_score * 100) if max_score > 0 else 0
        
        # محاسبه Entry, SL, TP
        entry_data = self._calculate_precise_entry(m5, m15, direction)
        
        return {
            'direction': direction,
            'confidence': round(confidence, 1),
            'entry': entry_data['entry'],
            'stop_loss': entry_data['sl'],
            'take_profit_1': entry_data['tp1'],
            'take_profit_2': entry_data['tp2'],
            'take_profit_3': entry_data['tp3'],
            'risk_reward': entry_data['rr'],
            'reasons': reasons,
            'timeframe_alignment': {
                '4h': h4['trend'],
                '1h': h1['trend'],
                '15m': m15['trend'],
                '5m': m5['trend']
            },
            'strength_scores': {
                '4h': h4['strength'],
                '1h': h1['strength'],
                '15m': m15['strength'],
                '5m': m5['strength']
            }
        }
    
    def _calculate_precise_entry(self, m5: Dict, m15: Dict, direction: str) -> Dict:
        """محاسبه دقیق نقاط ورود و خروج"""
        
        current_price = m5['current_price']
        atr_5m = m5['indicators'].get('ATR', {}).get('value', current_price * 0.001)
        
        if direction == 'LONG':
            # Entry: بهترین Order Block یا FVG در 5M
            entry_candidates = []
            
            for ob in m5['key_zones']['bullish_obs']:
                if ob['bottom'] <= current_price <= ob['top']:
                    entry_candidates.append(ob['bottom'])
            
            for fvg in m5['key_zones']['bullish_fvgs']:
                if fvg['bottom'] <= current_price <= fvg['top']:
                    entry_candidates.append(fvg['bottom'])
            
            entry = min(entry_candidates) if entry_candidates else current_price
            
            # SL: زیر نزدیک‌ترین Swing Low
            sl_candidates = [entry - atr_5m * 1.5]
            
            for ob in m5['key_zones']['bullish_obs']:
                sl_candidates.append(ob['bottom'] - atr_5m * 0.2)
            
            sl = max(sl_candidates)
            
            # TP: بر اساس نواحی مقاومت در 15M
            risk = entry - sl
            
            resistance_levels = m15['key_zones']['resistance_levels']
            if resistance_levels:
                tp1 = resistance_levels[0]['price']
                tp2 = resistance_levels[1]['price'] if len(resistance_levels) > 1 else entry + risk * 3
                tp3 = resistance_levels[2]['price'] if len(resistance_levels) > 2 else entry + risk * 5
            else:
                tp1 = entry + risk * 2
                tp2 = entry + risk * 3
                tp3 = entry + risk * 5
            
        else:  # SHORT
            entry_candidates = []
            
            for ob in m5['key_zones']['bearish_obs']:
                if ob['bottom'] <= current_price <= ob['top']:
                    entry_candidates.append(ob['top'])
            
            for fvg in m5['key_zones']['bearish_fvgs']:
                if fvg['bottom'] <= current_price <= fvg['top']:
                    entry_candidates.append(fvg['top'])
            
            entry = max(entry_candidates) if entry_candidates else current_price
            
            sl_candidates = [entry + atr_5m * 1.5]
            
            for ob in m5['key_zones']['bearish_obs']:
                sl_candidates.append(ob['top'] + atr_5m * 0.2)
            
            sl = min(sl_candidates)
            
            risk = sl - entry
            
            support_levels = m15['key_zones']['support_levels']
            if support_levels:
                tp1 = support_levels[0]['price']
                tp2 = support_levels[1]['price'] if len(support_levels) > 1 else entry - risk * 3
                tp3 = support_levels[2]['price'] if len(support_levels) > 2 else entry - risk * 5
            else:
                tp1 = entry - risk * 2
                tp2 = entry - risk * 3
                tp3 = entry - risk * 5
        
        rr = abs((tp1 - entry) / (entry - sl)) if sl != entry else 0
        
        return {
            'entry': float(entry),
            'sl': float(sl),
            'tp1': float(tp1),
            'tp2': float(tp2),
            'tp3': float(tp3),
            'rr': round(rr, 2)
        }

# سیستم تحلیل و معاملات هوشمند

## نمای کلی
سیستم کامل تحلیل و معاملات با هوش مصنوعی برای بازارهای مالی (فارکس و کریپتو) با ربات تلگرام تعاملی.

## ساختار پروژه
```
├── config/
│   └── settings.py           # تنظیمات اصلی و API keys
├── data/
│   └── data_fetcher.py       # دریافت داده از OANDA و Bitstamp
├── indicators/
│   └── technical_indicators.py  # 20+ اندیکاتور تکنیکال
├── analysis/
│   ├── pattern_analyzer.py   # الگوهای کندلی و سطوح قیمتی
│   ├── smc_analyzer.py       # تحلیل Smart Money Concepts
│   ├── entry_signal.py       # سیگنال ورود سوباراشی و اسنایپری
│   └── fundamental_analyzer.py  # تحلیل فاندامنتال و اخبار
├── ai_engine/
│   └── ai_models.py          # هوش مصنوعی با Groq API رایگان
├── telegram/
│   └── bot_handler.py        # ربات تلگرام با منوی کامل
└── main.py                   # فایل اصلی اجرا
```

## امکانات

### تحلیل تکنیکال
- 20+ اندیکاتور: RSI, MACD, EMA, SMA, Bollinger Bands, Stochastic, CCI, Williams %R, ROC, ADX, Ichimoku, PSAR, Supertrend, ATR, Keltner, Donchian, VWAP, OBV, MFI
- الگوهای کندلی: Pin Bar, Engulfing, Doji, Hammer, Shooting Star
- سطوح حمایت و مقاومت
- سطوح فیبوناچی
- نقاط Pivot

### Smart Money Concepts (SMC)
- BOS (Break of Structure)
- CHoCH (Change of Character)
- FVG (Fair Value Gap)
- Order Blocks
- Supply/Demand Zones
- Premium/Discount Zones
- Liquidity Sweep

### هوش مصنوعی
- پیش‌بینی جهت حرکت با ML
- تشخیص رژیم بازار
- جریان پول هوشمند
- شناسایی فعالیت نهنگ‌ها
- Groq API (رایگان با Llama-3)

### نمادها
- فارکس: XAUUSD, USDJPY, GBPUSD, EURUSD
- کریپتو: BTCUSD, XRPUSD

### تایم فریم‌ها
5m | 15m | 30m | 1h | 4h | Daily

## اجرا
```bash
python main.py bot     # اجرای ربات تلگرام
python main.py test    # تست سیستم
python main.py prices  # قیمت‌های فعلی
python main.py analyze XAUUSD 1h  # تحلیل سریع
```

## API Keys
- OANDA: حساب دمو برای فارکس
- Bitstamp: API رایگان برای کریپتو
- Groq: مدل AI رایگان (اختیاری)
- Telegram: توکن ربات

## تاریخچه تغییرات
- 2025-12-08: ایجاد اولیه سیستم با تمام قابلیت‌ها

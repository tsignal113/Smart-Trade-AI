---
name: Subarashi Signal System
description: Architecture of the 5-phase subarashi entry signal generator
---

## Core architecture

`EntrySignalGenerator.generate_subarashi_signal()` runs 5 phases:

| Phase | Items | Max pts |
|-------|-------|---------|
| 1 – Trend | EMA (15) + Supertrend (10) + ADX (5) | 30 |
| 2 – SMC | Market Structure (12) + PD Zone (8) + Liquidity (5) | 25 |
| 3 – Momentum | RSI (10) + MACD (8) + Stochastic (7) | 25 |
| 4 – Entry Zone | Order Block (10) + FVG (6) + Supply/Demand (4) | 20 |
| 5 – Confirmation | Bollinger (6) + Candles (8) + Volume/MFI (6) | 20 |

- Signal fires (LONG/SHORT) when confidence ≥ 62% and one direction leads.
- Returns `detail` dict with keys: `ema supertrend adx ms pd liq rsi macd stoch ob fvg sd bb candle vol` — each has `{'dir', 'pts', 'text'}`.
- Returns `active_ob` and `active_fvg` dicts (or None) for level calculation.
- `_calc_subarashi_levels()` uses active_ob/fvg + swing high/low + PSAR + ATR buffers.
- SL capped at 3.5×ATR from entry; minimum risk = 0.4×ATR.
- TP ratios: 1.5×R, 2.5×R, 4.0×R.

## Helpers
- `_safe_float(val, default=0.0)` — safe float conversion
- `_fp(price)` — dynamic decimal formatting (≥1000→2dp, ≥100→3dp, ≥10→4dp, else→5dp)
- `_get_safe(d, *keys)` — safe nested dict access

**Why:** Previous version had unguarded dict access causing crashes; fixed with isinstance checks throughout.

import sys
import logging
from datetime import datetime

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

def print_banner():
    banner = """
╔══════════════════════════════════════════════════════════════════╗
║                                                                  ║
║     🤖 سیستم تحلیل و معاملات هوشمند                             ║
║     Smart Trading Analysis System                                ║
║                                                                  ║
║     📊 20+ اندیکاتور تکنیکال                                    ║
║     💎 تحلیل Smart Money Concepts                                ║
║     🧠 هوش مصنوعی پیشرفته                                       ║
║     📰 تحلیل فاندامنتال و اخبار                                 ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝
    """
    print(banner)

def test_data_fetcher():
    print("\n📊 تست دریافت داده‌ها...")
    from data.data_fetcher import DataFetcher
    
    fetcher = DataFetcher()
    
    print("  • دریافت قیمت XAUUSD...")
    price = fetcher.get_current_price("XAUUSD")
    if price:
        print(f"    ✅ قیمت: {price.get('mid', 'N/A')}")
    else:
        print("    ❌ خطا در دریافت قیمت")
    
    print("  • دریافت کندل‌های XAUUSD (1h)...")
    df = fetcher.get_candles("XAUUSD", "1h", count=100)
    if not df.empty:
        print(f"    ✅ تعداد کندل: {len(df)}")
    else:
        print("    ⚠️ داده‌ای دریافت نشد")
    
    print("  • دریافت قیمت BTCUSD...")
    price = fetcher.get_current_price("BTCUSD")
    if price:
        print(f"    ✅ قیمت: ${price.get('mid', 'N/A'):,.2f}")
    else:
        print("    ❌ خطا در دریافت قیمت")
    
    return df

def test_indicators(df):
    print("\n📈 تست اندیکاتورها...")
    from indicators.technical_indicators import TechnicalIndicators
    
    if df.empty:
        print("  ⚠️ داده‌ای برای تحلیل وجود ندارد")
        return None
    
    ti = TechnicalIndicators(df)
    indicators = ti.calculate_all()
    
    print(f"  • RSI: {indicators.get('RSI', {}).get('value', 'N/A'):.2f}")
    print(f"  • MACD: {indicators.get('MACD', {}).get('trend', 'N/A')}")
    print(f"  • EMA Trend: {indicators.get('EMA', {}).get('trend', 'N/A')}")
    print(f"  • ADX: {indicators.get('ADX', {}).get('adx', 'N/A'):.2f}")
    print(f"  • Overall: {indicators.get('TREND_SUMMARY', {}).get('overall', 'N/A')}")
    
    return indicators

def test_smc(df):
    print("\n💎 تست SMC...")
    from analysis.smc_analyzer import SMCAnalyzer
    
    if df.empty:
        print("  ⚠️ داده‌ای برای تحلیل وجود ندارد")
        return None
    
    smc = SMCAnalyzer(df)
    analysis = smc.analyze_all()
    
    ms = analysis.get('market_structure', {})
    print(f"  • Market Structure: {ms.get('trend', 'N/A')}")
    print(f"  • Premium/Discount: {analysis.get('premium_discount', {}).get('current_zone', 'N/A')}")
    print(f"  • FVG Count: {len(analysis.get('fvg', []))}")
    print(f"  • Order Blocks: {len(analysis.get('order_blocks', []))}")
    
    return analysis

def test_entry_signal(df):
    print("\n🎯 تست سیگنال ورود...")
    from analysis.entry_signal import EntrySignalGenerator
    
    if df.empty:
        print("  ⚠️ داده‌ای برای تحلیل وجود ندارد")
        return None
    
    signal_gen = EntrySignalGenerator(df, "XAUUSD", "1h")
    signal = signal_gen.generate_sniper_entry()
    
    print(f"  • Signal Type: {signal.get('signal_type', 'N/A')}")
    print(f"  • Confidence: {signal.get('confidence', 0):.1f}%")
    print(f"  • Sniper Entry: {'✅' if signal.get('is_sniper_entry') else '❌'}")
    print(f"  • Sniper Quality: {signal.get('sniper_quality', 'N/A')}")
    
    if signal.get('entry'):
        print(f"  • Entry: {signal['entry']:.5f}")
        print(f"  • SL: {signal.get('stop_loss', 0):.5f}")
        print(f"  • TP1: {signal.get('take_profit_1', 0):.5f}")
    
    return signal

def run_tests():
    print("\n" + "="*60)
    print("🧪 اجرای تست‌های سیستم")
    print("="*60)
    
    df = test_data_fetcher()
    test_indicators(df)
    test_smc(df)
    test_entry_signal(df)
    
    print("\n" + "="*60)
    print("✅ تست‌ها با موفقیت انجام شد")
    print("="*60)

def quick_analysis(symbol: str = "XAUUSD", timeframe: str = "1h"):
    print(f"\n🔍 تحلیل سریع {symbol} در تایم فریم {timeframe}...")
    
    from data.data_fetcher import DataFetcher
    from analysis.entry_signal import EntrySignalGenerator
    
    fetcher = DataFetcher()
    df = fetcher.get_candles(symbol, timeframe, count=500)
    
    if df.empty:
        print("❌ خطا در دریافت داده‌ها")
        return
    
    signal_gen = EntrySignalGenerator(df, symbol, timeframe)
    signal = signal_gen.generate_sniper_entry()
    
    print(f"""
{'='*60}
🎯 سیگنال ورود {symbol} ({timeframe})
{'='*60}

📊 نوع پوزیشن: {signal['signal_type']}
📈 اعتماد: {signal['confidence']:.1f}%
🎪 ورود اسنایپری: {'✅ تایید' if signal['is_sniper_entry'] else '❌ تایید نشد'}
⭐ کیفیت: {signal['sniper_quality']}

💰 نقاط ورود و خروج:
• Entry: {signal['entry']:.5f}
• SL: {signal['stop_loss']:.5f if signal['stop_loss'] else 'N/A'}
• TP1: {signal['take_profit_1']:.5f if signal['take_profit_1'] else 'N/A'}
• TP2: {signal['take_profit_2']:.5f if signal['take_profit_2'] else 'N/A'}
• TP3: {signal['take_profit_3']:.5f if signal['take_profit_3'] else 'N/A'}

⚠️ ریسک: {signal['risk_percent']:.2f}%

🔍 دلایل ورود:
""")
    for reason in signal['reasons'][:8]:
        print(f"  ✓ {reason}")
    
    print(f"\n{'='*60}")

def show_prices():
    print("\n💰 قیمت‌های فعلی...")
    
    from data.data_fetcher import DataFetcher
    from config.settings import SYMBOLS
    
    fetcher = DataFetcher()
    prices = fetcher.get_all_prices()
    
    print("\n📊 فارکس:")
    for symbol in SYMBOLS["forex"].keys():
        if symbol in prices:
            p = prices[symbol]
            print(f"  • {symbol}: {p.get('mid', 0):.5f}")
    
    print("\n₿ کریپتو:")
    for symbol in SYMBOLS["crypto"].keys():
        if symbol in prices:
            p = prices[symbol]
            print(f"  • {symbol}: ${p.get('mid', 0):,.2f}")

def run_telegram_bot():
    print("\n🤖 راه‌اندازی ربات تلگرام...")
    from tg_bot.bot_handler import run_bot
    run_bot()

def main():
    print_banner()
    
    if len(sys.argv) > 1:
        if sys.argv[1] == "bot":
            run_telegram_bot()
        elif sys.argv[1] == "test":
            run_tests()
        elif sys.argv[1] == "prices":
            show_prices()
        elif sys.argv[1] == "analyze":
            symbol = sys.argv[2] if len(sys.argv) > 2 else "XAUUSD"
            tf = sys.argv[3] if len(sys.argv) > 3 else "1h"
            quick_analysis(symbol, tf)
        return
    
    run_telegram_bot()

if __name__ == "__main__":
    main()

import requests
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import time
from config.settings import (
    OANDA_API_KEY, OANDA_ACCOUNT_ID, OANDA_BASE_URL,
    BITSTAMP_BASE_URL, SYMBOLS, TIMEFRAMES
)

class DataFetcher:
    def __init__(self):
        self.oanda_headers = {
            "Authorization": f"Bearer {OANDA_API_KEY}",
            "Content-Type": "application/json"
        }
    
    def get_oanda_candles(self, symbol: str, timeframe: str, count: int = 500) -> pd.DataFrame:
        oanda_symbol = SYMBOLS["forex"].get(symbol, symbol)
        granularity = TIMEFRAMES[timeframe]["oanda"]
        
        url = f"{OANDA_BASE_URL}/instruments/{oanda_symbol}/candles"
        params = {
            "granularity": granularity,
            "count": count,
            "price": "MAB"
        }
        
        try:
            response = requests.get(url, headers=self.oanda_headers, params=params, timeout=30)
            response.raise_for_status()
            data = response.json()
            
            candles = []
            for candle in data.get("candles", []):
                if candle.get("complete", True):
                    mid = candle.get("mid", {})
                    candles.append({
                        "time": pd.to_datetime(candle["time"]),
                        "open": float(mid.get("o", 0)),
                        "high": float(mid.get("h", 0)),
                        "low": float(mid.get("l", 0)),
                        "close": float(mid.get("c", 0)),
                        "volume": int(candle.get("volume", 0))
                    })
            
            df = pd.DataFrame(candles)
            if not df.empty:
                df.set_index("time", inplace=True)
            return df
            
        except Exception as e:
            print(f"Error fetching OANDA data for {symbol}: {e}")
            return pd.DataFrame()
    
    def get_bitstamp_candles(self, symbol: str, timeframe: str, count: int = 500) -> pd.DataFrame:
        bitstamp_symbol = SYMBOLS["crypto"].get(symbol, symbol.lower())
        step = TIMEFRAMES[timeframe]["bitstamp"]
        
        url = f"{BITSTAMP_BASE_URL}/ohlc/{bitstamp_symbol}/"
        params = {
            "step": step,
            "limit": count
        }
        
        try:
            response = requests.get(url, params=params, timeout=30)
            response.raise_for_status()
            data = response.json()
            
            ohlc_data = data.get("data", {}).get("ohlc", [])
            candles = []
            for candle in ohlc_data:
                candles.append({
                    "time": pd.to_datetime(int(candle["timestamp"]), unit="s"),
                    "open": float(candle["open"]),
                    "high": float(candle["high"]),
                    "low": float(candle["low"]),
                    "close": float(candle["close"]),
                    "volume": float(candle["volume"])
                })
            
            df = pd.DataFrame(candles)
            if not df.empty:
                df.set_index("time", inplace=True)
                df.sort_index(inplace=True)
            return df
            
        except Exception as e:
            print(f"Error fetching Bitstamp data for {symbol}: {e}")
            return pd.DataFrame()
    
    def get_candles(self, symbol: str, timeframe: str, count: int = 500) -> pd.DataFrame:
        if symbol in SYMBOLS["forex"]:
            return self.get_oanda_candles(symbol, timeframe, count)
        elif symbol in SYMBOLS["crypto"]:
            return self.get_bitstamp_candles(symbol, timeframe, count)
        else:
            print(f"Unknown symbol: {symbol}")
            return pd.DataFrame()
    
    def get_current_price(self, symbol: str) -> dict:
        if symbol in SYMBOLS["forex"]:
            return self._get_oanda_price(symbol)
        elif symbol in SYMBOLS["crypto"]:
            return self._get_bitstamp_price(symbol)
        return {}
    
    def _get_oanda_price(self, symbol: str) -> dict:
        oanda_symbol = SYMBOLS["forex"].get(symbol, symbol)
        url = f"{OANDA_BASE_URL}/accounts/{OANDA_ACCOUNT_ID}/pricing"
        params = {"instruments": oanda_symbol}
        
        try:
            response = requests.get(url, headers=self.oanda_headers, params=params, timeout=30)
            response.raise_for_status()
            data = response.json()
            
            prices = data.get("prices", [])
            if prices:
                price = prices[0]
                bid = float(price.get("bids", [{}])[0].get("price", 0))
                ask = float(price.get("asks", [{}])[0].get("price", 0))
                return {
                    "symbol": symbol,
                    "bid": bid,
                    "ask": ask,
                    "mid": (bid + ask) / 2,
                    "spread": ask - bid,
                    "time": datetime.now().isoformat()
                }
        except Exception as e:
            print(f"Error getting price for {symbol}: {e}")
        return {}
    
    def _get_bitstamp_price(self, symbol: str) -> dict:
        bitstamp_symbol = SYMBOLS["crypto"].get(symbol, symbol.lower())
        url = f"{BITSTAMP_BASE_URL}/ticker/{bitstamp_symbol}/"
        
        try:
            response = requests.get(url, timeout=30)
            response.raise_for_status()
            data = response.json()
            
            return {
                "symbol": symbol,
                "bid": float(data.get("bid", 0)),
                "ask": float(data.get("ask", 0)),
                "mid": float(data.get("last", 0)),
                "high": float(data.get("high", 0)),
                "low": float(data.get("low", 0)),
                "volume": float(data.get("volume", 0)),
                "time": datetime.now().isoformat()
            }
        except Exception as e:
            print(f"Error getting price for {symbol}: {e}")
        return {}
    
    def get_all_prices(self) -> dict:
        prices = {}
        all_symbols = list(SYMBOLS["forex"].keys()) + list(SYMBOLS["crypto"].keys())
        for symbol in all_symbols:
            price = self.get_current_price(symbol)
            if price:
                prices[symbol] = price
        return prices

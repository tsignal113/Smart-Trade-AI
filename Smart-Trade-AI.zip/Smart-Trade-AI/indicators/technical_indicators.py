import pandas as pd
import numpy as np
import ta
from ta.trend import MACD, EMAIndicator, SMAIndicator, ADXIndicator, IchimokuIndicator, PSARIndicator
from ta.momentum import RSIIndicator, StochRSIIndicator, StochasticOscillator, WilliamsRIndicator, ROCIndicator
from ta.volatility import BollingerBands, AverageTrueRange, KeltnerChannel, DonchianChannel
from ta.volume import OnBalanceVolumeIndicator, MFIIndicator, VolumeWeightedAveragePrice
from config.settings import INDICATOR_SETTINGS

class TechnicalIndicators:
    def __init__(self, df: pd.DataFrame):
        self.df = df.copy()
        self.indicators = {}
    
    def calculate_all(self) -> dict:
        self.calculate_momentum_indicators()
        self.calculate_trend_indicators()
        self.calculate_volatility_indicators()
        self.calculate_volume_indicators()
        self.calculate_custom_indicators()
        return self.indicators
    
    def calculate_momentum_indicators(self):
        settings = INDICATOR_SETTINGS
        
        rsi = RSIIndicator(self.df['close'], window=settings["RSI"]["period"])
        self.df['RSI'] = rsi.rsi()
        self.indicators['RSI'] = {
            'value': self.df['RSI'].iloc[-1],
            'signal': self._get_rsi_signal(),
            'overbought': self.df['RSI'].iloc[-1] > settings["RSI"]["overbought"],
            'oversold': self.df['RSI'].iloc[-1] < settings["RSI"]["oversold"]
        }
        
        stoch = StochasticOscillator(
            self.df['high'], self.df['low'], self.df['close'],
            window=settings["STOCHASTIC"]["k_period"],
            smooth_window=settings["STOCHASTIC"]["d_period"]
        )
        self.df['STOCH_K'] = stoch.stoch()
        self.df['STOCH_D'] = stoch.stoch_signal()
        self.indicators['STOCHASTIC'] = {
            'k': self.df['STOCH_K'].iloc[-1],
            'd': self.df['STOCH_D'].iloc[-1],
            'signal': self._get_stochastic_signal(),
            'overbought': self.df['STOCH_K'].iloc[-1] > settings["STOCHASTIC"]["overbought"],
            'oversold': self.df['STOCH_K'].iloc[-1] < settings["STOCHASTIC"]["oversold"]
        }
        
        self.df['CCI'] = ta.trend.cci(
            self.df['high'], self.df['low'], self.df['close'],
            window=settings["CCI"]["period"]
        )
        self.indicators['CCI'] = {
            'value': self.df['CCI'].iloc[-1],
            'signal': self._get_cci_signal(),
            'overbought': self.df['CCI'].iloc[-1] > settings["CCI"]["overbought"],
            'oversold': self.df['CCI'].iloc[-1] < settings["CCI"]["oversold"]
        }
        
        williams = WilliamsRIndicator(
            self.df['high'], self.df['low'], self.df['close'],
            lbp=settings["WILLIAMS_R"]["period"]
        )
        self.df['WILLIAMS_R'] = williams.williams_r()
        self.indicators['WILLIAMS_R'] = {
            'value': self.df['WILLIAMS_R'].iloc[-1],
            'signal': self._get_williams_signal(),
            'overbought': self.df['WILLIAMS_R'].iloc[-1] > settings["WILLIAMS_R"]["overbought"],
            'oversold': self.df['WILLIAMS_R'].iloc[-1] < settings["WILLIAMS_R"]["oversold"]
        }
        
        roc = ROCIndicator(self.df['close'], window=settings["ROC"]["period"])
        self.df['ROC'] = roc.roc()
        self.indicators['ROC'] = {
            'value': self.df['ROC'].iloc[-1],
            'signal': 'BULLISH' if self.df['ROC'].iloc[-1] > 0 else 'BEARISH'
        }
    
    def calculate_trend_indicators(self):
        settings = INDICATOR_SETTINGS
        
        macd = MACD(
            self.df['close'],
            window_fast=settings["MACD"]["fast"],
            window_slow=settings["MACD"]["slow"],
            window_sign=settings["MACD"]["signal"]
        )
        self.df['MACD'] = macd.macd()
        self.df['MACD_SIGNAL'] = macd.macd_signal()
        self.df['MACD_HIST'] = macd.macd_diff()
        self.indicators['MACD'] = {
            'macd': self.df['MACD'].iloc[-1],
            'signal': self.df['MACD_SIGNAL'].iloc[-1],
            'histogram': self.df['MACD_HIST'].iloc[-1],
            'trend': self._get_macd_signal()
        }
        
        for period in settings["EMA"]["periods"]:
            ema = EMAIndicator(self.df['close'], window=period)
            self.df[f'EMA_{period}'] = ema.ema_indicator()
        
        current_price = self.df['close'].iloc[-1]
        self.indicators['EMA'] = {
            'EMA_9': self.df['EMA_9'].iloc[-1],
            'EMA_21': self.df['EMA_21'].iloc[-1],
            'EMA_50': self.df['EMA_50'].iloc[-1],
            'EMA_200': self.df['EMA_200'].iloc[-1],
            'trend': self._get_ema_trend()
        }
        
        for period in settings["SMA"]["periods"]:
            sma = SMAIndicator(self.df['close'], window=period)
            self.df[f'SMA_{period}'] = sma.sma_indicator()
        
        self.indicators['SMA'] = {
            'SMA_20': self.df['SMA_20'].iloc[-1],
            'SMA_50': self.df['SMA_50'].iloc[-1],
            'SMA_100': self.df['SMA_100'].iloc[-1],
            'SMA_200': self.df['SMA_200'].iloc[-1],
            'trend': self._get_sma_trend()
        }
        
        adx = ADXIndicator(
            self.df['high'], self.df['low'], self.df['close'],
            window=settings["ADX"]["period"]
        )
        self.df['ADX'] = adx.adx()
        self.df['ADX_POS'] = adx.adx_pos()
        self.df['ADX_NEG'] = adx.adx_neg()
        self.indicators['ADX'] = {
            'adx': self.df['ADX'].iloc[-1],
            'plus_di': self.df['ADX_POS'].iloc[-1],
            'minus_di': self.df['ADX_NEG'].iloc[-1],
            'trend_strength': self._get_adx_strength(),
            'trend_direction': 'BULLISH' if self.df['ADX_POS'].iloc[-1] > self.df['ADX_NEG'].iloc[-1] else 'BEARISH'
        }
        
        try:
            ichimoku = IchimokuIndicator(
                self.df['high'], self.df['low'],
                window1=settings["ICHIMOKU"]["tenkan"],
                window2=settings["ICHIMOKU"]["kijun"],
                window3=settings["ICHIMOKU"]["senkou_b"]
            )
            self.df['ICHIMOKU_TENKAN'] = ichimoku.ichimoku_conversion_line()
            self.df['ICHIMOKU_KIJUN'] = ichimoku.ichimoku_base_line()
            self.df['ICHIMOKU_A'] = ichimoku.ichimoku_a()
            self.df['ICHIMOKU_B'] = ichimoku.ichimoku_b()
            self.indicators['ICHIMOKU'] = {
                'tenkan': self.df['ICHIMOKU_TENKAN'].iloc[-1],
                'kijun': self.df['ICHIMOKU_KIJUN'].iloc[-1],
                'senkou_a': self.df['ICHIMOKU_A'].iloc[-1],
                'senkou_b': self.df['ICHIMOKU_B'].iloc[-1],
                'signal': self._get_ichimoku_signal()
            }
        except:
            self.indicators['ICHIMOKU'] = {'signal': 'N/A'}
        
        psar = PSARIndicator(self.df['high'], self.df['low'], self.df['close'])
        self.df['PSAR'] = psar.psar()
        self.indicators['PSAR'] = {
            'value': self.df['PSAR'].iloc[-1],
            'signal': 'BULLISH' if self.df['close'].iloc[-1] > self.df['PSAR'].iloc[-1] else 'BEARISH'
        }
        
        self._calculate_supertrend()
    
    def _calculate_supertrend(self):
        settings = INDICATOR_SETTINGS["SUPERTREND"]
        period = settings["period"]
        multiplier = settings["multiplier"]
        
        atr = AverageTrueRange(self.df['high'], self.df['low'], self.df['close'], window=period)
        self.df['ATR_ST'] = atr.average_true_range()
        
        hl2 = (self.df['high'] + self.df['low']) / 2
        self.df['upper_band'] = hl2 + (multiplier * self.df['ATR_ST'])
        self.df['lower_band'] = hl2 - (multiplier * self.df['ATR_ST'])
        
        self.df['supertrend'] = 0.0
        self.df['st_direction'] = 1
        
        for i in range(1, len(self.df)):
            if self.df['close'].iloc[i] > self.df['upper_band'].iloc[i-1]:
                self.df.loc[self.df.index[i], 'st_direction'] = 1
            elif self.df['close'].iloc[i] < self.df['lower_band'].iloc[i-1]:
                self.df.loc[self.df.index[i], 'st_direction'] = -1
            else:
                self.df.loc[self.df.index[i], 'st_direction'] = self.df['st_direction'].iloc[i-1]
            
            if self.df['st_direction'].iloc[i] == 1:
                self.df.loc[self.df.index[i], 'supertrend'] = self.df['lower_band'].iloc[i]
            else:
                self.df.loc[self.df.index[i], 'supertrend'] = self.df['upper_band'].iloc[i]
        
        self.indicators['SUPERTREND'] = {
            'value': self.df['supertrend'].iloc[-1],
            'direction': int(self.df['st_direction'].iloc[-1]),
            'signal': 'BULLISH' if self.df['st_direction'].iloc[-1] == 1 else 'BEARISH'
        }
    
    def calculate_volatility_indicators(self):
        settings = INDICATOR_SETTINGS
        
        bb = BollingerBands(
            self.df['close'],
            window=settings["BOLLINGER"]["period"],
            window_dev=settings["BOLLINGER"]["std"]
        )
        self.df['BB_UPPER'] = bb.bollinger_hband()
        self.df['BB_MIDDLE'] = bb.bollinger_mavg()
        self.df['BB_LOWER'] = bb.bollinger_lband()
        self.df['BB_WIDTH'] = bb.bollinger_wband()
        self.df['BB_PBAND'] = bb.bollinger_pband()
        
        self.indicators['BOLLINGER'] = {
            'upper': self.df['BB_UPPER'].iloc[-1],
            'middle': self.df['BB_MIDDLE'].iloc[-1],
            'lower': self.df['BB_LOWER'].iloc[-1],
            'width': self.df['BB_WIDTH'].iloc[-1],
            'percent_b': self.df['BB_PBAND'].iloc[-1],
            'signal': self._get_bollinger_signal()
        }
        
        atr = AverageTrueRange(
            self.df['high'], self.df['low'], self.df['close'],
            window=settings["ATR"]["period"]
        )
        self.df['ATR'] = atr.average_true_range()
        self.indicators['ATR'] = {
            'value': self.df['ATR'].iloc[-1],
            'percent': (self.df['ATR'].iloc[-1] / self.df['close'].iloc[-1]) * 100
        }
        
        keltner = KeltnerChannel(
            self.df['high'], self.df['low'], self.df['close'],
            window=settings["KELTNER"]["period"],
            window_atr=settings["KELTNER"]["period"]
        )
        self.df['KELTNER_UPPER'] = keltner.keltner_channel_hband()
        self.df['KELTNER_MIDDLE'] = keltner.keltner_channel_mband()
        self.df['KELTNER_LOWER'] = keltner.keltner_channel_lband()
        
        self.indicators['KELTNER'] = {
            'upper': self.df['KELTNER_UPPER'].iloc[-1],
            'middle': self.df['KELTNER_MIDDLE'].iloc[-1],
            'lower': self.df['KELTNER_LOWER'].iloc[-1],
            'signal': self._get_keltner_signal()
        }
        
        donchian = DonchianChannel(
            self.df['high'], self.df['low'], self.df['close'],
            window=settings["DONCHIAN"]["period"]
        )
        self.df['DONCHIAN_UPPER'] = donchian.donchian_channel_hband()
        self.df['DONCHIAN_MIDDLE'] = donchian.donchian_channel_mband()
        self.df['DONCHIAN_LOWER'] = donchian.donchian_channel_lband()
        
        self.indicators['DONCHIAN'] = {
            'upper': self.df['DONCHIAN_UPPER'].iloc[-1],
            'middle': self.df['DONCHIAN_MIDDLE'].iloc[-1],
            'lower': self.df['DONCHIAN_LOWER'].iloc[-1],
            'signal': self._get_donchian_signal()
        }
    
    def calculate_volume_indicators(self):
        settings = INDICATOR_SETTINGS
        
        if 'volume' in self.df.columns and self.df['volume'].sum() > 0:
            obv = OnBalanceVolumeIndicator(self.df['close'], self.df['volume'])
            self.df['OBV'] = obv.on_balance_volume()
            self.indicators['OBV'] = {
                'value': self.df['OBV'].iloc[-1],
                'trend': 'BULLISH' if self.df['OBV'].iloc[-1] > self.df['OBV'].iloc[-5] else 'BEARISH'
            }
            
            mfi = MFIIndicator(
                self.df['high'], self.df['low'], self.df['close'], self.df['volume'],
                window=settings["MFI"]["period"]
            )
            self.df['MFI'] = mfi.money_flow_index()
            self.indicators['MFI'] = {
                'value': self.df['MFI'].iloc[-1],
                'overbought': self.df['MFI'].iloc[-1] > settings["MFI"]["overbought"],
                'oversold': self.df['MFI'].iloc[-1] < settings["MFI"]["oversold"],
                'signal': self._get_mfi_signal()
            }
            
            try:
                vwap = VolumeWeightedAveragePrice(
                    self.df['high'], self.df['low'], self.df['close'], self.df['volume']
                )
                self.df['VWAP'] = vwap.volume_weighted_average_price()
                self.indicators['VWAP'] = {
                    'value': self.df['VWAP'].iloc[-1],
                    'signal': 'BULLISH' if self.df['close'].iloc[-1] > self.df['VWAP'].iloc[-1] else 'BEARISH'
                }
            except:
                self.indicators['VWAP'] = {'value': 0, 'signal': 'N/A'}
        else:
            self.indicators['OBV'] = {'value': 0, 'trend': 'N/A'}
            self.indicators['MFI'] = {'value': 0, 'signal': 'N/A'}
            self.indicators['VWAP'] = {'value': 0, 'signal': 'N/A'}
    
    def calculate_custom_indicators(self):
        self.indicators['PRICE'] = {
            'current': self.df['close'].iloc[-1],
            'open': self.df['open'].iloc[-1],
            'high': self.df['high'].iloc[-1],
            'low': self.df['low'].iloc[-1],
            'change': ((self.df['close'].iloc[-1] - self.df['close'].iloc[-2]) / self.df['close'].iloc[-2]) * 100
        }
        
        self.indicators['TREND_SUMMARY'] = self._calculate_trend_summary()
    
    def _get_rsi_signal(self) -> str:
        rsi = self.df['RSI'].iloc[-1]
        if rsi > 70:
            return 'OVERBOUGHT'
        elif rsi < 30:
            return 'OVERSOLD'
        elif rsi > 50:
            return 'BULLISH'
        else:
            return 'BEARISH'
    
    def _get_stochastic_signal(self) -> str:
        k = self.df['STOCH_K'].iloc[-1]
        d = self.df['STOCH_D'].iloc[-1]
        if k > 80:
            return 'OVERBOUGHT'
        elif k < 20:
            return 'OVERSOLD'
        elif k > d:
            return 'BULLISH'
        else:
            return 'BEARISH'
    
    def _get_cci_signal(self) -> str:
        cci = self.df['CCI'].iloc[-1]
        if cci > 100:
            return 'OVERBOUGHT'
        elif cci < -100:
            return 'OVERSOLD'
        elif cci > 0:
            return 'BULLISH'
        else:
            return 'BEARISH'
    
    def _get_williams_signal(self) -> str:
        wr = self.df['WILLIAMS_R'].iloc[-1]
        if wr > -20:
            return 'OVERBOUGHT'
        elif wr < -80:
            return 'OVERSOLD'
        elif wr > -50:
            return 'BULLISH'
        else:
            return 'BEARISH'
    
    def _get_macd_signal(self) -> str:
        macd = self.df['MACD'].iloc[-1]
        signal = self.df['MACD_SIGNAL'].iloc[-1]
        hist = self.df['MACD_HIST'].iloc[-1]
        prev_hist = self.df['MACD_HIST'].iloc[-2]
        
        if macd > signal and hist > prev_hist:
            return 'STRONG_BULLISH'
        elif macd > signal:
            return 'BULLISH'
        elif macd < signal and hist < prev_hist:
            return 'STRONG_BEARISH'
        else:
            return 'BEARISH'
    
    def _get_ema_trend(self) -> str:
        price = self.df['close'].iloc[-1]
        ema9 = self.df['EMA_9'].iloc[-1]
        ema21 = self.df['EMA_21'].iloc[-1]
        ema50 = self.df['EMA_50'].iloc[-1]
        ema200 = self.df['EMA_200'].iloc[-1]
        
        if price > ema9 > ema21 > ema50 > ema200:
            return 'STRONG_BULLISH'
        elif price > ema21 > ema50:
            return 'BULLISH'
        elif price < ema9 < ema21 < ema50 < ema200:
            return 'STRONG_BEARISH'
        elif price < ema21 < ema50:
            return 'BEARISH'
        else:
            return 'NEUTRAL'
    
    def _get_sma_trend(self) -> str:
        price = self.df['close'].iloc[-1]
        sma20 = self.df['SMA_20'].iloc[-1]
        sma50 = self.df['SMA_50'].iloc[-1]
        sma200 = self.df['SMA_200'].iloc[-1]
        
        if price > sma20 > sma50 > sma200:
            return 'STRONG_BULLISH'
        elif price > sma50 > sma200:
            return 'BULLISH'
        elif price < sma20 < sma50 < sma200:
            return 'STRONG_BEARISH'
        elif price < sma50 < sma200:
            return 'BEARISH'
        else:
            return 'NEUTRAL'
    
    def _get_adx_strength(self) -> str:
        adx = self.df['ADX'].iloc[-1]
        if adx > 50:
            return 'VERY_STRONG'
        elif adx > 25:
            return 'STRONG'
        elif adx > 20:
            return 'MODERATE'
        else:
            return 'WEAK'
    
    def _get_ichimoku_signal(self) -> str:
        price = self.df['close'].iloc[-1]
        tenkan = self.df['ICHIMOKU_TENKAN'].iloc[-1]
        kijun = self.df['ICHIMOKU_KIJUN'].iloc[-1]
        
        if price > tenkan > kijun:
            return 'BULLISH'
        elif price < tenkan < kijun:
            return 'BEARISH'
        else:
            return 'NEUTRAL'
    
    def _get_bollinger_signal(self) -> str:
        price = self.df['close'].iloc[-1]
        upper = self.df['BB_UPPER'].iloc[-1]
        lower = self.df['BB_LOWER'].iloc[-1]
        middle = self.df['BB_MIDDLE'].iloc[-1]
        
        if price > upper:
            return 'OVERBOUGHT'
        elif price < lower:
            return 'OVERSOLD'
        elif price > middle:
            return 'BULLISH'
        else:
            return 'BEARISH'
    
    def _get_keltner_signal(self) -> str:
        price = self.df['close'].iloc[-1]
        upper = self.df['KELTNER_UPPER'].iloc[-1]
        lower = self.df['KELTNER_LOWER'].iloc[-1]
        
        if price > upper:
            return 'BREAKOUT_UP'
        elif price < lower:
            return 'BREAKOUT_DOWN'
        else:
            return 'NEUTRAL'
    
    def _get_donchian_signal(self) -> str:
        price = self.df['close'].iloc[-1]
        upper = self.df['DONCHIAN_UPPER'].iloc[-1]
        lower = self.df['DONCHIAN_LOWER'].iloc[-1]
        
        if price >= upper:
            return 'NEW_HIGH'
        elif price <= lower:
            return 'NEW_LOW'
        else:
            return 'RANGE'
    
    def _get_mfi_signal(self) -> str:
        mfi = self.df['MFI'].iloc[-1]
        if mfi > 80:
            return 'OVERBOUGHT'
        elif mfi < 20:
            return 'OVERSOLD'
        elif mfi > 50:
            return 'BULLISH'
        else:
            return 'BEARISH'
    
    def _calculate_trend_summary(self) -> dict:
        bullish_count = 0
        bearish_count = 0
        
        signals = [
            self.indicators.get('RSI', {}).get('signal', ''),
            self.indicators.get('MACD', {}).get('trend', ''),
            self.indicators.get('EMA', {}).get('trend', ''),
            self.indicators.get('ADX', {}).get('trend_direction', ''),
            self.indicators.get('SUPERTREND', {}).get('signal', ''),
            self.indicators.get('PSAR', {}).get('signal', '')
        ]
        
        for signal in signals:
            if 'BULLISH' in signal:
                bullish_count += 1
            elif 'BEARISH' in signal:
                bearish_count += 1
        
        total = bullish_count + bearish_count
        if total > 0:
            bullish_pct = (bullish_count / total) * 100
        else:
            bullish_pct = 50
        
        if bullish_pct >= 70:
            overall = 'STRONG_BULLISH'
        elif bullish_pct >= 55:
            overall = 'BULLISH'
        elif bullish_pct <= 30:
            overall = 'STRONG_BEARISH'
        elif bullish_pct <= 45:
            overall = 'BEARISH'
        else:
            overall = 'NEUTRAL'
        
        return {
            'bullish_count': bullish_count,
            'bearish_count': bearish_count,
            'bullish_percent': bullish_pct,
            'overall': overall
        }
    
    def get_dataframe(self) -> pd.DataFrame:
        return self.df

import os
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from typing import Dict, List, Optional, Tuple
import json

try:
    from groq import Groq
    GROQ_AVAILABLE = True
except ImportError:
    GROQ_AVAILABLE = False

from config.settings import GROQ_API_KEY

class AIAnalyzer:
    def __init__(self):
        self.groq_client = None
        if GROQ_AVAILABLE and GROQ_API_KEY:
            try:
                self.groq_client = Groq(api_key=GROQ_API_KEY)
            except:
                pass
        
        self.ml_model = None
        self.scaler = StandardScaler()
        self.feature_columns = []
    
    def analyze_with_ai(self, market_data: dict, symbol: str, timeframe: str) -> dict:
        ml_prediction = self._ml_prediction(market_data)
        regime = self._detect_market_regime(market_data)
        money_flow = self._calculate_smart_money_flow(market_data)
        whale_activity = self._detect_whale_activity(market_data)
        reversal_prob = self._predict_reversal_probability(market_data)
        
        llm_analysis = None
        if self.groq_client:
            llm_analysis = self._get_llm_analysis(market_data, symbol, timeframe)
        
        combined_signal = self._combine_ai_signals(
            ml_prediction, regime, money_flow, whale_activity, reversal_prob, llm_analysis
        )
        
        return {
            'ml_prediction': ml_prediction,
            'market_regime': regime,
            'smart_money_flow': money_flow,
            'whale_activity': whale_activity,
            'reversal_probability': reversal_prob,
            'llm_analysis': llm_analysis,
            'combined_signal': combined_signal,
            'ai_confidence': self._calculate_ai_confidence(combined_signal)
        }
    
    def _ml_prediction(self, market_data: dict) -> dict:
        indicators = market_data.get('indicators', {})
        
        features = self._extract_features(indicators)
        
        if not features:
            return {
                'direction': 'NEUTRAL',
                'confidence': 50,
                'description': 'داده کافی برای پیش‌بینی ML نیست'
            }
        
        bullish_score = 0
        bearish_score = 0
        
        rsi = indicators.get('RSI', {}).get('value', 50)
        if rsi < 30:
            bullish_score += 20
        elif rsi > 70:
            bearish_score += 20
        elif rsi > 50:
            bullish_score += 5
        else:
            bearish_score += 5
        
        macd_trend = indicators.get('MACD', {}).get('trend', '')
        if 'BULLISH' in macd_trend:
            bullish_score += 15
        elif 'BEARISH' in macd_trend:
            bearish_score += 15
        
        ema_trend = indicators.get('EMA', {}).get('trend', '')
        if 'BULLISH' in ema_trend:
            bullish_score += 15
        elif 'BEARISH' in ema_trend:
            bearish_score += 15
        
        adx = indicators.get('ADX', {}).get('adx', 20)
        trend_strength = 'WEAK'
        if adx > 25:
            trend_strength = 'STRONG'
            if indicators.get('ADX', {}).get('trend_direction') == 'BULLISH':
                bullish_score += 10
            else:
                bearish_score += 10
        
        supertrend = indicators.get('SUPERTREND', {}).get('signal', '')
        if supertrend == 'BULLISH':
            bullish_score += 10
        elif supertrend == 'BEARISH':
            bearish_score += 10
        
        total = bullish_score + bearish_score
        if total > 0:
            confidence = max(bullish_score, bearish_score) / total * 100
        else:
            confidence = 50
        
        if bullish_score > bearish_score:
            direction = 'BULLISH'
        elif bearish_score > bullish_score:
            direction = 'BEARISH'
        else:
            direction = 'NEUTRAL'
        
        return {
            'direction': direction,
            'confidence': round(confidence, 1),
            'bullish_score': bullish_score,
            'bearish_score': bearish_score,
            'trend_strength': trend_strength,
            'description': f'پیش‌بینی ML: {direction} با اطمینان {confidence:.1f}%'
        }
    
    def _extract_features(self, indicators: dict) -> List[float]:
        features = []
        
        try:
            features.append(indicators.get('RSI', {}).get('value', 50))
            features.append(indicators.get('MACD', {}).get('histogram', 0))
            features.append(indicators.get('ADX', {}).get('adx', 20))
            features.append(indicators.get('STOCHASTIC', {}).get('k', 50))
            features.append(indicators.get('CCI', {}).get('value', 0))
            features.append(indicators.get('BOLLINGER', {}).get('percent_b', 0.5))
            features.append(indicators.get('ATR', {}).get('percent', 1))
            features.append(indicators.get('MFI', {}).get('value', 50))
            
            return features
        except:
            return []
    
    def _detect_market_regime(self, market_data: dict) -> dict:
        indicators = market_data.get('indicators', {})
        smc = market_data.get('smc', {})
        
        adx = indicators.get('ADX', {}).get('adx', 20)
        bb_width = indicators.get('BOLLINGER', {}).get('width', 0.02)
        atr_pct = indicators.get('ATR', {}).get('percent', 1)
        
        trend_summary = indicators.get('TREND_SUMMARY', {})
        bullish_pct = trend_summary.get('bullish_percent', 50)
        
        market_structure = smc.get('market_structure', {})
        
        if adx > 30:
            if bullish_pct > 60:
                regime = 'TRENDING_UP'
                description = 'روند صعودی قوی'
            elif bullish_pct < 40:
                regime = 'TRENDING_DOWN'
                description = 'روند نزولی قوی'
            else:
                regime = 'TRENDING'
                description = 'بازار روندی'
        elif adx < 20:
            if bb_width < 0.015:
                regime = 'CONSOLIDATION'
                description = 'فشردگی قیمت - آماده شکست'
            else:
                regime = 'RANGING'
                description = 'بازار رنج'
        else:
            regime = 'TRANSITIONING'
            description = 'در حال تغییر رژیم'
        
        if atr_pct > 2:
            volatility = 'HIGH'
        elif atr_pct > 1:
            volatility = 'NORMAL'
        else:
            volatility = 'LOW'
        
        return {
            'regime': regime,
            'description': description,
            'volatility': volatility,
            'adx': adx,
            'trend_direction': 'BULLISH' if bullish_pct > 50 else 'BEARISH',
            'recommendation': self._get_regime_recommendation(regime, volatility)
        }
    
    def _get_regime_recommendation(self, regime: str, volatility: str) -> str:
        recommendations = {
            'TRENDING_UP': 'مناسب برای معاملات لانگ - پیروی از روند',
            'TRENDING_DOWN': 'مناسب برای معاملات شورت - پیروی از روند',
            'RANGING': 'مناسب برای معاملات نوسانی - خرید در کف، فروش در سقف',
            'CONSOLIDATION': 'صبر کنید - احتمال شکست قوی وجود دارد',
            'TRANSITIONING': 'احتیاط کنید - سایز معاملات را کاهش دهید'
        }
        
        rec = recommendations.get(regime, 'بازار را رصد کنید')
        
        if volatility == 'HIGH':
            rec += ' | نوسان بالا - استاپ را بزرگتر بگذارید'
        elif volatility == 'LOW':
            rec += ' | نوسان پایین - منتظر حرکت بزرگ باشید'
        
        return rec
    
    def _calculate_smart_money_flow(self, market_data: dict) -> dict:
        indicators = market_data.get('indicators', {})
        smc = market_data.get('smc', {})
        
        mfi = indicators.get('MFI', {}).get('value', 50)
        obv_trend = indicators.get('OBV', {}).get('trend', 'NEUTRAL')
        
        premium_discount = smc.get('premium_discount', {})
        current_zone = premium_discount.get('current_zone', 'EQUILIBRIUM')
        
        order_blocks = smc.get('order_blocks', [])
        bullish_obs = len([ob for ob in order_blocks if ob['type'] == 'BULLISH_OB'])
        bearish_obs = len([ob for ob in order_blocks if ob['type'] == 'BEARISH_OB'])
        
        score = 50
        
        if mfi > 60:
            score += 15
        elif mfi < 40:
            score -= 15
        
        if obv_trend == 'BULLISH':
            score += 10
        elif obv_trend == 'BEARISH':
            score -= 10
        
        if current_zone == 'DISCOUNT':
            score += 10
        elif current_zone == 'PREMIUM':
            score -= 10
        
        score += (bullish_obs - bearish_obs) * 5
        
        score = max(0, min(100, score))
        
        if score > 65:
            flow = 'ACCUMULATION'
            description = 'پول هوشمند در حال انباشت است'
        elif score < 35:
            flow = 'DISTRIBUTION'
            description = 'پول هوشمند در حال توزیع است'
        else:
            flow = 'NEUTRAL'
            description = 'جریان پول هوشمند خنثی است'
        
        return {
            'flow': flow,
            'score': score,
            'description': description,
            'mfi': mfi,
            'obv_trend': obv_trend,
            'institutional_bias': 'BULLISH' if score > 55 else 'BEARISH' if score < 45 else 'NEUTRAL'
        }
    
    def _detect_whale_activity(self, market_data: dict) -> dict:
        indicators = market_data.get('indicators', {})
        smc = market_data.get('smc', {})
        
        liquidity = smc.get('liquidity', [])
        order_blocks = smc.get('order_blocks', [])
        
        whale_signals = []
        activity_score = 0
        
        if liquidity:
            recent_sweeps = liquidity[-3:]
            for sweep in recent_sweeps:
                whale_signals.append({
                    'type': 'LIQUIDITY_SWEEP',
                    'signal': sweep.get('signal', 'NEUTRAL'),
                    'description': sweep.get('description', '')
                })
                activity_score += 20
        
        strong_obs = [ob for ob in order_blocks if ob.get('strength', 0) >= 3]
        if strong_obs:
            for ob in strong_obs[:2]:
                whale_signals.append({
                    'type': 'ORDER_BLOCK',
                    'signal': 'BULLISH' if ob['type'] == 'BULLISH_OB' else 'BEARISH',
                    'description': ob.get('description', '')
                })
                activity_score += 15
        
        bos_choch = smc.get('bos_choch', [])
        choch_signals = [s for s in bos_choch if s['type'] == 'CHoCH']
        if choch_signals:
            whale_signals.append({
                'type': 'STRUCTURE_SHIFT',
                'signal': choch_signals[-1].get('direction', 'NEUTRAL'),
                'description': 'تغییر ساختار بازار - ورود موسسات'
            })
            activity_score += 25
        
        activity_score = min(100, activity_score)
        
        if activity_score > 60:
            activity_level = 'HIGH'
        elif activity_score > 30:
            activity_level = 'MODERATE'
        else:
            activity_level = 'LOW'
        
        bullish_signals = len([s for s in whale_signals if s.get('signal') == 'BULLISH'])
        bearish_signals = len([s for s in whale_signals if s.get('signal') == 'BEARISH'])
        
        if bullish_signals > bearish_signals:
            whale_direction = 'BULLISH'
        elif bearish_signals > bullish_signals:
            whale_direction = 'BEARISH'
        else:
            whale_direction = 'NEUTRAL'
        
        return {
            'activity_level': activity_level,
            'activity_score': activity_score,
            'whale_direction': whale_direction,
            'signals': whale_signals[:5],
            'description': f'فعالیت نهنگ‌ها: {activity_level} - جهت: {whale_direction}'
        }
    
    def _predict_reversal_probability(self, market_data: dict) -> dict:
        indicators = market_data.get('indicators', {})
        patterns = market_data.get('patterns', {})
        smc = market_data.get('smc', {})
        
        reversal_score = 0
        reversal_signals = []
        
        rsi = indicators.get('RSI', {}).get('value', 50)
        if rsi > 75:
            reversal_score += 20
            reversal_signals.append('RSI در اشباع خرید شدید')
        elif rsi < 25:
            reversal_score += 20
            reversal_signals.append('RSI در اشباع فروش شدید')
        
        stoch = indicators.get('STOCHASTIC', {})
        if stoch.get('overbought') or stoch.get('oversold'):
            reversal_score += 10
            reversal_signals.append('استوکاستیک در منطقه اشباع')
        
        candlesticks = patterns.get('candlestick_patterns', [])
        reversal_patterns = [p for p in candlesticks if p.get('strength') in ['STRONG', 'VERY_STRONG']]
        if reversal_patterns:
            reversal_score += len(reversal_patterns) * 15
            for p in reversal_patterns[:2]:
                reversal_signals.append(f"الگوی {p.get('pattern', '')}")
        
        bb = indicators.get('BOLLINGER', {})
        if bb.get('signal') in ['OVERBOUGHT', 'OVERSOLD']:
            reversal_score += 15
            reversal_signals.append('قیمت در کرانه باند بولینگر')
        
        premium_discount = smc.get('premium_discount', {})
        zone_pct = premium_discount.get('zone_percentage', 0)
        if zone_pct > 80:
            reversal_score += 15
            reversal_signals.append(f"قیمت در {premium_discount.get('current_zone', '')} قوی")
        
        liquidity = smc.get('liquidity', [])
        if liquidity:
            reversal_score += 15
            reversal_signals.append('جمع‌آوری نقدینگی رخ داده')
        
        macd_hist = indicators.get('MACD', {}).get('histogram', 0)
        prev_hist = macd_hist
        if macd_hist * prev_hist < 0:
            reversal_score += 10
            reversal_signals.append('واگرایی MACD')
        
        reversal_score = min(100, reversal_score)
        
        if reversal_score > 70:
            probability = 'HIGH'
            description = 'احتمال بالای برگشت قیمت'
        elif reversal_score > 40:
            probability = 'MODERATE'
            description = 'احتمال متوسط برگشت قیمت'
        else:
            probability = 'LOW'
            description = 'احتمال پایین برگشت قیمت'
        
        return {
            'probability': probability,
            'score': reversal_score,
            'description': description,
            'signals': reversal_signals[:5],
            'expected_direction': 'DOWN' if rsi > 50 else 'UP'
        }
    
    def _get_llm_analysis(self, market_data: dict, symbol: str, timeframe: str) -> Optional[dict]:
        if not self.groq_client:
            return None
        
        try:
            indicators = market_data.get('indicators', {})
            smc = market_data.get('smc', {})
            
            prompt = f"""تحلیل بازار {symbol} در تایم فریم {timeframe}:

اندیکاتورها:
- RSI: {indicators.get('RSI', {}).get('value', 'N/A')}
- MACD: {indicators.get('MACD', {}).get('trend', 'N/A')}
- روند EMA: {indicators.get('EMA', {}).get('trend', 'N/A')}
- ADX: {indicators.get('ADX', {}).get('adx', 'N/A')}

تحلیل SMC:
- ساختار بازار: {smc.get('market_structure', {}).get('trend', 'N/A')}
- منطقه قیمت: {smc.get('premium_discount', {}).get('current_zone', 'N/A')}

لطفا یک تحلیل کوتاه و مفید به فارسی ارائه دهید شامل:
1. جهت احتمالی حرکت
2. سطوح کلیدی
3. توصیه معاملاتی
"""
            
            response = self.groq_client.chat.completions.create(
                model="llama-3.1-70b-versatile",
                messages=[
                    {"role": "system", "content": "شما یک تحلیلگر حرفه‌ای بازارهای مالی هستید. پاسخ‌های کوتاه و کاربردی به فارسی بدهید."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=500,
                temperature=0.7
            )
            
            analysis_text = response.choices[0].message.content
            
            return {
                'analysis': analysis_text,
                'model': 'llama-3.1-70b-versatile',
                'status': 'success'
            }
            
        except Exception as e:
            return {
                'analysis': f'خطا در تحلیل AI: {str(e)}',
                'model': 'N/A',
                'status': 'error'
            }
    
    def _combine_ai_signals(self, ml: dict, regime: dict, money_flow: dict, 
                           whale: dict, reversal: dict, llm: Optional[dict]) -> dict:
        signals = {
            'BULLISH': 0,
            'BEARISH': 0,
            'NEUTRAL': 0
        }
        
        ml_dir = ml.get('direction', 'NEUTRAL')
        ml_conf = ml.get('confidence', 50)
        if ml_dir == 'BULLISH':
            signals['BULLISH'] += ml_conf * 0.25
        elif ml_dir == 'BEARISH':
            signals['BEARISH'] += ml_conf * 0.25
        
        if 'UP' in regime.get('regime', ''):
            signals['BULLISH'] += 20
        elif 'DOWN' in regime.get('regime', ''):
            signals['BEARISH'] += 20
        
        flow = money_flow.get('flow', 'NEUTRAL')
        if flow == 'ACCUMULATION':
            signals['BULLISH'] += 15
        elif flow == 'DISTRIBUTION':
            signals['BEARISH'] += 15
        
        whale_dir = whale.get('whale_direction', 'NEUTRAL')
        whale_score = whale.get('activity_score', 0)
        if whale_dir == 'BULLISH':
            signals['BULLISH'] += whale_score * 0.2
        elif whale_dir == 'BEARISH':
            signals['BEARISH'] += whale_score * 0.2
        
        if reversal.get('score', 0) > 60:
            expected = reversal.get('expected_direction', '')
            if expected == 'UP':
                signals['BULLISH'] += 10
            elif expected == 'DOWN':
                signals['BEARISH'] += 10
        
        total = sum(signals.values())
        if total > 0:
            bullish_pct = (signals['BULLISH'] / total) * 100
            bearish_pct = (signals['BEARISH'] / total) * 100
        else:
            bullish_pct = 50
            bearish_pct = 50
        
        if bullish_pct > 60:
            direction = 'BULLISH'
            confidence = bullish_pct
        elif bearish_pct > 60:
            direction = 'BEARISH'
            confidence = bearish_pct
        else:
            direction = 'NEUTRAL'
            confidence = 50
        
        return {
            'direction': direction,
            'confidence': round(confidence, 1),
            'bullish_score': round(signals['BULLISH'], 1),
            'bearish_score': round(signals['BEARISH'], 1),
            'description': f'سیگنال ترکیبی AI: {direction} با اطمینان {confidence:.1f}%'
        }
    
    def _calculate_ai_confidence(self, combined: dict) -> dict:
        confidence = combined.get('confidence', 50)
        
        if confidence > 80:
            level = 'VERY_HIGH'
            description = 'اطمینان بسیار بالا'
            trade_size = '100%'
        elif confidence > 65:
            level = 'HIGH'
            description = 'اطمینان بالا'
            trade_size = '75%'
        elif confidence > 55:
            level = 'MODERATE'
            description = 'اطمینان متوسط'
            trade_size = '50%'
        else:
            level = 'LOW'
            description = 'اطمینان پایین'
            trade_size = '25%'
        
        return {
            'level': level,
            'value': confidence,
            'description': description,
            'recommended_size': trade_size
        }

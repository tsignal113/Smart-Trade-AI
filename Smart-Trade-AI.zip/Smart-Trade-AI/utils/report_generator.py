from datetime import datetime
from typing import Dict, List, Any
from config.settings import TIMEFRAMES, INDICATOR_SETTINGS, SMC_SETTINGS

class DetailedReportGenerator:
    
    def __init__(self):
        self.separator = "━" * 40
        self.line_count = 0
    
    def _add_section(self, title: str, content: str) -> str:
        lines = f"\n{self.separator}\n{title}\n{self.separator}\n\n{content}\n"
        self.line_count += len(lines.split('\n'))
        return lines
    
    def _add_subsection(self, title: str) -> str:
        lines = f"\n📌 {title}\n" + "-" * 30 + "\n"
        self.line_count += 3
        return lines

    def _fmt_price(self, price) -> str:
        if price is None:
            return 'N/A'
        try:
            p = float(price)
        except (TypeError, ValueError):
            return 'N/A'
        if p >= 1000:
            return f"{p:.2f}"
        elif p >= 100:
            return f"{p:.3f}"
        elif p >= 10:
            return f"{p:.4f}"
        else:
            return f"{p:.5f}"
    
    def generate_indicator_report(self, indicators: Dict, symbol: str, timeframe: str, df) -> str:
        self.line_count = 0
        report = ""
        
        report += f"""
╔══════════════════════════════════════════════════════════════════╗
║       📊 گزارش کامل تحلیل اندیکاتورها                           ║
║       {symbol} - {TIMEFRAMES[timeframe]['display']}                                       ║
║       {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}                               ║
╚══════════════════════════════════════════════════════════════════╝

"""
        
        report += self._add_section("📈 اطلاعات پایه", f"""
💵 قیمت فعلی: {indicators['PRICE']['current']:.5f}
📊 تغییر: {indicators['PRICE']['change']:.2f}%
🔝 بالاترین: {indicators['PRICE']['high']:.5f}
🔻 پایین‌ترین: {indicators['PRICE']['low']:.5f}
📅 تاریخ و زمان: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
⏱ تایم فریم: {TIMEFRAMES[timeframe]['display']}
📊 تعداد کندل‌های تحلیل شده: {len(df)}
""")
        
        report += self._add_section("📊 خلاصه کلی روند", f"""
📈 تعداد سیگنال‌های صعودی: {indicators['TREND_SUMMARY']['bullish_count']}
📉 تعداد سیگنال‌های نزولی: {indicators['TREND_SUMMARY']['bearish_count']}
📊 درصد صعودی: {indicators['TREND_SUMMARY']['bullish_percent']:.1f}%

🎯 **نتیجه نهایی: {indicators['TREND_SUMMARY']['overall']}**
""")
        
        report += f"""

{'='*60}
📊 پایان گزارش تحلیل اندیکاتورها
تعداد خطوط گزارش: {len(report.split(chr(10)))}
تاریخ و زمان: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
{'='*60}
"""
        
        return report
    
    def generate_smc_report(self, smc_data: Dict, symbol: str, timeframe: str, df) -> str:
        self.line_count = 0
        report = ""
        
        ms = smc_data.get('market_structure', {})
        
        report += f"""
╔══════════════════════════════════════════════════════════════════╗
║       💎 گزارش کامل تحلیل Smart Money Concepts                  ║
║       {symbol} - {TIMEFRAMES[timeframe]['display']}                                       ║
║       {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}                               ║
╚══════════════════════════════════════════════════════════════════╝

"""
        
        report += self._add_section("📊 ساختار بازار (Market Structure)", f"""
🎯 روند کلی: {ms.get('trend', 'N/A')}
📝 توضیح: {ms.get('description', 'N/A')}
💪 قدرت روند: {ms.get('strength', 'N/A')}
""")
        
        report += f"""

{'='*60}
💎 پایان گزارش تحلیل SMC
تعداد خطوط گزارش: {len(report.split(chr(10)))}
تاریخ و زمان: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
{'='*60}
"""
        
        return report
    
    def _sf(self, v, default=0.0) -> float:
        try:
            return float(v)
        except (TypeError, ValueError):
            return default

    def generate_signal_report(self, signal: Dict, symbol: str, timeframe: str, signal_type: str) -> str:
        if signal_type == "subarashi":
            return self._subarashi_report(signal, symbol, timeframe)
        else:
            return self._sniper_report(signal, symbol, timeframe)

    # ─────────────────────────────────────────────────────────────────
    # گزارش سوباراشی - حرفه‌ای و کامل
    # ─────────────────────────────────────────────────────────────────
    def _subarashi_report(self, signal: Dict, symbol: str, timeframe: str) -> str:
        stype      = signal.get('signal_type', 'NEUTRAL')
        conf       = self._sf(signal.get('confidence', 0))
        bull       = self._sf(signal.get('bull_score', signal.get('bullish_score', 0)))
        bear       = self._sf(signal.get('bear_score', signal.get('bearish_score', 0)))
        cp         = self._sf(signal.get('current_price', 0))
        atr_val    = self._sf(signal.get('atr', 0))
        entry      = signal.get('entry')
        sl         = signal.get('stop_loss')
        tp1        = signal.get('take_profit_1')
        tp2        = signal.get('take_profit_2')
        tp3        = signal.get('take_profit_3')
        risk_pct   = self._sf(signal.get('risk_percent', 0))
        detail     = signal.get('detail', {}) or {}
        expl       = signal.get('entry_explanation', {}) or {}
        tf_display = TIMEFRAMES.get(timeframe, {}).get('display', timeframe)
        now        = datetime.now().strftime('%Y-%m-%d %H:%M')

        sig_emoji = '🟢' if stype == 'LONG' else '🔴' if stype == 'SHORT' else '⚪'
        conf_bar  = self._conf_bar(conf)
        strength  = 'عالی' if conf >= 78 else 'خوب' if conf >= 68 else 'متوسط' if conf >= 62 else 'ضعیف'

        r = ""

        # ── سربرگ ───────────────────────────────────────────────────
        r += f"""
╔══════════════════════════════════════════╗
║  🎯 ورود سوباراشی | {symbol} {tf_display}
║  {now}
╚══════════════════════════════════════════╝

{sig_emoji} سیگنال: {stype}    اطمینان: {conf:.1f}%  [{strength}]
{conf_bar}
امتیاز صعودی: {int(bull)}  |  نزولی: {int(bear)}
قیمت فعلی: {self._fmt_price(cp)}    ATR: {self._fmt_price(atr_val)}
"""

        # ── نقاط ورود و خروج ─────────────────────────────────────
        if stype != 'NEUTRAL' and entry is not None and sl is not None:
            ent_f = self._sf(entry)
            sl_f  = self._sf(sl)
            risk  = abs(ent_f - sl_f)

            rr1 = f"1:{abs(self._sf(tp1) - ent_f) / risk:.2f}" if tp1 and risk > 0 else "N/A"
            rr2 = f"1:{abs(self._sf(tp2) - ent_f) / risk:.2f}" if tp2 and risk > 0 else "N/A"
            rr3 = f"1:{abs(self._sf(tp3) - ent_f) / risk:.2f}" if tp3 and risk > 0 else "N/A"

            r += f"""
{self.separator}
💰 نقاط معامله
{self.separator}

🎯 ورود (Entry)    : {self._fmt_price(entry)}
🛑 استاپ لاس       : {self._fmt_price(sl)}    ریسک: {risk_pct:.3f}%

✅ TP1              : {self._fmt_price(tp1)}    R:R = {rr1}
✅ TP2              : {self._fmt_price(tp2)}    R:R = {rr2}
✅ TP3              : {self._fmt_price(tp3)}    R:R = {rr3}
"""
        else:
            # NEUTRAL
            ind = signal.get('indicators', {}) or {}
            smc = signal.get('smc', {}) or {}
            ms  = smc.get('market_structure', {}) if isinstance(smc, dict) else {}
            rsi_v = self._sf((ind.get('RSI', {}) or {}).get('value', 50))
            ema_d = ind.get('EMA', {}) or {}
            ema50 = self._sf(ema_d.get('EMA_50', cp))
            ema200= self._sf(ema_d.get('EMA_200', cp))
            ms_tr = ms.get('trend', 'N/A') if isinstance(ms, dict) else 'N/A'
            bos   = ms.get('recent_bos', 0) if isinstance(ms, dict) else 0
            choch = ms.get('recent_choch', 0) if isinstance(ms, dict) else 0

            r += f"""
{self.separator}
⚠️ شرایط ورود هنوز کامل نیست
{self.separator}

قیمت فعلی: {self._fmt_price(cp)}
RSI: {rsi_v:.1f}    EMA50: {self._fmt_price(ema50)}    EMA200: {self._fmt_price(ema200)}
ساختار SMC: {ms_tr}    BOS: {bos}    CHoCH: {choch}

منتظر شرایط زیر باشید:
  • BOS واضح + CHoCH در جهت مطلوب
  • قیمت در Order Block یا FVG معتبر
  • RSI زیر 35 (LONG) یا بالای 65 (SHORT)
  • تایید EMA50 + EMA200 + Supertrend
"""

        # ── تحلیل 5 فاز ──────────────────────────────────────────
        r += f"\n{self.separator}\n📊 تحلیل 5 فاز\n{self.separator}\n\n"

        phase_map = [
            ("روند کلی",     ['ema', 'supertrend', 'adx']),
            ("ساختار SMC",   ['ms', 'pd', 'liq']),
            ("مومنتوم",      ['rsi', 'macd', 'stoch']),
            ("ناحیه ورود",   ['ob', 'fvg', 'sd']),
            ("تأییدیه",      ['bb', 'candle', 'vol']),
        ]
        dir_emoji = {'BULL': '🟢', 'BULL_M': '🔵', 'BEAR': '🔴', 'BEAR_M': '🟠',
                     'NEUT': '⚪', 'NEUTRAL': '⚪', 'NONE': '⚫', 'WEAK': '⚫'}

        for phase_name, keys in phase_map:
            pts_total = sum(detail.get(k, {}).get('pts', 0) for k in keys if k in detail)
            r += f"[ فاز: {phase_name} ]  (+{pts_total} pts)\n"
            for k in keys:
                if k in detail:
                    d = detail[k]
                    em = dir_emoji.get(d.get('dir', 'NEUT'), '⚪')
                    r += f"  {em} {d.get('text', '')}\n"
            r += "\n"

        # ── دلایل ورود ──────────────────────────────────────────
        entry_reasons = expl.get('entry_reasons', [])
        if entry_reasons:
            r += f"{self.separator}\n🔎 دلایل ورود\n{self.separator}\n"
            for i, reason in enumerate(entry_reasons, 1):
                r += f"{i}. {reason}\n"
            r += "\n"

        # ── دلایل SL ─────────────────────────────────────────────
        sl_reasons = expl.get('sl_reasons', [])
        if sl_reasons:
            r += f"{self.separator}\n🛑 استاپ لاس – چرا؟\n{self.separator}\n"
            for i, reason in enumerate(sl_reasons, 1):
                r += f"{i}. {reason}\n"
            r += "\n"

        # ── تارگت‌ها ──────────────────────────────────────────────
        tp_reasons = expl.get('tp_reasons', {})
        if tp_reasons:
            r += f"{self.separator}\n🎯 توضیح تارگت‌ها\n{self.separator}\n"
            for tp_key, tp_label in [('tp1', f"TP1 ({self._fmt_price(tp1)})"),
                                      ('tp2', f"TP2 ({self._fmt_price(tp2)})"),
                                      ('tp3', f"TP3 ({self._fmt_price(tp3)})")]:
                items = tp_reasons.get(tp_key, [])
                if items:
                    r += f"{tp_label}:\n"
                    for item in items:
                        r += f"  • {item}\n"
                    r += "\n"

        # ── پلن معامله ───────────────────────────────────────────
        trade_plan = expl.get('trade_plan', [])
        if trade_plan:
            r += f"{self.separator}\n📋 پلن مدیریت معامله\n{self.separator}\n"
            for step in trade_plan:
                r += f"{step}\n"
            r += "\n"

        # ── سطوح کلیدی ───────────────────────────────────────────
        key_levels = expl.get('key_levels', {})
        if key_levels:
            r += f"{self.separator}\n📌 سطوح کلیدی بازار\n{self.separator}\n"
            level_labels = [
                ('pivot',   'Pivot Point'),
                ('r1',      'مقاومت R1 '),
                ('r2',      'مقاومت R2 '),
                ('s1',      'حمایت S1  '),
                ('s2',      'حمایت S2  '),
                ('fib_382', 'فیبو 38.2% '),
                ('fib_500', 'فیبو 50.0% '),
                ('fib_618', 'فیبو 61.8% '),
            ]
            for alias, label in level_labels:
                v = key_levels.get(alias)
                if v:
                    r += f"• {label}: {self._fmt_price(v)}\n"
            r += "\n"

        # ── شرایط باطل شدن ───────────────────────────────────────
        invalidation = expl.get('invalidation', [])
        if invalidation:
            r += f"{self.separator}\n❌ شرایط باطل شدن معامله\n{self.separator}\n"
            for item in invalidation:
                r += f"• {item}\n"
            r += "\n"

        # ── خلاصه دلایل ──────────────────────────────────────────
        reasons = signal.get('reasons', [])
        if reasons:
            r += f"{self.separator}\n✔ خلاصه دلایل سیگنال\n{self.separator}\n"
            for i, reason in enumerate(reasons[:8], 1):
                r += f"{i}. {reason}\n"
            r += "\n"

        # ── پاورقی ───────────────────────────────────────────────
        r += f"""{'='*44}
🎯 پایان گزارش سوباراشی | {symbol} {tf_display}
⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
{'='*44}
"""
        return r

    def _conf_bar(self, pct: float) -> str:
        filled = int(round(pct / 5))
        filled = max(0, min(20, filled))
        return "[" + "█" * filled + "░" * (20 - filled) + f"] {pct:.0f}%"

    # ─────────────────────────────────────────────────────────────────
    # گزارش اسنایپر
    # ─────────────────────────────────────────────────────────────────
    def _sniper_report(self, signal: Dict, symbol: str, timeframe: str) -> str:
        stype      = signal.get('signal_type', 'NEUTRAL')
        conf       = self._sf(signal.get('confidence', 0))
        bull       = self._sf(signal.get('bullish_score', 0))
        bear       = self._sf(signal.get('bearish_score', 0))
        cp         = self._sf(signal.get('current_price', 0))
        atr_val    = self._sf(signal.get('atr', 0))
        entry      = signal.get('entry')
        sl         = signal.get('stop_loss')
        tp1        = signal.get('take_profit_1')
        tp2        = signal.get('take_profit_2')
        tp3        = signal.get('take_profit_3')
        risk_pct   = self._sf(signal.get('risk_percent', 0))
        expl       = signal.get('entry_explanation', {}) or {}
        tf_display = TIMEFRAMES.get(timeframe, {}).get('display', timeframe)
        now        = datetime.now().strftime('%Y-%m-%d %H:%M')

        sig_emoji = '🟢' if stype == 'LONG' else '🔴' if stype == 'SHORT' else '⚪'
        conf_bar  = self._conf_bar(conf)
        strength  = 'عالی' if conf >= 80 else 'خوب' if conf >= 65 else 'متوسط' if conf >= 50 else 'ضعیف'

        r = ""
        r += f"""
╔══════════════════════════════════════════╗
║  🎪 ورود اسنایپری | {symbol} {tf_display}
║  {now}
╚══════════════════════════════════════════╝

{sig_emoji} سیگنال: {stype}    اطمینان: {conf:.1f}%  [{strength}]
{conf_bar}
امتیاز صعودی: {int(bull)}  |  نزولی: {int(bear)}
قیمت فعلی: {self._fmt_price(cp)}    ATR: {self._fmt_price(atr_val)}
"""

        if stype != 'NEUTRAL' and entry is not None and sl is not None:
            ent_f = self._sf(entry)
            sl_f  = self._sf(sl)
            risk  = abs(ent_f - sl_f)
            rr1 = f"1:{abs(self._sf(tp1) - ent_f) / risk:.2f}" if tp1 and risk > 0 else "N/A"
            rr2 = f"1:{abs(self._sf(tp2) - ent_f) / risk:.2f}" if tp2 and risk > 0 else "N/A"
            rr3 = f"1:{abs(self._sf(tp3) - ent_f) / risk:.2f}" if tp3 and risk > 0 else "N/A"

            r += f"""
{self.separator}
💰 نقاط معامله اسنایپری
{self.separator}

🎯 ورود (Entry)    : {self._fmt_price(entry)}
🛑 استاپ لاس       : {self._fmt_price(sl)}    ریسک: {risk_pct:.3f}%

✅ TP1              : {self._fmt_price(tp1)}    R:R = {rr1}
✅ TP2              : {self._fmt_price(tp2)}    R:R = {rr2}
✅ TP3              : {self._fmt_price(tp3)}    R:R = {rr3}
"""

        # اسنایپر-اختصاصی
        sniper_conf = signal.get('is_sniper_entry', False)
        sniper_q    = signal.get('sniper_quality', 'N/A')
        sniper_sc   = signal.get('sniper_score', 0)
        r += f"""
{self.separator}
🎪 وضعیت اسنایپر
{self.separator}

{'✅ تأیید شد' if sniper_conf else '❌ تأیید نشد'} – ورود اسنایپری
کیفیت: {sniper_q}    امتیاز: {sniper_sc}/100
"""
        sniper_conds = signal.get('sniper_conditions', [])
        if sniper_conds:
            r += "شرایط برآورده‌شده:\n"
            for c in sniper_conds:
                r += f"  ✓ {c}\n"

        # دلایل
        entry_reasons = expl.get('entry_reasons', [])
        if entry_reasons:
            r += f"\n{self.separator}\n🔎 دلایل ورود\n{self.separator}\n"
            for i, reason in enumerate(entry_reasons, 1):
                r += f"{i}. {reason}\n"

        sl_reasons = expl.get('sl_reasons', [])
        if sl_reasons:
            r += f"\n{self.separator}\n🛑 استاپ لاس – چرا؟\n{self.separator}\n"
            for i, reason in enumerate(sl_reasons, 1):
                r += f"{i}. {reason}\n"

        tp_reasons = expl.get('tp_reasons', {})
        if tp_reasons:
            r += f"\n{self.separator}\n🎯 توضیح تارگت‌ها\n{self.separator}\n"
            for tp_key, tp_label in [('tp1', f"TP1 ({self._fmt_price(tp1)})"),
                                      ('tp2', f"TP2 ({self._fmt_price(tp2)})"),
                                      ('tp3', f"TP3 ({self._fmt_price(tp3)})")]:
                items = tp_reasons.get(tp_key, [])
                if items:
                    r += f"{tp_label}:\n"
                    for item in items:
                        r += f"  • {item}\n"

        trade_plan = expl.get('trade_plan', [])
        if trade_plan:
            r += f"\n{self.separator}\n📋 پلن مدیریت معامله\n{self.separator}\n"
            for step in trade_plan:
                r += f"{step}\n"

        key_levels = expl.get('key_levels', {})
        if key_levels:
            r += f"\n{self.separator}\n📌 سطوح کلیدی\n{self.separator}\n"
            for alias, label in [('pivot','Pivot'),('r1','R1'),('r2','R2'),
                                  ('s1','S1'),('s2','S2'),('fib_382','F38.2'),
                                  ('fib_500','F50.0'),('fib_618','F61.8')]:
                v = key_levels.get(alias)
                if v:
                    r += f"• {label}: {self._fmt_price(v)}\n"

        invalidation = expl.get('invalidation', [])
        if invalidation:
            r += f"\n{self.separator}\n❌ شرایط باطل شدن\n{self.separator}\n"
            for item in invalidation:
                r += f"• {item}\n"

        reasons = signal.get('reasons', [])
        if reasons:
            r += f"\n{self.separator}\n✔ خلاصه دلایل\n{self.separator}\n"
            for i, reason in enumerate(reasons[:8], 1):
                r += f"{i}. {reason}\n"

        r += f"""
{'='*44}
🎪 پایان گزارش اسنایپری | {symbol} {TIMEFRAMES.get(timeframe,{}).get('display',timeframe)}
⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
{'='*44}
"""
        return r
    
    def generate_ai_report(self, ai_data: Dict, symbol: str, timeframe: str) -> str:
        report = ""
        
        combined = ai_data.get('combined_signal', {})
        
        report += f"""
╔══════════════════════════════════════════════════════════════════╗
║       🤖 گزارش کامل تحلیل هوش مصنوعی                            ║
║       {symbol} - {TIMEFRAMES[timeframe]['display']}                                       ║
║       {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}                               ║
╚══════════════════════════════════════════════════════════════════╝

"""
        
        report += self._add_section("🎯 سیگنال ترکیبی AI", f"""
{'🟢' if combined.get('direction') == 'BULLISH' else '🔴' if combined.get('direction') == 'BEARISH' else '⚪'} جهت پیش‌بینی: {combined.get('direction', 'N/A')}
📊 درصد اطمینان: {combined.get('confidence', 0):.1f}%
""")
        
        report += f"""

{'='*60}
🤖 پایان گزارش تحلیل AI
تاریخ و زمان: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
{'='*60}
"""
        
        return report
    
    def generate_technical_report(self, patterns: Dict, symbol: str, timeframe: str) -> str:
        report = ""
        
        report += f"""
╔══════════════════════════════════════════════════════════════════╗
║       📈 گزارش کامل تحلیل تکنیکال                               ║
║       {symbol} - {TIMEFRAMES[timeframe]['display']}                                       ║
║       {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}                               ║
╚══════════════════════════════════════════════════════════════════╝

"""
        
        report += f"""

{'='*60}
📈 پایان گزارش تحلیل تکنیکال
تاریخ و زمان: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
{'='*60}
"""
        
        return report
    
    def generate_fundamental_report(self, analysis: Dict, symbol: str) -> str:
        report = ""
        
        report += f"""
╔══════════════════════════════════════════════════════════════════╗
║       💼 گزارش کامل تحلیل فاندامنتال                            ║
║       {symbol}                                                    ║
║       {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}                               ║
╚══════════════════════════════════════════════════════════════════╝

"""
        
        report += f"""

{'='*60}
💼 پایان گزارش تحلیل فاندامنتال
تاریخ و زمان: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
{'='*60}
"""
        
        return report
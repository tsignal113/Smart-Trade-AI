import os
from dotenv import load_dotenv

load_dotenv()

OANDA_API_KEY = os.getenv("OANDA_API_KEY", "")
OANDA_ACCOUNT_ID = os.getenv("OANDA_ACCOUNT_ID", "")
OANDA_BASE_URL = "https://api-fxpractice.oanda.com/v3"

BITSTAMP_BASE_URL = "https://www.bitstamp.net/api/v2"

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
CHAT_ID = os.getenv("CHAT_ID", "")

GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")

SYMBOLS = {
    "forex": {
        "XAUUSD": "XAU_USD",
        "USDJPY": "USD_JPY",
        "GBPUSD": "GBP_USD",
        "EURUSD": "EUR_USD"
    },
    "crypto": {
        "BTCUSD": "btcusd",
        "XRPUSD": "xrpusd"
    }
}

TIMEFRAMES = {
    "1m": {"oanda": "M1", "bitstamp": 60, "display": "1 دقیقه"},
    "5m": {"oanda": "M5", "bitstamp": 300, "display": "5 دقیقه"},
    "15m": {"oanda": "M15", "bitstamp": 900, "display": "15 دقیقه"},
    "30m": {"oanda": "M30", "bitstamp": 1800, "display": "30 دقیقه"},
    "1h": {"oanda": "H1", "bitstamp": 3600, "display": "1 ساعت"},
    "4h": {"oanda": "H4", "bitstamp": 14400, "display": "4 ساعت"},
    "daily": {"oanda": "D", "bitstamp": 86400, "display": "روزانه"}
}

INDICATOR_SETTINGS = {
    "RSI": {"period": 14, "overbought": 70, "oversold": 30},
    "MACD": {"fast": 12, "slow": 26, "signal": 9},
    "EMA": {"periods": [9, 21, 50, 200]},
    "SMA": {"periods": [20, 50, 100, 200]},
    "BOLLINGER": {"period": 20, "std": 2},
    "STOCHASTIC": {"k_period": 14, "d_period": 3, "overbought": 80, "oversold": 20},
    "CCI": {"period": 20, "overbought": 100, "oversold": -100},
    "WILLIAMS_R": {"period": 14, "overbought": -20, "oversold": -80},
    "ROC": {"period": 12},
    "ADX": {"period": 14, "strong_trend": 25},
    "ATR": {"period": 14},
    "ICHIMOKU": {"tenkan": 9, "kijun": 26, "senkou_b": 52},
    "SUPERTREND": {"period": 10, "multiplier": 3},
    "KELTNER": {"period": 20, "multiplier": 2},
    "DONCHIAN": {"period": 20},
    "MFI": {"period": 14, "overbought": 80, "oversold": 20},
    "OBV": {"period": 14},
    "VWAP": {"period": 14}
}

SMC_SETTINGS = {
    "swing_lookback": 10,
    "fvg_min_gap": 0.001,
    "order_block_lookback": 20,
    "liquidity_sweep_pips": 5
}

UPDATE_INTERVAL = 300

MAX_MESSAGE_LENGTH = 4000
